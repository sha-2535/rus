from datetime import datetime
from uuid import UUID, uuid4
from pydantic import BaseModel, EmailStr


class User(BaseModel):
    id: UUID
    name: str
    email: EmailStr
    password_hash: str
    created_at: datetime

    @classmethod
    def create(cls, name: str, email: str, password_hash: str) -> "User":
        return cls(
            id=uuid4(),
            name=name,
            email=email,
            password_hash=password_hash,
            created_at=datetime.utcnow(),
        )