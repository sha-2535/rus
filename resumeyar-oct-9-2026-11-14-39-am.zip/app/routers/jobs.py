from fastapi import APIRouter, Depends, HTTPException, status

from app.routers.auth import get_current_user_dependency
from app.schemas.auth import UserResponse
from app.schemas.jobs import JobMatchRequest, JobMatchResponse
from app.services.job_match_service import match_job

router = APIRouter()


@router.post("/match", response_model=JobMatchResponse)
async def match_job_endpoint(
    request: JobMatchRequest,
    current_user: UserResponse = Depends(get_current_user_dependency),
):
    try:
        result = await match_job(str(current_user.id), request.job_text)
        return result
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to match job")


@router.get("/")
async def jobs_root():
    return {"message": "Jobs router"}