from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile, status
from pydantic import BaseModel
from typing import Optional

from app.routers.auth import get_current_user_dependency
from app.schemas.auth import UserResponse
from app.schemas.resume import ResumeResponse, ResumeUploadRequest
from app.schemas.tailor import TailorRequest, TailorResponse, FeedbackRequest, FeedbackResponse
from app.services.resume_service import process_resume_upload
from app.services.tailor_service import tailor_resume, apply_feedback

router = APIRouter()


class TailorBody(BaseModel):
    job_id: Optional[str] = None
    job_text: Optional[str] = None


@router.post("/upload", response_model=ResumeResponse, status_code=status.HTTP_201_CREATED)
async def upload_resume(
    file: UploadFile | None = File(None),
    text: str | None = Form(None),
    current_user: UserResponse = Depends(get_current_user_dependency),
):
    if not file and not text:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Either file or text must be provided",
        )
    
    file_bytes = None
    filename = None
    if file:
        file_bytes = await file.read()
        filename = file.filename
    
    try:
        resume = await process_resume_upload(
            user_id=str(current_user.id),
            file_bytes=file_bytes,
            filename=filename,
            raw_text=text,
        )
        return resume
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to process resume")


@router.post("/tailor", response_model=TailorResponse)
async def tailor_resume_endpoint(
    body: TailorBody,
    current_user: UserResponse = Depends(get_current_user_dependency),
):
    if not body.job_id and not body.job_text:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Either job_id or job_text must be provided",
        )
    
    request = TailorRequest(
        job_id=body.job_id,
        job_text=body.job_text,
        user_id=str(current_user.id),
    )
    
    try:
        result = await tailor_resume(request)
        return result
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to tailor resume")


@router.post("/feedback", response_model=FeedbackResponse)
async def feedback_endpoint(
    body: FeedbackRequest,
    current_user: UserResponse = Depends(get_current_user_dependency),
):
    if body.user_id != str(current_user.id):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorized")
    
    try:
        result = await apply_feedback(body)
        return result
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to apply feedback")


@router.get("/me", response_model=ResumeResponse)
async def get_my_resume(current_user: UserResponse = Depends(get_current_user_dependency)):
    from app.core.redis_client import kv_get
    
    resume_data = await kv_get(f"resume:{current_user.id}")
    if not resume_data:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Resume not found")
    
    return ResumeResponse(**resume_data)