from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from typing import Optional

from app.routers.auth import get_current_user_dependency
from app.schemas.auth import UserResponse
from app.services.agent_graph import AgentState, Preferences, run_agent

router = APIRouter()


class TailorRequest(BaseModel):
    jobs_text: list[str]
    preferences: Optional[Preferences] = None
    selected_job_index: Optional[int] = None
    feedback: Optional[str] = None


class TailorResponse(BaseModel):
    trace: list[dict]
    messages: list[str]
    matches: list[dict]
    selected_job: Optional[dict]
    tailored_resume: Optional[str]


@router.post("/run", response_model=TailorResponse)
async def run_tailor_agent(
    request: TailorRequest,
    current_user: UserResponse = Depends(get_current_user_dependency),
):
    initial_state: AgentState = {
        "user_id": str(current_user.id),
        "resume": None,
        "preferences": request.preferences,
        "jobs_text": request.jobs_text,
        "jobs": [],
        "matches": [],
        "selected_job": None,
        "tailored_resume": None,
        "feedback": request.feedback,
        "messages": [],
        "trace": [],
    }
    
    try:
        final_state = await run_agent(initial_state)
        
        if request.selected_job_index is not None and final_state.get("matches"):
            idx = request.selected_job_index
            if 0 <= idx < len(final_state["matches"]):
                final_state["selected_job"] = final_state["matches"][idx].job_parsed
        
        if final_state.get("feedback") and not request.feedback:
            pass
        
        return TailorResponse(
            trace=final_state["trace"],
            messages=final_state["messages"],
            matches=[m.model_dump() for m in final_state.get("matches", [])],
            selected_job=final_state["selected_job"].model_dump() if final_state.get("selected_job") else None,
            tailored_resume=final_state.get("tailored_resume"),
        )
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.post("/feedback")
async def apply_feedback(
    feedback: str,
    current_user: UserResponse = Depends(get_current_user_dependency),
):
    initial_state: AgentState = {
        "user_id": str(current_user.id),
        "resume": None,
        "preferences": None,
        "jobs_text": [],
        "jobs": [],
        "matches": [],
        "selected_job": None,
        "tailored_resume": None,
        "feedback": feedback,
        "messages": [],
        "trace": [],
    }
    
    try:
        final_state = await run_agent(initial_state)
        return {
            "tailored_resume": final_state.get("tailored_resume"),
            "trace": final_state["trace"],
        }
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.get("/")
async def tailor_root():
    return {"message": "Tailor router"}