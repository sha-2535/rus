import json
from typing import Any, Optional

import redis.asyncio as redis
from app.core.config import settings

_redis_client: Optional[redis.Redis] = None


async def get_redis() -> redis.Redis:
    global _redis_client
    if _redis_client is None:
        _redis_client = redis.from_url(
            settings.REDIS_URL,
            encoding="utf-8",
            decode_responses=True,
        )
    return _redis_client


async def close_redis():
    global _redis_client
    if _redis_client is not None:
        await _redis_client.close()
        _redis_client = None


async def kv_set(key: str, value: dict, ttl: Optional[int] = None) -> bool:
    client = await get_redis()
    serialized = json.dumps(value, ensure_ascii=False)
    if ttl:
        return await client.set(key, serialized, ex=ttl)
    return await client.set(key, serialized)


async def kv_get(key: str) -> Optional[dict]:
    client = await get_redis()
    data = await client.get(key)
    if data is None:
        return None
    return json.loads(data)


async def kv_delete(key: str) -> int:
    client = await get_redis()
    return await client.delete(key)