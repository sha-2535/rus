from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    FRONTEND_URL: str = "https://your-frontend.vercel.app"
    SECRET_KEY: str = "your-secret-key-change-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REDIS_URL: str = "redis://localhost:6379/0"
    OPENAI_API_KEY: Optional[str] = None
    OPENROUTER_API_KEY: Optional[str] = None
    OPENROUTER_BASE_URL: str = "https://openrouter.ai/api/v1"
    OPENROUTER_REFERER: str = "https://resumeyar.com"
    OPENROUTER_TITLE: str = "ResumeYar"
    OPENROUTER_EMBEDDING_MODEL: str = "liquid/lfm-2.5-embedding-350m:free"
    OPENROUTER_CHAT_MODEL: str = "nvidia/nemotron-3.5-lightning:free"
    OPENROUTER_FALLBACK_MODEL: str = "google/gemini-2.0-flash-exp:free"
    GEMINI_API_KEY: Optional[str] = None

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()