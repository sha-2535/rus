import json
import logging
from typing import Optional

from app.core.config import settings
from app.core.redis_client import kv_get, kv_set
from app.schemas.resume import ResumeResponse
from app.schemas.jobs import JobParsed
from app.schemas.tailor import TailorRequest, TailorResponse, FeedbackRequest, FeedbackResponse
from app.services.llm_service import chat_with_fallback
from app.services.job_match_service import parse_job_text

logger = logging.getLogger(__name__)

TAILOR_PROMPT = """تو یک نویسنده رزومه حرفه‌ای و متخصص ATS هستی. رزومه کاندید رو برای این شغل اختصاصی کن.

رزومه کاندید:
- نام: {name}
- خلاصه: {summary}
- مهارت‌ها: {skills}
- تجربیات: {experience}
- تحصیلات: {education}

آگهی شغلی:
- عنوان: {job_title}
- شرکت: {job_company}
- سطح: {job_level}
- مهارت‌های مورد نیاز: {job_skills}
- توضیحات: {job_description}

خروجی JSON دقیقاً این فرمت:
{{
  "tailored_resume": "متن کامل رزومه فارسی، فرمت استاندارد، بهینه برای ATS، با کلمات کلیدی آگهی",
  "changes": ["تغییر ۱", "تغییر ۲", "..."],
  "cover_letter": "نامه'accompagnement فارسی کوتاه و تأثیرگذار (۱۵۰-۲۰۰ کلمه)"
}}

فقط JSON معتبر برگردون، بدون متن اضافه."""

FEEDBACK_PROMPT = """رزومه اختصاصی زیر رو بر اساس بازخورد کاربر بازنویسی کن:

رزومه فعلی:
{current_resume}

بازخورد:
{feedback}

خروجی JSON:
{{
  "tailored_resume": "متن کامل رزومه اصلاح‌شده",
  "changes": ["تغییر ۱ بر اساس بازخورد", "تغییر ۲ بر اساس بازخورد"],
  "cover_letter": "نامه'accompagnement به‌روزرسانی‌شده"
}}

فقط JSON معتبر برگردون."""


def format_resume_for_prompt(resume: ResumeResponse) -> dict:
    return {
        "name": resume.name,
        "summary": resume.summary,
        "skills": ", ".join(resume.skills),
        "experience": "; ".join(
            f"{exp.title} در {exp.company} ({exp.duration}): {', '.join(exp.highlights)}"
            for exp in resume.experience
        ),
        "education": "; ".join(
            f"{edu.degree} {edu.field} در {edu.institution}"
            for edu in resume.education
        ),
    }


def format_job_for_prompt(job: JobParsed) -> dict:
    return {
        "job_title": job.title,
        "job_company": job.company,
        "job_level": job.level,
        "job_skills": ", ".join(job.required_skills),
        "job_description": job.description,
    }


async def tailor_resume(request: TailorRequest) -> TailorResponse:
    resume_data = await kv_get(f"resume:{request.user_id}")
    if not resume_data:
        raise ValueError("Resume not found for user")
    
    resume = ResumeResponse(**resume_data)
    
    if request.job_id:
        job_data = await kv_get(f"job:{request.job_id}")
        if not job_data:
            raise ValueError("Job not found")
        job = JobParsed(**job_data)
    elif request.job_text:
        job = await parse_job_text(request.job_text)
    else:
        raise ValueError("Either job_id or job_text must be provided")
    
    job_key = request.job_id or f"temp:{hash(request.job_text)}"
    cache_key = f"tailored:{request.user_id}:{job_key}"
    
    cached = await kv_get(cache_key)
    if cached:
        return TailorResponse(**cached)
    
    resume_fmt = format_resume_for_prompt(resume)
    job_fmt = format_job_for_prompt(job)
    
    messages = [
        {"role": "system", "content": TAILOR_PROMPT.format(**resume_fmt, **job_fmt)},
        {"role": "user", "content": "رزومه و نامه'accompagnement را تولید کن"},
    ]
    
    response = await chat_with_fallback(messages, json_mode=True)
    content = response["choices"][0]["message"]["content"]
    if not content:
        raise ValueError("Empty response from LLM")
    
    data = json.loads(content)
    result = TailorResponse(**data)
    
    await kv_set(cache_key, result.model_dump())
    
    return result


async def apply_feedback(request: FeedbackRequest) -> FeedbackResponse:
    job_data = await kv_get(f"job:{request.job_id}")
    if not job_data:
        raise ValueError("Job not found")
    job = JobParsed(**job_data)
    
    cache_key = f"tailored:{request.user_id}:{request.job_id}"
    current_data = await kv_get(cache_key)
    if not current_data:
        raise ValueError("No tailored resume found for this job")
    
    current = TailorResponse(**current_data)
    
    messages = [
        {"role": "system", "content": FEEDBACK_PROMPT.format(
            current_resume=current.tailored_resume,
            feedback=request.feedback_text,
        )},
        {"role": "user", "content": "رزومه را اصلاح کن"},
    ]
    
    response = await chat_with_fallback(messages, json_mode=True)
    content = response["choices"][0]["message"]["content"]
    if not content:
        raise ValueError("Empty response from LLM")
    
    data = json.loads(content)
    result = FeedbackResponse(**data)
    
    await kv_set(cache_key, result.model_dump())
    
    return result