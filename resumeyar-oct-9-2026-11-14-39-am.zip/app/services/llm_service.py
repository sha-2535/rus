import json
import logging
from typing import Any, Optional

import httpx

from app.core.config import settings

logger = logging.getLogger(__name__)

_client: Optional[httpx.AsyncClient] = None


def get_client() -> httpx.AsyncClient:
    global _client
    if _client is None:
        if not settings.OPENROUTER_API_KEY:
            raise ValueError("OPENROUTER_API_KEY not configured")
        _client = httpx.AsyncClient(
            base_url=settings.OPENROUTER_BASE_URL,
            headers={
                "Authorization": f"Bearer {settings.OPENROUTER_API_KEY}",
                "Content-Type": "application/json",
                "HTTP-Referer": settings.OPENROUTER_REFERER,
                "X-Title": settings.OPENROUTER_TITLE,
            },
            timeout=60.0,
        )
    return _client


async def close_client():
    global _client
    if _client is not None:
        await _client.aclose()
        _client = None


async def chat(
    messages: list[dict[str, Any]],
    model: str = None,
    json_mode: bool = False,
    reasoning: bool = False,
    max_retries: int = 2,
) -> dict:
    client = get_client()
    
    if model is None:
        model = settings.OPENROUTER_CHAT_MODEL
    
    payload: dict[str, Any] = {
        "model": model,
        "messages": messages,
    }
    if json_mode:
        payload["response_format"] = {"type": "json_object"}
    if reasoning:
        payload["reasoning"] = {"enabled": True}
    
    last_error: Exception | None = None
    
    for attempt in range(max_retries + 1):
        try:
            response = await client.post("/chat/completions", json=payload)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            last_error = e
            logger.warning(f"LLM call failed (attempt {attempt + 1}/{max_retries + 1}): {e}")
            if attempt < max_retries:
                continue
    
    raise last_error


async def chat_with_fallback(
    messages: list[dict[str, Any]],
    primary_model: str = None,
    fallback_model: str = None,
    json_mode: bool = False,
    reasoning: bool = False,
    max_retries: int = 2,
) -> dict:
    if primary_model is None:
        primary_model = settings.OPENROUTER_CHAT_MODEL
    if fallback_model is None:
        fallback_model = settings.OPENROUTER_FALLBACK_MODEL
    
    try:
        return await chat(messages, model=primary_model, json_mode=json_mode, reasoning=reasoning, max_retries=max_retries)
    except Exception as e:
        logger.warning(f"Primary model failed, trying fallback: {e}")
        return await chat(messages, model=fallback_model, json_mode=json_mode, reasoning=reasoning, max_retries=max_retries)


async def chat_stream(
    messages: list[dict[str, Any]],
    model: str = None,
    reasoning: bool = False,
) -> Any:
    """Stream response from OpenRouter with reasoning tokens."""
    if model is None:
        model = settings.OPENROUTER_CHAT_MODEL
    
    client = get_client()
    
    payload: dict[str, Any] = {
        "model": model,
        "messages": messages,
        "stream": True,
    }
    if reasoning:
        payload["reasoning"] = {"enabled": True}
    
    async with client.stream("POST", "/chat/completions", json=payload) as response:
        response.raise_for_status()
        async for line in response.aiter_lines():
            if line.startswith("data: "):
                data = line[6:]
                if data.strip() == "[DONE]":
                    break
                try:
                    yield json.loads(data)
                except json.JSONDecodeError:
                    continue


def extract_reasoning_details(response: dict) -> Optional[list]:
    """Extract reasoning_details from OpenRouter response for multi-turn conversations."""
    try:
        return response["choices"][0]["message"].get("reasoning_details")
    except (KeyError, IndexError, TypeError):
        return None


def create_assistant_message_with_reasoning(response: dict) -> dict:
    """Create assistant message preserving reasoning_details for next turn."""
    message = response["choices"][0]["message"]
    return {
        "role": "assistant",
        "content": message.get("content"),
        "reasoning_details": message.get("reasoning_details"),
    }