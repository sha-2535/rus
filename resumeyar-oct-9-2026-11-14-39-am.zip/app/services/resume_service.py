import io
import json
import logging
from typing import Optional

import pypdf
from docx import Document

from app.core.redis_client import kv_set
from app.schemas.resume import ResumeParseResult, ResumeResponse
from app.services.llm_service import chat_with_fallback

logger = logging.getLogger(__name__)

RESUME_PARSE_PROMPT = """تو یک استخراج‌کننده رزومه فارسی هستی. متن رزومه زیر رو تحلیل کن و این JSON رو برمی‌گردون:
{
  "name": "نام کامل کاندید",
  "skills": ["مهارت ۱", "مهارت ۲", "..."],
  "experience": [
    {"title": "عنوان شغل", "company": "نام شرکت", "duration": "مدت زمان", "highlights": ["دستاورد ۱", "دستاورد ۲"]}
  ],
  "education": [
    {"degree": "مقطع", "field": "رشته", "institution": "دانشگاه/موسسه"}
  ],
  "summary": "خلاصه حرفه‌ای ۲-۳ جمله‌ای"
}

فقط JSON معتبر برگردون، بدون متن اضافه. اگر اطلاعاتی نیست، آرایه خالی یا رشته خالی بذار."""


def extract_text_from_pdf(file_bytes: bytes) -> str:
    reader = pypdf.PdfReader(io.BytesIO(file_bytes))
    text = []
    for page in reader.pages:
        extracted = page.extract_text()
        if extracted:
            text.append(extracted)
    return "\n".join(text)


def extract_text_from_docx(file_bytes: bytes) -> str:
    doc = Document(io.BytesIO(file_bytes))
    text = []
    for para in doc.paragraphs:
        if para.text.strip():
            text.append(para.text)
    return "\n".join(text)


def extract_text_from_txt(file_bytes: bytes) -> str:
    return file_bytes.decode("utf-8", errors="ignore")


async def parse_resume_with_llm(text: str) -> ResumeParseResult:
    messages = [
        {"role": "system", "content": RESUME_PARSE_PROMPT},
        {"role": "user", "content": text[:15000]},
    ]
    response = await chat_with_fallback(messages, json_mode=True)
    
    content = response["choices"][0]["message"]["content"]
    if not content:
        raise ValueError("Empty response from LLM")
    
    data = json.loads(content)
    return ResumeParseResult(**data)


async def process_resume_upload(
    user_id: str,
    file_bytes: Optional[bytes] = None,
    filename: Optional[str] = None,
    raw_text: Optional[str] = None,
) -> ResumeResponse:
    if raw_text:
        text = raw_text
    elif file_bytes and filename:
        ext = filename.lower().split(".")[-1]
        if ext == "pdf":
            text = extract_text_from_pdf(file_bytes)
        elif ext in ("docx", "doc"):
            text = extract_text_from_docx(file_bytes)
        elif ext in ("txt", "md"):
            text = extract_text_from_txt(file_bytes)
        else:
            raise ValueError(f"Unsupported file type: {ext}")
    else:
        raise ValueError("No file or text provided")
    
    if not text.strip():
        raise ValueError("No text extracted from file")
    
    parsed = await parse_resume_with_llm(text)
    
    from uuid import uuid4
    resume_id = uuid4()
    
    resume_data = ResumeResponse(
        id=resume_id,
        name=parsed.name,
        skills=parsed.skills,
        experience=parsed.experience,
        education=parsed.education,
        summary=parsed.summary,
        raw_text=text[:5000],
    )
    
    await kv_set(f"resume:{user_id}", resume_data.model_dump())
    
    return resume_data