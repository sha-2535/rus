import json
from datetime import datetime, timedelta
from uuid import UUID, uuid4

import bcrypt
import jwt
from redis.asyncio import Redis

from app.core.config import settings
from app.core.redis_client import get_redis
from app.schemas.auth import User, UserCreate, UserLogin, UserResponse, Token


SECRET_KEY = settings.SECRET_KEY
ALGORITHM = settings.ALGORITHM
ACCESS_TOKEN_EXPIRE_MINUTES = 7 * 24 * 60  # 7 days


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()


def verify_password(password: str, password_hash: str) -> bool:
    return bcrypt.checkpw(password.encode(), password_hash.encode())


def create_access_token(data: dict, expires_delta: timedelta | None = None) -> str:
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


def decode_token(token: str) -> dict | None:
    try:
        return jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    except jwt.PyJWTError:
        return None


async def register_user(user_data: UserCreate) -> UserResponse:
    redis = await get_redis()
    
    email_key = f"user:email:{user_data.email}"
    existing = await redis.get(email_key)
    if existing:
        raise ValueError("Email already registered")
    
    user = User(
        id=uuid4(),
        name=user_data.name,
        email=user_data.email,
        password_hash=hash_password(user_data.password),
        created_at=datetime.utcnow(),
    )
    
    user_dict = user.model_dump()
    user_dict["id"] = str(user.id)
    user_dict["created_at"] = user.created_at.isoformat()
    
    await redis.set(f"user:email:{user.email}", json.dumps(user_dict))
    await redis.set(f"user:id:{user.id}", json.dumps(user_dict))
    
    return UserResponse(**user_dict)


async def login_user(credentials: UserLogin) -> Token:
    redis = await get_redis()
    
    email_key = f"user:email:{credentials.email}"
    user_json = await redis.get(email_key)
    if not user_json:
        raise ValueError("Invalid credentials")
    
    user = json.loads(user_json)
    if not verify_password(credentials.password, user["password_hash"]):
        raise ValueError("Invalid credentials")
    
    access_token = create_access_token(data={"sub": str(user["id"]), "email": user["email"]})
    return Token(access_token=access_token)


async def get_current_user(token: str) -> UserResponse | None:
    payload = decode_token(token)
    if not payload:
        return None
    
    user_id = payload.get("sub")
    if not user_id:
        return None
    
    redis = await get_redis()
    user_json = await redis.get(f"user:id:{user_id}")
    if not user_json:
        return None
    
    user = json.loads(user_json)
    return UserResponse(**user)