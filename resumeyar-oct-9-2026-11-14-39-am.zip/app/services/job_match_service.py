import json
import logging
import math
from typing import Optional

from app.core.config import settings
from app.core.redis_client import kv_get, kv_set
from app.schemas.jobs import JobMatchResponse, JobParsed
from app.schemas.resume import ResumeResponse
from app.services.llm_service import chat_with_fallback, get_client

logger = logging.getLogger(__name__)

JOB_PARSE_PROMPT = """تو یک تحلیل‌گر آگهی شغلی فارسی هستی. متن آگهی زیر رو تحلیل کن و این JSON رو برمی‌گردون:
{
  "title": "عنوان شغل",
  "company": "نام شرکت",
  "level": "سطح (junior/mid/senior/lead)",
  "remote": true/false,
  "location": "موقعیت مکانی",
  "required_skills": ["مهارت ۱", "مهارت ۲", "..."],
  "description": "توضیحات کامل شغل"
}

فقط JSON معتبر برگردون، بدون متن اضافه."""

MATCH_EXPLANATION_PROMPT = """تو یک مشاور شغلی هستی. بر اساس تطابق رزومه و آگهی شغلی، یک تحلیل کوتاه فارسی بنویس.

رزومه کاندید: {resume_summary}
مهارت‌های کاندید: {candidate_skills}
تجربیات کاندید: {candidate_experience}

آگهی شغلی: {job_title} در {job_company}
مهارت‌های مورد نیاز: {job_skills}
توضیحات: {job_description}

نمره تطابق: {score}/100

خروجی JSON:
{
  "reason": "توضیح ۲-۳ جمله‌ای چرا این نمره",
  "strengths": ["نقطه قوت ۱", "نقطه قوت ۲"],
  "gaps": ["شکاف ۱", "شکاف ۲"]
}

فقط JSON معتبر برگردون."""


def cosine_similarity(a: list[float], b: list[float]) -> float:
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(y * y for y in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


async def get_embedding(text: str) -> list[float]:
    if not settings.OPENROUTER_API_KEY:
        raise ValueError("OPENROUTER_API_KEY not configured")
    
    client = get_client()
    model = settings.OPENROUTER_EMBEDDING_MODEL
    
    last_error: Exception | None = None
    for attempt in range(3):
        try:
            response = await client.post("/embeddings", json={
                "model": model,
                "input": text,
                "encoding_format": "float",
            })
            response.raise_for_status()
            data = response.json()
            return data["data"][0]["embedding"]
        except Exception as e:
            last_error = e
            logger.warning(f"Embedding call failed (attempt {attempt + 1}/3): {e}")
            if attempt < 2:
                continue
    
    raise last_error


async def get_resume_embedding(user_id: str, resume: ResumeResponse) -> list[float]:
    cache_key = f"emb:resume:{user_id}"
    cached = await kv_get(cache_key)
    if cached and "embedding" in cached:
        return cached["embedding"]
    
    text_parts = [
        resume.name,
        resume.summary,
        " ".join(resume.skills),
        " ".join(f"{exp.title} {exp.company} {' '.join(exp.highlights)}" for exp in resume.experience),
        " ".join(f"{edu.degree} {edu.field} {edu.institution}" for edu in resume.education),
    ]
    text = " ".join(filter(None, text_parts))
    
    embedding = await get_embedding(text)
    
    await kv_set(cache_key, {"embedding": embedding})
    
    return embedding


async def parse_job_text(job_text: str) -> JobParsed:
    messages = [
        {"role": "system", "content": JOB_PARSE_PROMPT},
        {"role": "user", "content": job_text[:10000]},
    ]
    response = await chat_with_fallback(messages, json_mode=True)
    
    content = response["choices"][0]["message"]["content"]
    if not content:
        raise ValueError("Empty response from LLM")
    
    data = json.loads(content)
    return JobParsed(**data)


async def generate_match_explanation(
    resume: ResumeResponse,
    job: JobParsed,
    score: int,
) -> tuple[str, list[str], list[str]]:
    candidate_experience = "; ".join(
        f"{exp.title} at {exp.company} ({exp.duration}): {'; '.join(exp.highlights)}"
        for exp in resume.experience
    )
    
    messages = [
        {"role": "system", "content": MATCH_EXPLANATION_PROMPT.format(
            resume_summary=resume.summary,
            candidate_skills=", ".join(resume.skills),
            candidate_experience=candidate_experience,
            job_title=job.title,
            job_company=job.company,
            job_skills=", ".join(job.required_skills),
            job_description=job.description,
            score=score,
        )},
        {"role": "user", "content": "تحلیل را تولید کن"},
    ]
    
    response = await chat_with_fallback(messages, json_mode=True)
    
    content = response["choices"][0]["message"]["content"]
    if not content:
        return "تحلیل در دسترس نیست", [], []
    
    data = json.loads(content)
    return (
        data.get("reason", ""),
        data.get("strengths", []),
        data.get("gaps", []),
    )


async def match_job(user_id: str, job_text: str) -> JobMatchResponse:
    from app.core.redis_client import kv_get
    
    resume_data = await kv_get(f"resume:{user_id}")
    if not resume_data:
        raise ValueError("Resume not found for user")
    
    resume = ResumeResponse(**resume_data)
    
    job_parsed = await parse_job_text(job_text)
    
    # Store job for later reference
    from uuid import uuid4
    job_id = str(uuid4())
    await kv_set(f"job:{job_id}", job_parsed.model_dump())
    
    resume_embedding = await get_resume_embedding(user_id, resume)
    
    job_text_for_embedding = f"{job_parsed.title} {job_parsed.company} {job_parsed.description} {' '.join(job_parsed.required_skills)}"
    job_embedding = await get_embedding(job_text_for_embedding)
    
    similarity = cosine_similarity(resume_embedding, job_embedding)
    score = int(round(similarity * 100))
    score = max(0, min(100, score))
    
    reason, strengths, gaps = await generate_match_explanation(resume, job_parsed, score)
    
    return JobMatchResponse(
        score=score,
        reason=reason,
        strengths=strengths,
        gaps=gaps,
        job_parsed=job_parsed,
    )


async def store_job(job: JobParsed) -> str:
    """Store a parsed job and return its ID."""
    from uuid import uuid4
    job_id = str(uuid4())
    await kv_set(f"job:{job_id}", job.model_dump())
    return job_id