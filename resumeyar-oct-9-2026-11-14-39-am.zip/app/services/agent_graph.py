from typing import TypedDict, Annotated, Sequence
from uuid import UUID
from pydantic import BaseModel
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver

from app.schemas.resume import ResumeResponse, ExperienceItem, EducationItem
from app.schemas.jobs import JobParsed, JobMatchResponse
from app.schemas.auth import UserResponse


class Preferences(BaseModel):
    target_role: str | None = None
    target_level: str | None = None
    target_city: str | None = None
    remote_ok: bool | None = None
    salary_min: int | None = None


class AgentState(TypedDict):
    user_id: str
    resume: ResumeResponse | None
    preferences: Preferences | None
    jobs_text: list[str]
    jobs: list[JobParsed]
    matches: list[JobMatchResponse]
    selected_job: JobParsed | None
    tailored_resume: str | None
    feedback: str | None
    messages: Annotated[Sequence[str], "append"]
    trace: Annotated[list[dict], "append"]


async def extract_profile(state: AgentState) -> AgentState:
    trace_entry = {"node": "extract_profile", "status": "started"}
    state["trace"].append(trace_entry)
    
    if not state.get("resume"):
        from app.core.redis_client import kv_get
        resume_data = await kv_get(f"resume:{state['user_id']}")
        if resume_data:
            state["resume"] = ResumeResponse(**resume_data)
    
    trace_entry["status"] = "completed"
    trace_entry["resume_found"] = state.get("resume") is not None
    return state


async def clarify(state: AgentState) -> AgentState:
    trace_entry = {"node": "clarify", "status": "started"}
    state["trace"].append(trace_entry)
    
    prefs = state.get("preferences")
    if not prefs:
        from app.core.redis_client import kv_get
        prefs_data = await kv_get(f"prefs:{state['user_id']}")
        if prefs_data:
            state["preferences"] = Preferences(**prefs_data)
            prefs = state["preferences"]
    
    missing = []
    if prefs:
        if not prefs.target_role:
            missing.append("target_role")
        if not prefs.target_level:
            missing.append("target_level")
        if not prefs.target_city:
            missing.append("target_city")
    else:
        missing = ["target_role", "target_level", "target_city"]
    
    if missing:
        question = f"برای بهینه‌سازی جستجو، لطفاً این موارد را مشخص کنید: {', '.join(missing)}"
        state["messages"].append(question)
        trace_entry["status"] = "waiting_input"
        trace_entry["missing"] = missing
    else:
        trace_entry["status"] = "completed"
        trace_entry["preferences"] = prefs.model_dump() if prefs else None
    
    return state


async def parse_jobs(state: AgentState) -> AgentState:
    trace_entry = {"node": "parse_jobs", "status": "started"}
    state["trace"].append(trace_entry)
    
    from app.services.job_match_service import parse_job_text
    
    jobs_text = state.get("jobs_text", [])
    parsed_jobs = []
    for job_text in jobs_text:
        try:
            job = await parse_job_text(job_text)
            parsed_jobs.append(job)
        except Exception as e:
            trace_entry["errors"] = trace_entry.get("errors", [])
            trace_entry["errors"].append(str(e))
    
    state["jobs"] = parsed_jobs
    trace_entry["status"] = "completed"
    trace_entry["jobs_count"] = len(parsed_jobs)
    return state


async def match(state: AgentState) -> AgentState:
    trace_entry = {"node": "match", "status": "started"}
    state["trace"].append(trace_entry)
    
    from app.services.job_match_service import match_job
    
    matches = []
    for job in state.get("jobs", []):
        try:
            job_text = f"{job.title} {job.company} {job.description} {' '.join(job.required_skills)}"
            match_result = await match_job(state["user_id"], job_text)
            matches.append(match_result)
        except Exception as e:
            trace_entry["errors"] = trace_entry.get("errors", [])
            trace_entry["errors"].append(str(e))
    
    matches.sort(key=lambda m: m.score, reverse=True)
    state["matches"] = matches
    trace_entry["status"] = "completed"
    trace_entry["matches_count"] = len(matches)
    trace_entry["top_score"] = matches[0].score if matches else 0
    return state


async def explain(state: AgentState) -> AgentState:
    trace_entry = {"node": "explain", "status": "started"}
    state["trace"].append(trace_entry)
    
    for match in state.get("matches", []):
        if not match.reason:
            from app.services.job_match_service import generate_match_explanation
            from app.core.redis_client import kv_get
            
            resume_data = await kv_get(f"resume:{state['user_id']}")
            if resume_data:
                resume = ResumeResponse(**resume_data)
                reason, strengths, gaps = await generate_match_explanation(
                    resume, match.job_parsed, match.score
                )
                match.reason = reason
                match.strengths = strengths
                match.gaps = gaps
    
    trace_entry["status"] = "completed"
    trace_entry["explained_count"] = len(state.get("matches", []))
    return state


async def tailor_resume(state: AgentState) -> AgentState:
    trace_entry = {"node": "tailor_resume", "status": "started"}
    state["trace"].append(trace_entry)
    
    if not state.get("selected_job") or not state.get("matches"):
        trace_entry["status"] = "skipped"
        trace_entry["reason"] = "No job selected"
        return state
    
    selected = state["selected_job"]
    resume = state.get("resume")
    if not resume:
        trace_entry["status"] = "error"
        trace_entry["reason"] = "No resume available"
        return state
    
    from app.services.llm_service import chat_with_fallback
    
    TAILOR_PROMPT = f"""تو یک نویسنده رزومه تخصصی هستی. رزومه زیر رو برای این شغل اختصاصی کن:

رزومه فعلی:
- نام: {resume.name}
- خلاصه: {resume.summary}
- مهارت‌ها: {', '.join(resume.skills)}
- تجربیات: {'; '.join(f'{exp.title} در {exp.company} ({exp.duration}): {", ".join(exp.highlights)}' for exp in resume.experience)}
- تحصیلات: {'; '.join(f'{edu.degree} {edu.field} در {edu.institution}' for edu in resume.education)}

شغل هدف:
- عنوان: {selected.title}
- شرکت: {selected.company}
- مهارت‌های مورد نیاز: {', '.join(selected.required_skills)}
- توضیحات: {selected.description}

یک رزومه فارسی کامل و حرفه‌ای تولید کن که:
1. مهارت‌های مرتبط رو برجسته کنه
2. تجربیات رو طوری بازنویسی کنه که با شغل هدف سازگار باشه
3. کلمات کلیدی آگهی رو در متن ادغام کنه
4. فرمت استاندارد و خوانا داشته باشه

فقط متن رزومه رو برگردون، بدون JSON."""
    
    messages = [
        {"role": "system", "content": TAILOR_PROMPT},
        {"role": "user", "content": "رزومه اختصاصی را تولید کن"},
    ]
    
    response = await chat_with_fallback(messages, json_mode=False)
    tailored = response["choices"][0]["message"]["content"] or ""
    
    state["tailored_resume"] = tailored
    trace_entry["status"] = "completed"
    trace_entry["length"] = len(tailored)
    return state


async def apply_feedback(state: AgentState) -> AgentState:
    trace_entry = {"node": "apply_feedback", "status": "started"}
    state["trace"].append(trace_entry)
    
    feedback = state.get("feedback")
    if not feedback:
        trace_entry["status"] = "skipped"
        trace_entry["reason"] = "No feedback provided"
        return state
    
    if not state.get("tailored_resume"):
        trace_entry["status"] = "error"
        trace_entry["reason"] = "No tailored resume to modify"
        return state
    
    from app.services.llm_service import chat_with_fallback
    
    FEEDBACK_PROMPT = f"""رزومه زیر رو بر اساس بازخورد کاربر تغییر بده:

رزومه فعلی:
{state['tailored_resume']}

بازخورد کاربر:
{feedback}

فقط متن رزومه اصلاح‌شده رو برگردون."""
    
    messages = [
        {"role": "system", "content": FEEDBACK_PROMPT},
        {"role": "user", "content": "رزومه را اصلاح کن"},
    ]
    
    response = await chat_with_fallback(messages, json_mode=False)
    updated = response["choices"][0]["message"]["content"] or ""
    
    state["tailored_resume"] = updated
    state["feedback"] = None
    trace_entry["status"] = "completed"
    trace_entry["length"] = len(updated)
    return state


async def finalize(state: AgentState) -> AgentState:
    trace_entry = {"node": "finalize", "status": "started"}
    state["trace"].append(trace_entry)
    
    state["messages"].append("✅ فرآیند تکمیل شد. رزومه اختصاصی شما آماده است.")
    trace_entry["status"] = "completed"
    trace_entry["final_output"] = {
        "has_tailored_resume": bool(state.get("tailored_resume")),
        "matches_count": len(state.get("matches", [])),
        "selected_job": state.get("selected_job").model_dump() if state.get("selected_job") else None,
    }
    return state


def should_continue_clarify(state: AgentState) -> str:
    prefs = state.get("preferences")
    if not prefs:
        return "clarify"
    missing = []
    if not prefs.target_role:
        missing.append("target_role")
    if not prefs.target_level:
        missing.append("target_level")
    if not prefs.target_city:
        missing.append("target_city")
    return "clarify" if missing else "parse_jobs"


def should_continue_match(state: AgentState) -> str:
    matches = state.get("matches", [])
    if not matches:
        return "finalize"
    return "explain"


def should_continue_tailor(state: AgentState) -> str:
    if state.get("feedback"):
        return "apply_feedback"
    return "finalize"


def build_agent_graph():
    workflow = StateGraph(AgentState)
    
    workflow.add_node("extract_profile", extract_profile)
    workflow.add_node("clarify", clarify)
    workflow.add_node("parse_jobs", parse_jobs)
    workflow.add_node("match", match)
    workflow.add_node("explain", explain)
    workflow.add_node("tailor_resume", tailor_resume)
    workflow.add_node("apply_feedback", apply_feedback)
    workflow.add_node("finalize", finalize)
    
    workflow.set_entry_point("extract_profile")
    
    workflow.add_conditional_edges(
        "extract_profile",
        should_continue_clarify,
        {"clarify": "clarify", "parse_jobs": "parse_jobs"},
    )
    workflow.add_edge("clarify", "extract_profile")
    
    workflow.add_edge("parse_jobs", "match")
    
    workflow.add_conditional_edges(
        "match",
        should_continue_match,
        {"explain": "explain", "finalize": "finalize"},
    )
    workflow.add_edge("explain", "tailor_resume")
    
    workflow.add_conditional_edges(
        "tailor_resume",
        should_continue_tailor,
        {"apply_feedback": "apply_feedback", "finalize": "finalize"},
    )
    workflow.add_edge("apply_feedback", "tailor_resume")
    
    workflow.add_edge("finalize", END)
    
    return workflow.compile(checkpointer=MemorySaver())


async def run_agent(initial_state: AgentState) -> AgentState:
    graph = build_agent_graph()
    config = {"configurable": {"thread_id": initial_state["user_id"]}}
    result = await graph.ainvoke(initial_state, config)
    return result