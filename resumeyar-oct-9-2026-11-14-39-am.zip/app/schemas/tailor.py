from typing import Optional
from pydantic import BaseModel, Field
from uuid import UUID


class TailorRequest(BaseModel):
    job_id: Optional[str] = None
    job_text: Optional[str] = None
    user_id: str


class TailorResponse(BaseModel):
    tailored_resume: str
    changes: list[str]
    cover_letter: str


class FeedbackRequest(BaseModel):
    job_id: str
    feedback_text: str
    user_id: str


class FeedbackResponse(BaseModel):
    tailored_resume: str
    changes: list[str]
    cover_letter: str