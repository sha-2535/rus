from typing import Optional
from pydantic import BaseModel, Field
from uuid import UUID


class ExperienceItem(BaseModel):
    title: str
    company: str
    duration: str
    highlights: list[str] = []


class EducationItem(BaseModel):
    degree: str
    field: str
    institution: str


class ResumeParseResult(BaseModel):
    name: str
    skills: list[str]
    experience: list[ExperienceItem]
    education: list[EducationItem]
    summary: str


class ResumeUploadRequest(BaseModel):
    text: Optional[str] = None


class ResumeResponse(BaseModel):
    id: UUID
    name: str
    skills: list[str]
    experience: list[ExperienceItem]
    education: list[EducationItem]
    summary: str
    raw_text: str

    class Config:
        from_attributes = True


class TailorRequest(BaseModel):
    job_id: str | None = None
    job_text: str | None = None
    user_id: str


class TailorResponse(BaseModel):
    tailored_resume: str
    changes: list[str]
    cover_letter: str


class FeedbackRequest(BaseModel):
    job_id: str
    feedback_text: str
    user_id: str