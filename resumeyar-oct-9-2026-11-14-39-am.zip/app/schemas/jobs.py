from typing import Optional
from pydantic import BaseModel, Field
from uuid import UUID


class JobParsed(BaseModel):
    title: str
    company: str
    level: str
    remote: bool
    location: str
    required_skills: list[str]
    description: str


class JobMatchRequest(BaseModel):
    job_text: str = Field(..., min_length=50)


class JobMatchResponse(BaseModel):
    score: int = Field(..., ge=0, le=100)
    reason: str
    strengths: list[str]
    gaps: list[str]
    job_parsed: JobParsed