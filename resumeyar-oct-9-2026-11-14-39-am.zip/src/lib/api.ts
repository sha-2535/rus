/**
 * @file api.ts
 * API Service Layer for ResumeYar (رزومه یار)
 * Connects to FastAPI backend at NEXT_PUBLIC_API_URL or http://localhost:8000
 * Includes mock fallback when backend is unavailable.
 */

import {
  User,
  ResumeProfile,
  UserPreferences,
  Job,
  MatchAnalysis,
  TailoredResume,
  TailoredResumeContent
} from '../types';
import {
  INITIAL_USER_PROFILE,
  MOCK_JOBS,
  MOCK_MATCH_RESULTS,
  MOCK_TAILORED_RESUMES
} from './mock-data';

const API_BASE_URL =
  (typeof process !== 'undefined' && process.env?.NEXT_PUBLIC_API_URL) ||
  (typeof import.meta !== 'undefined' && (import.meta as any).env?.VITE_API_URL) ||
  'http://localhost:8000';

const USE_REAL_BACKEND = true;

const delay = (ms: number = 1000): Promise<void> =>
  new Promise((resolve) => setTimeout(resolve, ms));

const TOKEN_KEY = 'resumeyar_token';
const USER_KEY = 'resumeyar_user';

const getAuthHeaders = (): Record<string, string> => {
  if (typeof window === 'undefined') return { 'Content-Type': 'application/json' };
  const token = localStorage.getItem(TOKEN_KEY);
  return {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {})
  };
};

const getAuthHeadersForm = (): Record<string, string> => {
  if (typeof window === 'undefined') return {};
  const token = localStorage.getItem(TOKEN_KEY);
  return {
    ...(token ? { Authorization: `Bearer ${token}` } : {})
  };
};

const handleResponse = async (res: Response) => {
  if (!res.ok) {
    const text = await res.text();
    throw new Error(text || `HTTP ${res.status}`);
  }
  return res.json();
};

const fetchWithFallback = async <T>(
  url: string,
  options: RequestInit,
  mockFn: () => Promise<T>
): Promise<T> => {
  if (!USE_REAL_BACKEND) {
    return mockFn();
  }
  try {
    const res = await fetch(url, options);
    return handleResponse(res);
  } catch (error) {
    console.warn(`Backend unavailable, using mock: ${error}`);
    return mockFn();
  }
};

// -------------------------------------------------------------
// 1. AUTHENTICATION ENDPOINTS
// -------------------------------------------------------------

export interface RegisterPayload {
  name: string;
  email: string;
  password?: string;
}

export interface LoginPayload {
  email: string;
  password?: string;
}

export interface AuthResponse {
  user: User;
  access_token: string;
  token_type: string;
}

export async function registerUser(payload: RegisterPayload): Promise<AuthResponse> {
  return fetchWithFallback(
    `${API_BASE_URL}/auth/register`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    },
    async () => {
      await delay(1100);
      const mockUser: User = {
        id: `usr_${Date.now()}`,
        name: payload.name || 'کاربر رزومه یار',
        email: payload.email,
        avatarUrl: '/src/assets/images/persian_user_avatar_1791568791198.jpg',
        createdAt: new Date().toISOString()
      };
      const mockToken = `ry_jwt_${Math.random().toString(36).substring(2)}_${Date.now()}`;
      return { user: mockUser, access_token: mockToken, token_type: 'bearer' };
    }
  );
}

export async function loginUser(payload: LoginPayload): Promise<AuthResponse> {
  return fetchWithFallback(
    `${API_BASE_URL}/auth/login`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    },
    async () => {
      await delay(900);
      const mockUser: User = {
        id: 'usr_default_1',
        name: 'امیرحسین رضایی',
        email: payload.email,
        avatarUrl: '/src/assets/images/persian_user_avatar_1791568791198.jpg',
        createdAt: new Date().toISOString()
      };
      const mockToken = `ry_jwt_${Math.random().toString(36).substring(2)}_${Date.now()}`;
      return { user: mockUser, access_token: mockToken, token_type: 'bearer' };
    }
  );
}

export function setAuth(token: string, user: User) {
  if (typeof window !== 'undefined') {
    localStorage.setItem(TOKEN_KEY, token);
    localStorage.setItem(USER_KEY, JSON.stringify(user));
  }
}

export function clearAuth() {
  if (typeof window !== 'undefined') {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
  }
}

export function getStoredAuth(): { token: string | null; user: User | null } {
  if (typeof window === 'undefined') return { token: null, user: null };
  const token = localStorage.getItem(TOKEN_KEY);
  const userStr = localStorage.getItem(USER_KEY);
  return { token, user: userStr ? JSON.parse(userStr) : null };
}

// -------------------------------------------------------------
// 2. RESUME UPLOAD & PARSING
// -------------------------------------------------------------

export interface UploadResumePayload {
  file?: File;
  rawText?: string;
}

export interface UploadResumeResponse {
  profile: ResumeProfile;
  message: string;
}

export async function uploadResume(payload: UploadResumePayload): Promise<UploadResumeResponse> {
  const mockFn = async () => {
    await delay(1300);
    const baseProfile = { ...INITIAL_USER_PROFILE };
    if (payload.file) {
      baseProfile.fileName = payload.file.name;
    }
    if (payload.rawText) {
      baseProfile.rawText = payload.rawText;
      const firstLine = payload.rawText.split('\n')[0]?.trim();
      if (firstLine && firstLine.length < 40 && !firstLine.includes(':')) {
        baseProfile.fullName = firstLine;
      }
    }
    baseProfile.updatedAt = 'لحظاتی پیش';
    return { profile: baseProfile, message: 'رزومه با موفقیت توسط هوش مصنوعی پردازش و بخش‌های اصلی استخراج گردید.' };
  };

  if (!USE_REAL_BACKEND) return mockFn();

  try {
    const formData = new FormData();
    if (payload.file) formData.append('file', payload.file);
    if (payload.rawText) formData.append('text', payload.rawText);

    const res = await fetch(`${API_BASE_URL}/resume/upload`, {
      method: 'POST',
      headers: getAuthHeadersForm(),
      body: formData
    });
    return handleResponse(res);
  } catch (error) {
    console.warn(`Backend unavailable, using mock: ${error}`);
    return mockFn();
  }
}

export async function getMyResume(): Promise<ResumeProfile> {
  const mockFn = async () => {
    await delay(600);
    return INITIAL_USER_PROFILE;
  };

  if (!USE_REAL_BACKEND) return mockFn();

  try {
    const res = await fetch(`${API_BASE_URL}/resume/me`, {
      headers: getAuthHeaders()
    });
    return handleResponse(res);
  } catch (error) {
    console.warn(`Backend unavailable, using mock: ${error}`);
    return mockFn();
  }
}

// -------------------------------------------------------------
// 3. JOB PREFERENCES
// -------------------------------------------------------------

export async function savePreferences(preferences: UserPreferences): Promise<{ success: boolean; preferences: UserPreferences }> {
  const mockFn = async () => {
    await delay(800);
    return { success: true, preferences };
  };

  return fetchWithFallback(
    `${API_BASE_URL}/preferences`,
    {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(preferences)
    },
    mockFn
  );
}

// -------------------------------------------------------------
// 4. JOBS DIRECTORY
// -------------------------------------------------------------

export async function getJobs(searchQuery?: string, filter?: { seniority?: string; workStyle?: string }): Promise<Job[]> {
  const mockFn = async () => {
    await delay(600);
    let filtered = [...MOCK_JOBS];
    if (searchQuery?.trim()) {
      const q = searchQuery.toLowerCase().trim();
      filtered = filtered.filter(
        (j) =>
          j.title.toLowerCase().includes(q) ||
          j.company.toLowerCase().includes(q) ||
          j.description.toLowerCase().includes(q)
      );
    }
    if (filter?.seniority && filter.seniority !== 'all') {
      filtered = filtered.filter((j) => j.seniority === filter.seniority);
    }
    if (filter?.workStyle && filter.workStyle !== 'all') {
      filtered = filtered.filter((j) => j.workStyle === filter.workStyle);
    }
    return filtered;
  };

  return fetchWithFallback(
    `${API_BASE_URL}/jobs${new URLSearchParams({ q: searchQuery || '', seniority: filter?.seniority || '', workStyle: filter?.workStyle || '' }).toString()}`,
    { headers: getAuthHeaders() },
    mockFn
  );
}

// -------------------------------------------------------------
// 5. MATCH ANALYSIS
// -------------------------------------------------------------

export interface MatchPayload {
  job_text: string;
}

export async function matchJob(payload: MatchPayload): Promise<MatchAnalysis> {
  const mockFn = async () => {
    await delay(1200);
    return {
      jobId: 'mock',
      score: 84,
      summary: 'تطابق بسیار مناسب سوابق شما با شرح نیازمندی‌های این موقعیت شغلی.',
      strengths: ['انطباق پشته فناوری کلیدی', 'سطح سابقه کار متناسب', 'درک فرایندهای مهندسی چابک'],
      gaps: ['نیاز به بررسی دقیق‌تر معماری داده', 'افزودن کلیدواژه‌های اختصاصی پروژه'],
      agentReasoning: 'ایجنت بر اساس ارزیابی شباهت معنایی، تطابق بالایی میان مهارت‌های اعلامی و مسئولیت‌های این ردیف شغلی برآورد نمود.',
      skillOverlap: {
        matched: ['React', 'TypeScript', 'Responsive Design'],
        missing: ['Cloud Infrastructure']
      },
      recommendedActions: ['برجسته‌سازی پروژه‌های مرتبط با مقیاس بالا در رزومه سفارشی']
    };
  };

  return fetchWithFallback(
    `${API_BASE_URL}/jobs/match`,
    {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(payload)
    },
    mockFn
  );
}

// -------------------------------------------------------------
// 6. RESUME TAILORING
// -------------------------------------------------------------

export interface TailorPayload {
  job_id?: string;
  job_text?: string;
}

export async function tailorResume(payload: TailorPayload): Promise<TailoredResume> {
  const mockFn = async () => {
    await delay(1500);
    const job = MOCK_JOBS[0];
    const content: TailoredResumeContent = {
      headline: `متخصص ${job.title} | متمرکز بر ارزش‌آفرینی در ${job.company}`,
      summary: `مهندس باتجربه با تخصص متمرکز بر نیازمندی‌های کلیدی ${job.company}. متعهد به افزایش راندمان تیم و پیاده‌سازی متدهای پیشرفته منطبق بر استانداردهای این ردیف شغلی.`,
      highlightedSkills: job.requirements.slice(0, 5),
      tailoredExperiences: [
        {
          role: `توسعه‌دهنده متناسب با ${job.title}`,
          company: 'راهکارهای نوین ابری',
          period: '۱۴۰۱ - اکنون',
          bulletPoints: [
            {
              text: `پیاده‌سازی ماژول‌های مقیاس‌پذیر با تمرکز مستقیم بر ${job.requirements[0] || 'معماری مدرن'} و ارتقای شاخص‌های کارایی.`,
              isModified: true,
              keywordsAdded: [job.company, 'عملکرد مقیاس‌پذیر']
            },
            {
              text: `به‌کارگیری بهترین الگوهای مهندسی نرم‌افزار متناسب با چالش‌های فنی مطرح شده در آگهی ${job.company}.`,
              isModified: true,
              keywordsAdded: ['مهندسی نرم‌افزار', 'کار تیمی']
            }
          ]
        }
      ],
      addedKeywords: [job.company, 'معماری مقیاس‌پذیر', 'کیفیت کد', 'بهینه‌سازی سیستم'],
      coverLetter: `تیم محترم جذب و استخدام ${job.company}،

با سلام،

اینجانب با اشتیاق کامل متقاضی پیوستن به تیم پویا و پیشروی شما در جایگاه شغلی «${job.title}» می‌باشم. با بررسی دقیق اهداف مطرح‌شده، اطمینان دارم تجربیات گذشته اینجانب می‌تواند در مسیر رشد محصولات شما هم‌افزایی موثری ایجاد نماید.

با سپاس و احترام،
امیرحسین رضایی`,
      version: 1,
      generationNote: 'تولید نسخه اول بر پایه آگهی شغلی'
    };

    return {
      id: `tailored_${Date.now()}`,
      jobId: payload.job_id || 'mock',
      jobTitle: job.title,
      company: job.company,
      content,
      versions: [],
      createdAt: 'لحظاتی پیش',
      updatedAt: 'لحظاتی پیش'
    };
  };

  return fetchWithFallback(
    `${API_BASE_URL}/resume/tailor`,
    {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(payload)
    },
    mockFn
  );
}

// -------------------------------------------------------------
// 7. AGENT FEEDBACK & RE-GENERATION
// -------------------------------------------------------------

export interface FeedbackPayload {
  job_id: string;
  feedback_text: string;
}

export interface FeedbackResponse {
  tailored_resume: string;
  changes: string[];
  cover_letter: string;
}

export async function sendFeedback(payload: FeedbackPayload): Promise<FeedbackResponse> {
  const mockFn = async () => {
    await delay(1300);
    return {
      tailored_resume: 'رزومه به‌روزرسانی‌شده بر اساس بازخورد شما...',
      changes: [`اعمال بازخورد: ${payload.feedback_text}`],
      cover_letter: "نامه'accompagnement به‌روزرسانی‌شده..."
    };
  };

  return fetchWithFallback(
    `${API_BASE_URL}/resume/feedback`,
    {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(payload)
    },
    mockFn
  );
}

// -------------------------------------------------------------
// 8. AGENT GRAPH (Full Pipeline)
// -------------------------------------------------------------

export interface AgentRunPayload {
  jobs_text: string[];
  preferences?: UserPreferences;
  selected_job_index?: number;
  feedback?: string;
}

export interface AgentRunResponse {
  trace: Array<{ node: string; status: string; [key: string]: any }>;
  messages: string[];
  matches: MatchAnalysis[];
  selected_job?: Job;
  tailored_resume?: string;
}

export async function runAgent(payload: AgentRunPayload): Promise<AgentRunResponse> {
  const mockFn = async () => {
    await delay(2000);
    return {
      trace: [
        { node: 'extract_profile', status: 'completed', resume_found: true },
        { node: 'parse_jobs', status: 'completed', jobs_count: payload.jobs_text.length },
        { node: 'match', status: 'completed', matches_count: payload.jobs_text.length, top_score: 84 },
        { node: 'explain', status: 'completed', explained_count: payload.jobs_text.length },
        { node: 'tailor_resume', status: 'completed', length: 1500 },
        { node: 'finalize', status: 'completed' }
      ],
      messages: ['پروفایل استخراج شد', 'آگهی‌ها پارس شدند', 'تطابق محاسبه شد', 'تحلیل‌ها تولید شدند', 'رزومه اختصاصی ساخته شد', '✅ فرآیند تکمیل شد'],
      matches: payload.jobs_text.map((_, i) => ({
        jobId: `mock_${i}`,
        score: 84 - i * 5,
        summary: 'تطابق مناسب',
        strengths: ['مهارت‌های مرتبط'],
        gaps: ['مهارت کم'],
        agentReasoning: 'تحلیل',
        skillOverlap: { matched: [], missing: [] },
        recommendedActions: []
      })),
      selected_job: payload.selected_job_index !== undefined ? MOCK_JOBS[payload.selected_job_index] : MOCK_JOBS[0],
      tailored_resume: 'رزومه اختصاصی تولید شده...'
    };
  };

  return fetchWithFallback(
    `${API_BASE_URL}/tailor/run`,
    {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(payload)
    },
    mockFn
  );
}

export async function applyAgentFeedback(feedback: string): Promise<{ tailored_resume: string; trace: any[] }> {
  const mockFn = async () => {
    await delay(1300);
    return {
      tailored_resume: 'رزومه اصلاح‌شده بر اساس بازخورد...',
      trace: [
        { node: 'apply_feedback', status: 'completed' },
        { node: 'tailor_resume', status: 'completed', length: 1600 },
        { node: 'finalize', status: 'completed' }
      ]
    };
  };

  return fetchWithFallback(
    `${API_BASE_URL}/tailor/feedback`,
    {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ feedback })
    },
    mockFn
  );
}

// -------------------------------------------------------------
// 9. HEALTH CHECK
// -------------------------------------------------------------

export async function healthCheck(): Promise<{ status: string }> {
  try {
    const res = await fetch(`${API_BASE_URL}/health`, { method: 'GET' });
    return handleResponse(res);
  } catch {
    return { status: 'mock' };
  }
}