import { Job, ResumeProfile, UserPreferences, MatchAnalysis, TailoredResume, AgentLogStep } from '../types';

export const INITIAL_USER_PROFILE: ResumeProfile = {
  fullName: 'امیرحسین رضایی',
  title: 'توسعه‌دهنده ارشد فرانت‌اند و ری‌اکت',
  summary: 'مهندس نرم‌افزار با بیش از ۵ سال تجربه در ساخت وب‌اپلیکیشن‌های مقیاس‌پذیر، سیستم‌های طراحی (Design Systems) و بهینه‌سازی عملکرد با تمرکز بر اکوسیستم React، TypeScript و Next.js.',
  phone: '۰۹۱۲۳۴۵۶۷۸۹',
  email: 'amirhossein.rezaei@example.com',
  location: 'تهران، ایران',
  skills: [
    'React',
    'Next.js',
    'TypeScript',
    'Tailwind CSS',
    'JavaScript (ES6+)',
    'Redux Toolkit',
    'Zustand',
    'REST APIs',
    'GraphQL',
    'Git & GitHub',
    'Jest & Testing Library',
    'Web Performance',
    'Responsive Design'
  ],
  experiences: [
    {
      id: 'exp-1',
      role: 'توسعه‌دهنده ارشد فرانت‌اند',
      company: 'راهکارهای نوین ابری (کلودفلایر پارس)',
      period: '۱۴۰۱ - اکنون (۲ سال)',
      description: 'رهبری تیم ۴ نفره فرانت‌اند در بازنویسی داشبورد اصلی ابری و پیاده‌سازی معماری ماژولار.',
      highlights: [
        'افزایش ۴۰ درصدی سرعت لود اولیه صفحه با پیاده‌سازی Server-Side Rendering و Code Splitting در Next.js',
        'طراحی و انتشار کتابخانه مشترک Design System برای استفاده در ۴ محصول سازمانی',
        'پیاده‌سازی تست‌های خودکار E2E و Unit با پوشش ۷۵ درصدی کد'
      ]
    },
    {
      id: 'exp-2',
      role: 'برنامه‌نویس فرانت‌اند',
      company: 'فناوران داده رایان',
      period: '۱۳۹۸ - ۱۴۰۱ (۳ سال)',
      description: 'توسعه ماژول‌های فروشگاهی و پنل مدیریت سفارشات با React و Redux.',
      highlights: [
        'طراحی مجدد فرایند پرداخت و سبد خرید که نرخ تکمیل تراکنش را ۱۸ درصد افزایش داد',
        'یکپارچه‌سازی بیش از ۳۰ اندپوینت REST API و مدیریت کش کلاینت با React Query',
        'همکاری مستمر با تیم UI/UX در فرایند پیاده‌سازی فیگما به کد'
      ]
    }
  ],
  education: [
    {
      id: 'edu-1',
      degree: 'کارشناسی',
      field: 'مهندسی کامپیوتر - نرم‌افزار',
      university: 'دانشگاه صنعتی امیرکبیر',
      year: '۱۳۹۸'
    }
  ],
  fileName: 'Amirhossein_Rezaei_CV.pdf',
  updatedAt: 'امروز، ۱۰:۳۰'
};

export const INITIAL_PREFERENCES: UserPreferences = {
  desiredRole: 'توسعه‌دهنده ارشد فرانت‌اند (Senior Frontend)',
  seniorityLevel: 'senior',
  workStyle: 'hybrid',
  cities: ['تهران', 'دورکاری'],
  expectedSalaryMinMillionTomans: 55,
  expectedSalaryMaxMillionTomans: 85,
  keySkills: ['React', 'Next.js', 'TypeScript', 'Tailwind CSS', 'Web Performance'],
  industries: ['فین‌تک', 'تجارت الکترونیک', 'هوش مصنوعی', 'محصولات ابری SaaS']
};

export const MOCK_JOBS: Job[] = [
  {
    id: 'job-1',
    title: 'توسعه‌دهنده ارشد فرانت‌اند (Senior Frontend Developer)',
    company: 'دیجی‌کالا (Digikala)',
    location: 'تهران - ونک',
    city: 'تهران',
    workStyle: 'hybrid',
    seniority: 'senior',
    salaryRange: '۶۰ تا ۸۵ میلیون تومان',
    description: 'ما در دیجی‌کالا به دنبال یک مهندس ارشد فرانت‌اند باتجربه هستیم تا به تیم توسعه پلتفرم بازارگاه (Marketplace) بپیوندد و تجربه کاربری میلیون‌ها کاربر روزانه را بهبود بخشد.',
    requirements: [
      'تسلط عمیق به React و Next.js و اصول معماری کامپوننت',
      'تسلط کامل به TypeScript و ابزارهای State Management نظیر Zustand یا Redux',
      'تجربه بهینه‌سازی عملکرد (Core Web Vitals، Lazy Loading، SSR/SSG)',
      'آشنایی با تست‌نویسی خودکار (Jest / React Testing Library)',
      'روحیه کارتیمی، منتورشیپ مهندسان جونیور و ارتباط موثر'
    ],
    benefits: [
      'بیمه تکمیلی SOS پوشش کامل',
      'ساعت کاری منعطف و امکان دورکاری ۲ روز در هفته',
      'بودجه سالانه آموزش و دوره‌های تخصصی',
      'پاداش فصلی مبتنی بر عملکرد OKR'
    ],
    postedAt: '۲ روز پیش'
  },
  {
    id: 'job-2',
    title: 'مهندس بک‌اند پایتون / FastAPI (Python Backend Engineer)',
    company: 'اسنپ (Snapp!)',
    location: 'تهران - جردن',
    city: 'تهران',
    workStyle: 'onsite',
    seniority: 'senior',
    salaryRange: '۶۵ تا ۹۰ میلیون تومان',
    description: 'تیم زیرساخت اسنپ به دنبال یک توسعه‌دهنده مسلط به Python و فریم‌ورک‌های مدرن نظیر FastAPI و آسنکرون برای پردازش میلیون‌ها درخواست مکانی همزمان است.',
    requirements: [
      'حداقل ۴ سال تجربه عملی با Python و تسلط بر FastAPI یا Django',
      'تسلط به پایگاه‌های داده PostgreSQL و Redis و مفاهیم کشینگ توزیع‌شده',
      'تجربه کار با سیستم‌های پیام‌رسان مانند RabbitMQ یا Apache Kafka',
      'آشنایی با Docker، Kubernetes و اصول معماری میکروسرویس'
    ],
    benefits: [
      'پاداش عملکرد و سهام تشویقی',
      'امکانات ورزشی و ناهار روزانه باکیفیت',
      'بیمه تکمیلی ممتاز و وام سازمانی'
    ],
    postedAt: 'امروز'
  },
  {
    id: 'job-3',
    title: 'طراح ارشد محصول و رابط کاربری (Senior Product Designer - UI/UX)',
    company: 'کافه بازار (Bazaar)',
    location: 'تهران - سعادت‌آباد / تمام دورکاری',
    city: 'دورکاری',
    workStyle: 'remote',
    seniority: 'senior',
    salaryRange: '۵۰ تا ۷۰ میلیون تومان',
    description: 'طراحی تجربیات تعاملی ساده، زیبا و کاربرپسند برای بزرگ‌ترین فروشگاه اپلیکیشن اندرویدی در منطقه با تکیه بر داده‌های رفتاری کاربران.',
    requirements: [
      'حداقل ۴ سال سابقه در طراحی محصولات دیجیتال و پرتفولیوی قوی',
      'تسلط حرفه‌ای به Figma، Auto Layout، Variants و ساخت Design System مقیاس‌پذیر',
      'تجربه هدایت تست‌های کاربردپذیری (Usability Testing) و تحلیل داده‌های محصولی',
      'درک اصول فنی فرانت‌اند و محدودیت‌های پیاده‌سازی در وب و موبایل'
    ],
    benefits: [
      'امکان کار کاملاً ریموت از هر کجای ایران',
      'کمک‌هزینه تجهیز میز کار خانگی',
      'بیمه درمان و بسته‌های سلامت روان'
    ],
    postedAt: '۳ روز پیش'
  },
  {
    id: 'job-4',
    title: 'دانشمند داده و مهندس هوش مصنوعی (Data Scientist / AI)',
    company: 'تپسی (Tapsi)',
    location: 'تهران - مرزداران',
    city: 'تهران',
    workStyle: 'hybrid',
    seniority: 'mid',
    salaryRange: '۵۵ تا ۷۵ میلیون تومان',
    description: 'توسعه مدل‌های هوشمند یادگیری ماشین برای تخمین تقاضا، قیمت‌گذاری پویا و بهینه‌سازی الگوریتم‌های مسیریابی و جفت‌سازی سفیران.',
    requirements: [
      'تسلط به Python و کتابخانه‌های NumPy, Pandas, Scikit-learn و PyTorch',
      'درک عمیق از آمار کاربردی، تحلیل سری‌های زمانی و آزمون‌های A/B',
      'تجربه کار با پایگاه داده‌های SQL و موتورهای پردازش کلان‌داده',
      'آشنایی با متدهای استقرار مدل‌ها (MLOps)'
    ],
    benefits: [
      'ساعت کاری منعطف',
      'محیط علمی پویا با دسترسی به دیتاست‌های عظیم در ابعاد ملی',
      'بیمه تکمیلی و کمک‌هزینه آموزش'
    ],
    postedAt: '۴ روز پیش'
  },
  {
    id: 'job-5',
    title: 'مهندس دواپس و زیرساخت ابری (DevOps & Cloud Engineer)',
    company: 'دیوار (Divar)',
    location: 'تهران - شهرک غرب',
    city: 'تهران',
    workStyle: 'hybrid',
    seniority: 'senior',
    salaryRange: '۷۰ تا ۱۰۰ میلیون تومان',
    description: 'مدیریت و ارتقای کلاسترهای کوبرنتیز با ترافیک بسیار بالا، خودکارسازی خطوط استقرار CI/CD و پایدارسازی سرویس‌های زیرساختی دیوار.',
    requirements: [
      'تسلط عملیاتی به Kubernetes, Helm و لینوکس در سطح پیشرفته',
      'تجربه راه‌اندازی و نگهداری خطوط CI/CD با GitLab CI یا ArgoCD',
      'تسلط به ابزارهای مانیتورینگ مانند Prometheus, Grafana, Thanos',
      'تسلط به اصول امنیت زیرساخت و Infrastructure as Code با Terraform'
    ],
    benefits: [
      'حقوق رقابتی و پاداش شش‌ماهه',
      'برنامه دورکاری منعطف (۲ روز حضوری)',
      'تجهیزات مدرن سخت‌افزاری شامل لپ‌تاپ‌های مک‌بوک پرو'
    ],
    postedAt: '۱ روز پیش'
  },
  {
    id: 'job-6',
    title: 'مدیر محصول رشد و پلتفرم (Product Manager - Growth)',
    company: 'علی‌بابا (Alibaba Travels)',
    location: 'تهران - کارخانه نوآوری آزادی',
    city: 'تهران',
    workStyle: 'hybrid',
    seniority: 'senior',
    salaryRange: '۵۵ تا ۸۰ میلیون تومان',
    description: 'تعیین استراتژی چرخه حیات کاربر، افزایش وفاداری و بهینه‌سازی فانل خرید پرواز و هتل با همکاری مستقیم تیم‌های مارکتینگ، تک و دیتا.',
    requirements: [
      'حداقل ۳ سال سابقه مدیریت محصول در شرکت‌های مقیاس‌بالای فناوری',
      'تسلط به طراحی آزمایش‌های سریع Growth Hacking و متریک‌های ریتنشن',
      'توانایی عمیق در تبدیل نیازمندی‌های کسب‌وکار به بک‌لاگ محصول',
      'مهارت‌های ارتباطی و رهبری بدون اعمال اقتدار مستقیم'
    ],
    benefits: [
      'تخفیف‌های ویژه سازمانی در خرید تور و بلیط سفر',
      'برنامه‌های رفاهی ورزشی و روانشناختی',
      'محیط باز و استارتاپی کارخانه نوآوری'
    ],
    postedAt: '۵ روز پیش'
  }
];

export const MOCK_MATCH_RESULTS: Record<string, MatchAnalysis> = {
  'job-1': {
    jobId: 'job-1',
    score: 92,
    summary: 'تطابق فوق‌العاده بالا با نقش توسعه‌دهنده ارشد فرانت‌اند در دیجی‌کالا. تسلط شما بر React، Next.js، TypeScript و سابقه بهینه‌سازی عملکرد دقیقاً پاسخگوی نیازمندی‌های کلیدی این جایگاه شغلی است.',
    strengths: [
      'تطابق کامل در پشته فناوری (React + Next.js + TypeScript)',
      'سابقه مستند در افزایش ۴۰٪ عملکرد و Core Web Vitals که مستقیماً در آگهی آمده است',
      'سابقه منتورشیپ و رهبری تیم فرانت‌اند متناسب با لول Senior',
      'تجربه تست‌نویسی با Jest و React Testing Library'
    ],
    gaps: [
      'در رزومه فعلی اشاره مستقیمی به Zustand نشده است (اگرچه با Redux Toolkit و مدیریت استیت آشنایی دارید)',
      'معیارهای مقیاس بازارگاه (Marketplace) و حجم ترافیک بالا در شرح تجربیات برجسته‌تر شود'
    ],
    agentReasoning: 'ایجنت با تطبیق بیش از ۱۵ پارامتر تحلیلی تشخیص داد که سوابق کاری امیرحسین بیش از ۹۲٪ همپوشانی فنی و لولی با موقعیت دیجی‌کالا دارد. شکاف‌های موجود با بازنویسی هوشمند بولت‌پوینت‌ها و تزریق کلیدواژه‌های Zustand و SSR Caching کاملاً برطرف خواهد شد.',
    skillOverlap: {
      matched: ['React', 'Next.js', 'TypeScript', 'Tailwind CSS', 'Redux Toolkit', 'Web Performance', 'Jest & Testing Library'],
      missing: ['Zustand', 'Micro-frontends']
    },
    recommendedActions: [
      'برجسته‌سازی متریک افزایش ۴۰ درصدی سرعت در بالای رزومه',
      'افزودن نام فریم‌ورک Next.js App Router و متدهای بهینه‌سازی سئو تکنیکال',
      'سفارشی‌سازی خلاصه رزومه (Executive Summary) با تمرکز بر پلتفرم‌های پرتردد'
    ]
  },
  'job-2': {
    jobId: 'job-2',
    score: 42,
    summary: 'تناسب پایین به دلیل تفاوت چشمگیر حوزه تخصصی. این موقعیت نیازمند تخصص عمیق در بک‌اند پایتون و توزیع بار است، در حالی که تمرکز پروفایل شما بر فرانت‌اند مدرن وب است.',
    strengths: [
      'درک معماری کلاینت-سرور و تعامل با اندپوینت‌های REST',
      'آشنایی با ابزارهای همکاری تیمی و Git'
    ],
    gaps: [
      'عدم وجود سابقه تخصصی با Python و FastAPI',
      'نبود تجربه با کلاسترهای دیتابیس PostgreSQL و سیستم‌های پیام Kafka/RabbitMQ'
    ],
    agentReasoning: 'ایجنت پیشنهاد می‌کند در صورت علاقه به این نقش، ابتدا یک پروژه عملی با FastAPI و دیتابیس رابطه‌ای در گیت‌هاب قرار دهید، یا برای موقعیت‌های Fullstack اقدام فرمایید.',
    skillOverlap: {
      matched: ['REST APIs', 'Git & GitHub'],
      missing: ['Python', 'FastAPI', 'PostgreSQL', 'Redis', 'RabbitMQ', 'Docker']
    },
    recommendedActions: [
      'پیشنهاد می‌شود به جای این نقش، بر روی موقعیت‌های Full-stack یا Frontend تمرکز نمایید.'
    ]
  },
  'job-3': {
    jobId: 'job-3',
    score: 68,
    summary: 'تناسب متوسط تا خوب. اگرچه شما توسعه‌دهنده هستید، سابقه شما در ساخت Design System و تسلط به تعامل با طراحان، ارزش افزوده‌ای عالی برای همکاری با تیم محصول بازار ایجاد می‌کند.',
    strengths: [
      'تسلط بر ساخت سیستم‌های طراحی (Design System) و پیاده‌سازی Figma-to-Code',
      'درک بالای تجربه کاربری، ریسپانسیو و تایپوگرافی فارسی',
      'تطابق تمایل دورکاری در ترجیحات شغلی شما'
    ],
    gaps: [
      'نداشتن نمونه کار متمرکز در فیگما و فرایند دیزاین ریسرچ رسمی',
      'عدم درج پروژه‌های پژوهش کاربر و وایرفریمینگ در رزومه'
    ],
    agentReasoning: 'با پررنگ کردن تجربیات همکاری نزدیک با تیم UX و ارائه مستندات دیزاین سیستم، شانس قبولی در مرحله اولیه مصاحبه به شدت افزایش می‌یابد.',
    skillOverlap: {
      matched: ['Responsive Design', 'Design Systems', 'Figma to Code', 'User Experience'],
      missing: ['User Research', 'Wireframing', 'Prototyping in Figma']
    },
    recommendedActions: [
      'اضافه کردن بخش مهارت‌های دیزاین سیستم و ارجاع به استوری‌بوک پروژه‌ها'
    ]
  },
  'job-4': {
    jobId: 'job-4',
    score: 38,
    summary: 'شکاف فنی عمده در زمینه یادگیری ماشین و ریاضیات داده.',
    strengths: ['تجربه پیاده‌سازی بصری‌سازی داده‌ها با کتابخانه‌های چارت فرانت‌اند'],
    gaps: ['عدم سابقه در یادگیری ماشین، پایتون علمی و آمار پیشرفته'],
    agentReasoning: 'این آگهی به مدل‌سازی‌های پیچیده ریاضی و الگوریتم‌های قیمت‌گذاری اختصاص دارد.',
    skillOverlap: {
      matched: ['Data Visualization'],
      missing: ['Python', 'Scikit-learn', 'PyTorch', 'A/B Testing', 'Statistics']
    },
    recommendedActions: ['بررسی موقعیت‌های مرتبط با توسعه داشبوردهای هوش مصنوعی به عنوان فرانت‌اند']
  },
  'job-5': {
    jobId: 'job-5',
    score: 55,
    summary: 'تناسب متوسط. آشنایی با فرایندهای بیلد و CI/CD فرانت‌اند وجود دارد، اما برای نقش ارشد دوآپس نیاز به مهارت‌های زیرساختی کوبرنتیز است.',
    strengths: ['سابقه راه‌اندازی پایپ‌لاین‌های بیلد و دیپلوی خودکار وب'],
    gaps: ['نیازمند دانش پیشرفته کلاسترهای Kubernetes و زیرساخت کد (IaC)'],
    agentReasoning: 'مناسب برای مهندسی وب با علاقه به ارتقای استک دپلوی.',
    skillOverlap: {
      matched: ['Git & GitHub', 'CI/CD Pipelines'],
      missing: ['Kubernetes', 'Helm', 'Terraform', 'Prometheus', 'Linux Administration']
    },
    recommendedActions: ['تمرکز بر نقش‌های Fullstack DevOps یا پلتفرم فرانت‌اند']
  },
  'job-6': {
    jobId: 'job-6',
    score: 64,
    summary: 'تناسب قابل‌توجه در بخش تکنیکال محصول به دلیل سابقه شما در بهبود متریک‌های نرخ تبدیل و سرعت صفحه.',
    strengths: ['درک متریک‌های تبدیل کسب‌وکار (افزایش ۱۸ درصدی خرید)', 'مهارت رهبری تیم'],
    gaps: ['عدم عنوان شغلی رسمی به عنوان مدیر محصول (Product Manager)'],
    agentReasoning: 'سابقه هدایت تیم و بهبود کانورژن امتیاز مناسبی برای انتقال به حوزه مدیریت محصول فنی به حساب می‌آید.',
    skillOverlap: {
      matched: ['Team Leadership', 'Conversion Rate Optimization', 'Agile/Scrum'],
      missing: ['Product Roadmapping', 'PRD Writing', 'Retention Analysis']
    },
    recommendedActions: ['بازنویسی تجربیات با تأکید بر دستاوردهای مالی و کاربری محصول']
  }
};

export const MOCK_TAILORED_RESUMES: Record<string, TailoredResume> = {
  'job-1': {
    id: 'tailored-job-1',
    jobId: 'job-1',
    jobTitle: 'توسعه‌دهنده ارشد فرانت‌اند',
    company: 'دیجی‌کالا',
    createdAt: 'امروز، ۱۰:۴۵',
    updatedAt: 'امروز، ۱۰:۴۸',
    content: {
      headline: 'توسعه‌دهنده ارشد فرانت‌اند | متخصص React، Next.js، عملکرد وب و معماری مقیاس‌پذیر',
      summary: 'مهندس ارشد فرانت‌اند با بیش از ۵ سال تجربه متمرکز بر ساخت پلتفرم‌های پرتردد تجارت الکترونیک و ابری. مسلط به Next.js، TypeScript و متدهای مدرن مدیریت استیت (Zustand و Redux). دارای سابقه ثبت‌شده در بهبود ۴۰ درصدی شاخص‌های Core Web Vitals و استقرار Design System سازمانی در مقیاس میلیون‌ها کاربر فعال ماهانه.',
      highlightedSkills: [
        'React & Next.js (SSR / SSG / ISR)',
        'TypeScript پیشرفته',
        'Zustand & Redux Toolkit',
        'بهینه‌سازی Core Web Vitals & Web Performance',
        'طراحی Design System مقیاس‌پذیر',
        'تست‌نویسی با Jest & Testing Library',
        'Tailwind CSS & معماری ماژولار UI'
      ],
      tailoredExperiences: [
        {
          role: 'توسعه‌دهنده ارشد فرانت‌اند و لید تیم رابط کاربری',
          company: 'راهکارهای نوین ابری (کلودفلایر پارس)',
          period: '۱۴۰۱ - اکنون (۲ سال)',
          bulletPoints: [
            {
              text: 'رهبری تیم ۴ نفره فرانت‌اند در مهاجرت داشبورد پرترافیک به Next.js و پیاده‌سازی استراتژی‌های کشینگ هوشمند SSR، منجر به کاهش ۴۰٪ زمان بارگذاری اولیه (LCP/FCP).',
              isModified: true,
              keywordsAdded: ['Next.js SSR', 'Core Web Vitals', 'پرترافیک']
            },
            {
              text: 'طراحی، توسعه و مستندسازی سیستم طراحی یکپارچه (Design System) با TypeScript و Tailwind CSS جهت تضمین انطباق بصری در تمامی ماژول‌های بازارگاه و محصول.',
              isModified: true,
              keywordsAdded: ['TypeScript', 'Design System', 'بازارگاه']
            },
            {
              text: 'پیاده‌سازی تست‌های خودکار یکپارچه با Jest و React Testing Library که پوشش کدهای بحرانی پرداخت و ثبت سفارش را به بالای ۸۰٪ رساند.',
              isModified: true,
              keywordsAdded: ['Jest', 'React Testing Library', 'سفارشات']
            }
          ]
        },
        {
          role: 'مهندس فرانت‌اند محصولات دیجیتال',
          company: 'فناوران داده رایان',
          period: '۱۳۹۸ - ۱۴۰۱ (۳ سال)',
          bulletPoints: [
            {
              text: 'بازطراحی فرایند قیف فروش و سبد خرید در مقیاس هزاران تراکنش روزانه که موجب جهش ۱۸ درصدی در نرخ تبدیل (Conversion Rate) پرداخت گردید.',
              isModified: true,
              keywordsAdded: ['نرخ تبدیل', 'تراکنش روزانه']
            },
            {
              text: 'مدیریت بهینه وضعیت برنامه‌ها با بهره‌گیری از Zustand و Redux Toolkit در کنار بیش از ۳۰ سرویس REST API با کش‌سازی هوشمند سمت کلاینت.',
              isModified: true,
              keywordsAdded: ['Zustand', 'Redux Toolkit', 'REST API']
            }
          ]
        }
      ],
      addedKeywords: ['Next.js SSR', 'Zustand', 'Core Web Vitals', 'Marketplace Scale', 'Jest Testing', 'Design System'],
      coverLetter: `تیم محترم جذب و استخدام دیجی‌کالا،

با سلام و احترام،

با اشتیاق فراوان، رزومه و سوابق کاری خود را برای موقعیت «توسعه‌دهنده ارشد فرانت‌اند» در پلتفرم بازارگاه دیجی‌کالا ارسال می‌نمایم. در طول ۵ سال گذشته، تمرکز اصلی من بر خلق تجربیات وب سریع، پایدار و با دسترسی‌پذیری بالا با بهره‌گیری از مدرن‌ترین ابزارهای فرانت‌اند بوده است.

در آخرین تجربه حرفه‌ای‌ام به عنوان توسعه‌دهنده ارشد در راهکارهای نوین ابری، موفق شدم با اعمال تکنیک‌های بهینه‌سازی عملکرد در Next.js و TypeScript، سرعت بارگذاری صفحات را تا ۴۰٪ ارتقا داده و Design System سازمانی تیم را پایه‌گذاری کنم. این تجارب همراه با سابقه مستقیم در افزایش ۱۸ درصدی نرخ تکمیل خرید در پلتفرم فروشگاهی، من را مشتاق کرده است تا مهارت‌هایم را در خدمت بهبود تجربه میلیون‌ها هم‌وطن در دیجی‌کالا قرار دهم.

از فرصت ارزیابی این درخواست سپاسگزارم و بسیار علاقه‌مندم در جلسه‌ای حضوری یا آنلاین، در خصوص چگونگی ارزش‌آفرینی در تیم فرانت‌اند شما گفتگو نمایم.

با آرزوی موفقیت،
امیرحسین رضایی`,
      version: 1,
      generationNote: 'رزومه اولیه بر پایه کلیدواژه‌های آگهی دیجی‌کالا و سوابق فرانت‌اند بهینه‌سازی شد.'
    },
    versions: []
  }
};

export const INITIAL_AGENT_STEPS: AgentLogStep[] = [
  {
    id: 'step-1',
    action: 'بارگذاری و استخراج پروفایل',
    detail: 'فایل رزومه با موفقیت دریافت و مهارت‌های کلیدی، سوابق و تحصیلات استخراج گردید.',
    timestamp: '۱۰:۳۰:۱۲',
    status: 'done',
    category: 'profile'
  },
  {
    id: 'step-2',
    action: 'تثبیت ترجیحات و معیارها',
    detail: 'نقش توسعه‌دهنده ارشد، مدل کاری ترکیبی و بازه حقوقی ۶۰+ میلیون تومان ثبت شد.',
    timestamp: '۱۰:۳۲:۰۵',
    status: 'done',
    category: 'profile'
  },
  {
    id: 'step-3',
    action: 'اسکن و غربالگری آگهی‌های فعال',
    detail: '۶ آگهی معتبر فناوری در تهران و موقعیت‌های ریموت جهت ارزیابی آماده شدند.',
    timestamp: '۱۰:۳۵:۴۰',
    status: 'done',
    category: 'analysis'
  },
  {
    id: 'step-4',
    action: 'محاسبه تناسب شغلی با هوش مصنوعی',
    detail: 'تطابق عمیق آگهی توسعه‌دهنده ارشد دیجی‌کالا با نمره ۹۲٪ تأیید شد.',
    timestamp: '۱۰:۴۵:۱۹',
    status: 'done',
    category: 'matching'
  },
  {
    id: 'step-5',
    action: 'سفارشی‌سازی رزومه اختصاصی',
    detail: 'تزریق کلیدواژه‌های Next.js SSR، Zustand و متمرکزسازی دستاوردها برای موقعیت دیجی‌کالا انجام پذیرفت.',
    timestamp: '۱۰:۴۸:۲۲',
    status: 'done',
    category: 'tailoring'
  }
];
