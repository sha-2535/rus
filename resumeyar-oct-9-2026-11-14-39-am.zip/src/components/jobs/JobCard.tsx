import React from 'react';
import {
  MapPin,
  Building2,
  DollarSign,
  ArrowLeft,
  Sparkles,
  CheckCircle,
  Briefcase
} from 'lucide-react';
import { Job, MatchAnalysis } from '../../types';
import { GlassCard } from '../common/GlassCard';
import { GradientButton } from '../common/GradientButton';
import { MatchScoreRing } from '../common/MatchScoreRing';

interface JobCardProps {
  job: Job;
  match?: MatchAnalysis;
  isMatching?: boolean;
  onAnalyzeMatch: (jobId: string) => void;
  onViewDetails: (jobId: string) => void;
  onTailorResume: (jobId: string) => void;
}

export const JobCard: React.FC<JobCardProps> = ({
  job,
  match,
  isMatching = false,
  onAnalyzeMatch,
  onViewDetails,
  onTailorResume
}) => {
  const getWorkStyleBadge = (style: Job['workStyle']) => {
    switch (style) {
      case 'remote':
        return 'دورکاری کامل';
      case 'hybrid':
        return 'هیبرید (ترکیبی)';
      case 'onsite':
        return 'حضوری';
    }
  };

  const getSeniorityLabel = (seniority: Job['seniority']) => {
    switch (seniority) {
      case 'junior':
        return 'جونیور (مبتدی)';
      case 'mid':
        return 'میدلول (متوسط)';
      case 'senior':
        return 'سنیور (ارشد)';
      case 'lead':
        return 'لید / مدیر فنی';
    }
  };

  return (
    <GlassCard
      hoverEffect
      elevation="medium"
      className="p-5 md:p-6 flex flex-col justify-between transition-all"
    >
      {/* Top Details & Header */}
      <div>
        <div className="flex items-start justify-between gap-4 mb-3">
          <div className="flex-1 min-w-0">
            <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white truncate">
              {job.title}
            </h3>
            {/* Metadata line with typographic separators (anti-slop rule) */}
            <div className="flex flex-wrap items-center gap-2 mt-1 text-xs text-slate-500 dark:text-slate-400">
              <span className="font-semibold text-slate-700 dark:text-slate-200">
                {job.company}
              </span>
              <span aria-hidden="true">·</span>
              <span className="flex items-center gap-1">
                <MapPin className="w-3 h-3 text-slate-400" />
                {job.location}
              </span>
              <span aria-hidden="true">·</span>
              <span>{getWorkStyleBadge(job.workStyle)}</span>
              <span aria-hidden="true">·</span>
              <span>{getSeniorityLabel(job.seniority)}</span>
            </div>
          </div>

          {/* Salary info if available */}
          {job.salaryRange && (
            <div className="text-left shrink-0 hidden sm:block">
              <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 font-mono tabular-nums">
                {job.salaryRange}
              </span>
            </div>
          )}
        </div>

        {/* Short description */}
        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 line-clamp-2 leading-relaxed mb-4">
          {job.description}
        </p>

        {/* Requirements chips */}
        <div className="flex flex-wrap gap-1.5 mb-4">
          {job.requirements.slice(0, 3).map((req, idx) => (
            <span
              key={idx}
              className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200/60 dark:border-slate-700/60"
            >
              {req}
            </span>
          ))}
          {job.requirements.length > 3 && (
            <span className="text-[11px] px-2 py-1 text-slate-400">
              +{job.requirements.length - 3} مورد دیگر
            </span>
          )}
        </div>
      </div>

      {/* Match Section or Skeleton Loader */}
      <div className="pt-4 border-t border-slate-200/60 dark:border-slate-800/60">
        {isMatching ? (
          /* Skeleton Loader state */
          <div className="flex items-center gap-4 py-2 animate-pulse">
            <div className="w-14 h-14 rounded-full bg-slate-200 dark:bg-slate-800 shrink-0" />
            <div className="flex-1 space-y-2">
              <div className="h-3.5 bg-slate-200 dark:bg-slate-800 rounded w-3/4" />
              <div className="h-2.5 bg-slate-200 dark:bg-slate-800 rounded w-1/2" />
            </div>
          </div>
        ) : match ? (
          /* Matched Result with Score Ring and explanation */
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 py-1">
            <div className="flex items-center gap-3.5">
              <MatchScoreRing score={match.score} size="md" showLabel />
              <div className="space-y-0.5">
                <span className="text-xs font-bold text-slate-900 dark:text-white block">
                  دلیل ارزیابی هوش مصنوعی:
                </span>
                <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-2 leading-relaxed max-w-sm">
                  {match.summary}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
              <button
                onClick={() => onViewDetails(job.id)}
                className="text-xs font-medium text-slate-600 dark:text-slate-300 hover:text-violet-600 px-3 py-2 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                تحلیل جامع
              </button>
              <GradientButton
                size="sm"
                variant="primary"
                onClick={() => onTailorResume(job.id)}
                leftIcon={<ArrowLeft className="w-3.5 h-3.5" />}
              >
                رزومه اختصاصی بساز
              </GradientButton>
            </div>
          </div>
        ) : (
          /* Unmatched State: Call to Action to Match */
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs text-slate-400">
              هنوز تناسب سنجیده نشده است
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => onViewDetails(job.id)}
                className="text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 px-3 py-1.5 rounded-xl cursor-pointer"
              >
                مشاهده آگهی
              </button>
              <GradientButton
                size="sm"
                variant="glass"
                onClick={() => onAnalyzeMatch(job.id)}
                rightIcon={<Sparkles className="w-3.5 h-3.5 text-violet-500" />}
              >
                تحلیل تناسب با هوش مصنوعی
              </GradientButton>
            </div>
          </div>
        )}
      </div>
    </GlassCard>
  );
};
