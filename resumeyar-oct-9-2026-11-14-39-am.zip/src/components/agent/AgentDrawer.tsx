import React from 'react';
import {
  Sparkles,
  X,
  CheckCircle2,
  Clock,
  Loader2,
  AlertCircle,
  Cpu,
  Brain,
  FileSearch,
  Wand2,
  MessageSquare
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { AgentLogStep } from '../../types';

export const AgentDrawer: React.FC = () => {
  const { agentSteps, isAgentDrawerOpen, setAgentDrawerOpen } = useApp();

  const getCategoryIcon = (category: AgentLogStep['category']) => {
    switch (category) {
      case 'profile':
        return <FileSearch className="w-4 h-4 text-sky-500" />;
      case 'matching':
        return <Brain className="w-4 h-4 text-violet-500" />;
      case 'tailoring':
        return <Wand2 className="w-4 h-4 text-fuchsia-500" />;
      case 'feedback':
        return <MessageSquare className="w-4 h-4 text-amber-500" />;
      default:
        return <Cpu className="w-4 h-4 text-indigo-500" />;
    }
  };

  const getStatusBadge = (status: AgentLogStep['status']) => {
    switch (status) {
      case 'done':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-medium text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full">
            <CheckCircle2 className="w-3 h-3" />
            انجام شد
          </span>
        );
      case 'running':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-medium text-violet-600 dark:text-violet-400 bg-violet-500/10 px-2 py-0.5 rounded-full animate-pulse">
            <Loader2 className="w-3 h-3 animate-spin" />
            در حال پردازش
          </span>
        );
      case 'failed':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-medium text-rose-600 dark:text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded-full">
            <AlertCircle className="w-3 h-3" />
            ناموفق
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-500 bg-slate-500/10 px-2 py-0.5 rounded-full">
            <Clock className="w-3 h-3" />
            در انتظار
          </span>
        );
    }
  };

  if (!isAgentDrawerOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/40 backdrop-blur-sm transition-opacity">
      {/* Backdrop click to close */}
      <div
        className="absolute inset-0"
        onClick={() => setAgentDrawerOpen(false)}
        aria-hidden="true"
      />

      {/* Drawer Container (RTL: slide in from left or right) */}
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <aside
          role="dialog"
          aria-modal="true"
          aria-labelledby="agent-panel-title"
          className="w-screen max-w-md bg-white/95 dark:bg-slate-900/95 backdrop-blur-2xl border-l border-white/40 dark:border-white/10 shadow-2xl flex flex-col"
        >
          {/* Header */}
          <div className="p-5 border-b border-slate-200/80 dark:border-slate-800/80 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-2xl bg-gradient-to-br from-indigo-500 to-fuchsia-600 flex items-center justify-center text-white shadow-md shadow-violet-500/20">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <h2 id="agent-panel-title" className="text-sm font-bold text-slate-900 dark:text-white">
                  فعالیت‌های زنده ایجنت هوشمند
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  زنجیرهٔ استدلال، تطبیق و بهینه‌سازی زنده رزومه
                </p>
              </div>
            </div>

            <button
              onClick={() => setAgentDrawerOpen(false)}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              aria-label="بستن پنل ایجنت"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Subheader status bar */}
          <div className="px-5 py-3 bg-slate-50/70 dark:bg-slate-800/40 border-b border-slate-200/60 dark:border-slate-800/60 flex items-center justify-between text-xs text-slate-600 dark:text-slate-400">
            <span>تعداد کل مراحل ثبت‌شده: {agentSteps.length} گام</span>
            <span className="font-mono tabular-nums text-violet-600 dark:text-violet-400 font-semibold">
              Live Agent Execution
            </span>
          </div>

          {/* Steps Timeline Content */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {agentSteps.map((step, idx) => (
              <div
                key={step.id}
                className="relative pl-0 pr-6 border-r-2 border-violet-200 dark:border-violet-900/50 last:border-r-transparent group"
              >
                {/* Node icon */}
                <div className="absolute -right-[17px] top-0 w-8 h-8 rounded-xl bg-white dark:bg-slate-800 border-2 border-violet-400 dark:border-violet-600 flex items-center justify-center shadow-sm">
                  {getCategoryIcon(step.category)}
                </div>

                {/* Card Container */}
                <div className="bg-white/80 dark:bg-slate-800/60 rounded-2xl p-3.5 border border-slate-200/60 dark:border-slate-700/60 shadow-sm transition-all hover:border-violet-300 dark:hover:border-violet-500/50">
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <span className="text-xs font-bold text-slate-900 dark:text-white">
                      {step.action}
                    </span>
                    {getStatusBadge(step.status)}
                  </div>

                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    {step.detail}
                  </p>

                  <div className="mt-2.5 flex items-center justify-between text-[11px] text-slate-400 font-mono tabular-nums">
                    <span>زمان ثبت: {step.timestamp}</span>
                    <span className="text-[10px] uppercase font-sans text-violet-500 dark:text-violet-400">
                      #{idx + 1}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Footer note */}
          <div className="p-4 border-t border-slate-200/80 dark:border-slate-800/80 bg-slate-50/50 dark:bg-slate-900/50 text-center text-xs text-slate-500 dark:text-slate-400">
            ایجنت به شکل پیوسته وضعیت رزومه و تعامل با آگهی‌ها را تحلیل می‌کند.
          </div>
        </aside>
      </div>
    </div>
  );
};
