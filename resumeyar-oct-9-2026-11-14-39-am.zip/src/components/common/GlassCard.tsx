import React from 'react';

interface GlassCardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  className?: string;
  hoverEffect?: boolean;
  elevation?: 'flat' | 'low' | 'medium' | 'high';
  bordered?: boolean;
  glow?: 'none' | 'violet' | 'indigo' | 'fuchsia';
}

export const GlassCard: React.FC<GlassCardProps> = ({
  children,
  className = '',
  hoverEffect = false,
  elevation = 'medium',
  bordered = true,
  glow = 'none',
  ...props
}) => {
  const elevationStyles = {
    flat: 'shadow-none',
    low: 'shadow-sm dark:shadow-none',
    medium: 'shadow-[0_8px_30px_rgb(0,0,0,0.04)] dark:shadow-[0_8px_30px_rgb(0,0,0,0.25)]',
    high: 'shadow-[0_20px_50px_rgba(8,_112,_184,_0.07)] dark:shadow-[0_20px_50px_rgba(0,0,0,0.4)]'
  };

  const glowStyles = {
    none: '',
    violet: 'hover:shadow-[0_0_30px_rgba(139,92,246,0.18)] dark:hover:shadow-[0_0_35px_rgba(139,92,246,0.25)]',
    indigo: 'hover:shadow-[0_0_30px_rgba(99,102,241,0.18)] dark:hover:shadow-[0_0_35px_rgba(99,102,241,0.25)]',
    fuchsia: 'hover:shadow-[0_0_30px_rgba(217,70,239,0.18)] dark:hover:shadow-[0_0_35px_rgba(217,70,239,0.25)]'
  };

  return (
    <div
      className={`
        relative rounded-3xl backdrop-blur-xl transition-all duration-300
        bg-white/80 dark:bg-slate-900/70
        ${bordered ? 'border border-white/60 dark:border-white/10' : ''}
        ${elevationStyles[elevation]}
        ${hoverEffect ? 'hover:-translate-y-1 hover:border-violet-300/60 dark:hover:border-violet-500/40' : ''}
        ${glowStyles[glow]}
        ${className}
      `}
      {...props}
    >
      {/* Subtle inner top highlight */}
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/50 dark:via-white/10 to-transparent pointer-events-none rounded-t-3xl" />
      {children}
    </div>
  );
};
