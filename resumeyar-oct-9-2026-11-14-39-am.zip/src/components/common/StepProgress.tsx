import React from 'react';
import { Check } from 'lucide-react';

interface WizardStepsProps {
  currentStep: number;
  totalSteps: number;
  steps: { label: string; description?: string }[];
  onStepClick?: (step: number) => void;
  className?: string;
}

export const StepProgress: React.FC<WizardStepsProps> = ({
  currentStep,
  totalSteps,
  steps,
  onStepClick,
  className = ''
}) => {
  return (
    <div className={`w-full ${className}`}>
      {/* Visual step indicator */}
      <div className="relative flex items-center justify-between">
        {/* Connecting track line */}
        <div className="absolute top-1/2 left-0 right-0 -translate-y-1/2 h-1 bg-slate-200 dark:bg-slate-800 -z-0" />
        {/* Active track line */}
        <div
          className="absolute top-1/2 right-0 -translate-y-1/2 h-1 bg-gradient-to-l from-indigo-600 via-violet-600 to-fuchsia-600 transition-all duration-500 -z-0"
          style={{
            width: `${((currentStep - 1) / (totalSteps - 1)) * 100}%`
          }}
        />

        {steps.map((step, index) => {
          const stepNum = index + 1;
          const isCompleted = stepNum < currentStep;
          const isCurrent = stepNum === currentStep;

          return (
            <button
              key={index}
              type="button"
              disabled={!onStepClick || stepNum > currentStep + 1}
              onClick={() => onStepClick && onStepClick(stepNum)}
              className="relative z-10 flex flex-col items-center group cursor-pointer disabled:cursor-default"
            >
              <div
                className={`
                  w-10 h-10 rounded-2xl flex items-center justify-center font-bold text-sm transition-all duration-300
                  ${
                    isCompleted
                      ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/20'
                      : isCurrent
                      ? 'bg-gradient-to-br from-indigo-600 via-violet-600 to-fuchsia-600 text-white shadow-lg shadow-violet-500/30 ring-4 ring-violet-200 dark:ring-violet-900/50 scale-105'
                      : 'bg-white dark:bg-slate-800 text-slate-400 dark:text-slate-500 border border-slate-200 dark:border-slate-700'
                  }
                `}
              >
                {isCompleted ? <Check className="w-5 h-5 stroke-[2.5]" /> : stepNum}
              </div>

              <div className="mt-2 text-center">
                <span
                  className={`text-xs block font-medium transition-colors ${
                    isCurrent
                      ? 'text-violet-600 dark:text-violet-400 font-bold'
                      : isCompleted
                      ? 'text-slate-700 dark:text-slate-300'
                      : 'text-slate-400 dark:text-slate-500'
                  }`}
                >
                  {step.label}
                </span>
                {step.description && (
                  <span className="text-[10px] text-slate-400 hidden sm:block">
                    {step.description}
                  </span>
                )}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};

interface ChecklistItem {
  id: string;
  label: string;
  isDone: boolean;
  actionText?: string;
  onAction?: () => void;
}

export const ChecklistProgress: React.FC<{
  items: ChecklistItem[];
  className?: string;
}> = ({ items, className = '' }) => {
  const completedCount = items.filter((i) => i.isDone).length;
  const progressPercent = Math.round((completedCount / items.length) * 100);

  return (
    <div className={`space-y-4 ${className}`}>
      {/* Progress Bar Header */}
      <div className="flex items-center justify-between text-xs font-medium">
        <span className="text-slate-600 dark:text-slate-400">
          مسیر آمادگی شغلی ({completedCount} از {items.length} مرحله تکمیل شده)
        </span>
        <span className="font-mono font-bold text-violet-600 dark:text-violet-400 tabular-nums">
          {progressPercent}٪
        </span>
      </div>

      {/* Progress track */}
      <div className="h-2 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
        <div
          className="h-full bg-gradient-to-l from-indigo-600 via-violet-600 to-fuchsia-600 transition-all duration-700 rounded-full"
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      {/* Items list */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2">
        {items.map((item) => (
          <div
            key={item.id}
            className={`
              flex items-center justify-between p-3 rounded-2xl border transition-all
              ${
                item.isDone
                  ? 'bg-emerald-500/5 border-emerald-500/20 text-emerald-900 dark:text-emerald-100'
                  : 'bg-white/50 dark:bg-slate-800/40 border-slate-200/60 dark:border-slate-800 text-slate-700 dark:text-slate-300'
              }
            `}
          >
            <div className="flex items-center gap-2.5">
              <div
                className={`w-6 h-6 rounded-lg flex items-center justify-center shrink-0 ${
                  item.isDone
                    ? 'bg-emerald-500 text-white'
                    : 'border border-slate-300 dark:border-slate-600 text-transparent'
                }`}
              >
                {item.isDone && <Check className="w-3.5 h-3.5 stroke-[3]" />}
              </div>
              <span className={`text-xs font-medium ${item.isDone ? 'line-through text-slate-500 dark:text-slate-400' : ''}`}>
                {item.label}
              </span>
            </div>

            {!item.isDone && item.actionText && (
              <button
                onClick={item.onAction}
                className="text-xs text-violet-600 dark:text-violet-400 font-semibold hover:underline cursor-pointer shrink-0"
              >
                {item.actionText}
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
