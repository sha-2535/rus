import React from 'react';

interface MatchScoreRingProps {
  score: number;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showLabel?: boolean;
  animate?: boolean;
  className?: string;
}

export const MatchScoreRing: React.FC<MatchScoreRingProps> = ({
  score,
  size = 'md',
  showLabel = true,
  className = ''
}) => {
  const clampedScore = Math.max(0, Math.min(100, Math.round(score)));

  // Color config according to spec: red <50, yellow 50-75, green >75
  let strokeColor = '#10B981'; // Green
  let textColor = 'text-emerald-600 dark:text-emerald-400';
  let badgeBg = 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300';
  let statusText = 'تطابق عالی';

  if (clampedScore < 50) {
    strokeColor = '#EF4444'; // Red
    textColor = 'text-rose-600 dark:text-rose-400';
    badgeBg = 'bg-rose-500/10 text-rose-700 dark:text-rose-300';
    statusText = 'نیاز به ارتقا';
  } else if (clampedScore <= 75) {
    strokeColor = '#F59E0B'; // Yellow / Amber
    textColor = 'text-amber-600 dark:text-amber-400';
    badgeBg = 'bg-amber-500/10 text-amber-700 dark:text-amber-300';
    statusText = 'تناسب متوسط';
  }

  const dimensions = {
    sm: { size: 48, strokeWidth: 4, textSize: 'text-xs font-bold' },
    md: { size: 76, strokeWidth: 6, textSize: 'text-base font-extrabold' },
    lg: { size: 110, strokeWidth: 8, textSize: 'text-2xl font-black' },
    xl: { size: 140, strokeWidth: 10, textSize: 'text-3xl font-black' }
  }[size];

  const radius = (dimensions.size - dimensions.strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (clampedScore / 100) * circumference;

  return (
    <div className={`flex flex-col items-center justify-center gap-1.5 ${className}`}>
      <div className="relative inline-flex items-center justify-center">
        <svg
          width={dimensions.size}
          height={dimensions.size}
          className="transform -rotate-90"
        >
          {/* Background Track */}
          <circle
            cx={dimensions.size / 2}
            cy={dimensions.size / 2}
            r={radius}
            stroke="currentColor"
            strokeWidth={dimensions.strokeWidth}
            fill="transparent"
            className="text-slate-200/70 dark:text-slate-800"
          />
          {/* Animated Progress Ring */}
          <circle
            cx={dimensions.size / 2}
            cy={dimensions.size / 2}
            r={radius}
            stroke={strokeColor}
            strokeWidth={dimensions.strokeWidth}
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            fill="transparent"
            className="transition-all duration-1000 ease-out"
          />
        </svg>

        {/* Center percentage value */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className={`${dimensions.textSize} ${textColor} tracking-tight font-mono tabular-nums`}>
            {clampedScore}٪
          </span>
        </div>
      </div>

      {showLabel && (
        <span className={`text-[11px] font-medium px-2 py-0.5 rounded-full ${badgeBg} whitespace-nowrap`}>
          {statusText}
        </span>
      )}
    </div>
  );
};
