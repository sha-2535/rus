import React from 'react';
import { Sun, Moon } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const ThemeToggle: React.FC<{ className?: string }> = ({ className = '' }) => {
  const { theme, toggleTheme } = useApp();

  return (
    <button
      onClick={toggleTheme}
      type="button"
      aria-label={theme === 'dark' ? 'تغییر به تم روشن' : 'تغییر به تم تاریک'}
      title={theme === 'dark' ? 'تغییر به تم روشن' : 'تغییر به تم تاریک'}
      className={`
        relative w-9 h-9 rounded-2xl flex items-center justify-center
        bg-white/70 dark:bg-slate-800/80 backdrop-blur-md
        border border-slate-200/80 dark:border-slate-700/80
        text-slate-700 dark:text-slate-200
        hover:border-violet-400 dark:hover:border-violet-500
        hover:text-violet-600 dark:hover:text-violet-400
        transition-all duration-200 shadow-sm cursor-pointer active:scale-95
        ${className}
      `}
    >
      {theme === 'dark' ? (
        <Sun className="w-4 h-4 text-amber-400 transition-transform duration-300 rotate-0 hover:rotate-90" />
      ) : (
        <Moon className="w-4 h-4 text-indigo-600 transition-transform duration-300 rotate-0 hover:-rotate-45" />
      )}
    </button>
  );
};
