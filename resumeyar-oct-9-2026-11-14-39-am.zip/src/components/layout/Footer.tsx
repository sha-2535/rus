import React from 'react';
import { Sparkles, Heart } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const Footer: React.FC = () => {
  const { navigate } = useApp();

  return (
    <footer className="mt-auto border-t border-slate-200/60 dark:border-slate-800/60 bg-white/40 dark:bg-slate-950/40 backdrop-blur-md py-10 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand info */}
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 via-violet-600 to-fuchsia-600 flex items-center justify-center text-white shadow-sm">
                <Sparkles className="w-4 h-4" />
              </div>
              <span className="text-base font-bold text-slate-900 dark:text-white">
                رزومه یار (ResumeYar)
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed max-w-md">
              پلتفرم هوشمند تطبیق شغلی و شخصی‌سازی خودکار رزومه با هوش مصنوعی. ما به کارجویان کمک می‌کنیم تا با بررسی هوشمند آگهی‌ها، نقاط قوت و شکاف‌های خود را شناخته و بهترین نسخه رزومه را برای هر ردیف شغلی بسازند.
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-bold text-slate-900 dark:text-slate-200 uppercase tracking-wider">
              بخش‌های سامانه
            </h4>
            <ul className="space-y-1.5 text-xs text-slate-600 dark:text-slate-400">
              <li>
                <button
                  onClick={() => navigate('/dashboard')}
                  className="hover:text-violet-600 dark:hover:text-violet-400 transition-colors cursor-pointer"
                >
                  پیشخوان کاربری
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/resume')}
                  className="hover:text-violet-600 dark:hover:text-violet-400 transition-colors cursor-pointer"
                >
                  تحلیل و آپلود رزومه
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/jobs')}
                  className="hover:text-violet-600 dark:hover:text-violet-400 transition-colors cursor-pointer"
                >
                  فرصت‌های شغلی برتر
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/preferences')}
                  className="hover:text-violet-600 dark:hover:text-violet-400 transition-colors cursor-pointer"
                >
                  تنظیم ترجیحات کاری
                </button>
              </li>
            </ul>
          </div>

          {/* Standards & Tech */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-bold text-slate-900 dark:text-slate-200 uppercase tracking-wider">
              معماری و یکپارچه‌سازی
            </h4>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              لایه‌بندی ماژولار هماهنگ با FastAPI Backend، استاندارد RTL فارسی، قلم وزیرمتن و طراحی Glassmorphism + Material Design 3.
            </p>
          </div>
        </div>

        <div className="pt-6 border-t border-slate-200/50 dark:border-slate-800/50 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500 dark:text-slate-400">
          <div className="flex items-center gap-1.5">
            <span>توسعه یافته با</span>
            <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500 inline" />
            <span>برای جامعه کارجویان و متخصصان ایران</span>
          </div>
          <div>
            <span>تمامی حقوق برای «رزومه یار» محفوظ است © ۱۴۰۵</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
