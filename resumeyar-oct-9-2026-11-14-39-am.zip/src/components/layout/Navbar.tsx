import React, { useState } from 'react';
import {
  Sparkles,
  User as UserIcon,
  Menu,
  X,
  FileText,
  Briefcase,
  Sliders,
  LayoutDashboard,
  Settings
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ThemeToggle } from '../common/ThemeToggle';
import { GradientButton } from '../common/GradientButton';

export const Navbar: React.FC = () => {
  const { currentPath, navigate, user, isAuthenticated, setAgentDrawerOpen, agentSteps } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const runningAgentSteps = agentSteps.filter((s) => s.status === 'running').length;

  const navLinks = [
    { label: 'پیشخوان', path: '/dashboard', icon: <LayoutDashboard className="w-4 h-4" /> },
    { label: 'رزومه من', path: '/resume', icon: <FileText className="w-4 h-4" /> },
    { label: 'ترجیحات شغلی', path: '/preferences', icon: <Sliders className="w-4 h-4" /> },
    { label: 'فرصت‌های شغلی', path: '/jobs', icon: <Briefcase className="w-4 h-4" /> }
  ];

  const handleNavClick = (path: string) => {
    navigate(path);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-white/75 dark:bg-slate-950/75 backdrop-blur-xl border-b border-slate-200/60 dark:border-slate-800/60 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4 md:gap-8">
          {/* ZONE 1: Single text element wordmark */}
          <button
            onClick={() => handleNavClick('/')}
            className="flex items-center gap-2.5 text-right shrink-0 cursor-pointer group text-slate-900 dark:text-white"
          >
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-indigo-600 via-violet-600 to-fuchsia-600 flex items-center justify-center text-white shadow-md shadow-violet-500/20 group-hover:scale-105 transition-transform">
              <Sparkles className="w-5 h-5" />
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-black tracking-tight bg-gradient-to-l from-indigo-600 via-violet-600 to-fuchsia-600 bg-clip-text text-transparent">
                رزومه یار
              </span>
              <span className="text-[10px] text-slate-400 font-mono -mt-1 hidden sm:block">
                ResumeYar AI
              </span>
            </div>
          </button>

          {/* ZONE 2: 4-5 clean single-line nav links */}
          <nav className="hidden md:flex items-center gap-1 lg:gap-2">
            {navLinks.map((link) => {
              const isActive = currentPath === link.path;
              return (
                <button
                  key={link.path}
                  onClick={() => handleNavClick(link.path)}
                  className={`
                    px-3.5 py-1.5 rounded-xl text-xs lg:text-sm font-medium transition-all cursor-pointer whitespace-nowrap shrink-0 flex items-center gap-1.5
                    ${
                      isActive
                        ? 'bg-violet-500/10 text-violet-700 dark:text-violet-300 font-bold'
                        : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100/60 dark:hover:bg-slate-800/40'
                    }
                  `}
                >
                  {link.label}
                </button>
              );
            })}
          </nav>

          {/* ZONE 3: 1 primary action zone with agent trigger, theme toggle & profile */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Agent Drawer Trigger Button */}
            <button
              onClick={() => setAgentDrawerOpen(true)}
              aria-label="نمایش زنجیره استدلال ایجنت"
              title="نمایش زنجیره استدلال ایجنت"
              className="relative flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium bg-gradient-to-l from-violet-600/10 to-fuchsia-600/10 border border-violet-500/30 text-violet-700 dark:text-violet-300 hover:bg-violet-500/20 transition-all cursor-pointer shadow-sm active:scale-95"
            >
              <Sparkles className="w-3.5 h-3.5 text-violet-600 dark:text-violet-400 animate-pulse" />
              <span className="hidden sm:inline">ایجنت هوشمند</span>
              {runningAgentSteps > 0 ? (
                <span className="w-2 h-2 rounded-full bg-violet-600 animate-ping" />
              ) : (
                <span className="text-[10px] font-mono px-1 rounded bg-violet-500/20 tabular-nums">
                  {agentSteps.length}
                </span>
              )}
            </button>

            {/* Theme Toggle */}
            <ThemeToggle />

            {/* Profile or Auth */}
            {isAuthenticated ? (
              <button
                onClick={() => handleNavClick('/settings')}
                title="تنظیمات و پروفایل"
                className="flex items-center gap-2 p-1 pl-2.5 rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 hover:border-violet-400 transition-all cursor-pointer"
              >
                <img
                  src={user?.avatarUrl || '/src/assets/images/persian_user_avatar_1791568791198.jpg'}
                  alt={user?.name || 'کاربر'}
                  referrerPolicy="no-referrer"
                  className="w-7 h-7 rounded-xl object-cover border border-violet-200 dark:border-violet-900"
                />
                <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 hidden lg:inline max-w-[100px] truncate">
                  {user?.name?.split(' ')[0]}
                </span>
                <Settings className="w-3.5 h-3.5 text-slate-400 hidden sm:block" />
              </button>
            ) : (
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => handleNavClick('/login')}
                  className="text-xs font-medium text-slate-700 dark:text-slate-200 hover:text-violet-600 px-2.5 py-1.5 cursor-pointer"
                >
                  ورود
                </button>
                <GradientButton
                  size="sm"
                  variant="primary"
                  onClick={() => handleNavClick('/register')}
                >
                  شروع کن
                </GradientButton>
              </div>
            )}

            {/* Mobile Hamburger Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-slate-600 dark:text-slate-300 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              aria-label="منوی موبایل"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200/70 dark:border-slate-800/80 bg-white/95 dark:bg-slate-950/95 backdrop-blur-xl p-4 space-y-2 animate-in fade-in slide-in-from-top-2">
          {navLinks.map((link) => {
            const isActive = currentPath === link.path;
            return (
              <button
                key={link.path}
                onClick={() => handleNavClick(link.path)}
                className={`
                  w-full flex items-center gap-3 p-3 rounded-2xl text-sm font-medium transition-all text-right
                  ${
                    isActive
                      ? 'bg-violet-500/10 text-violet-700 dark:text-violet-300 font-bold'
                      : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }
                `}
              >
                {link.icon}
                <span>{link.label}</span>
              </button>
            );
          })}
          <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex justify-between items-center px-1">
            <span className="text-xs text-slate-500">دستیار شغلی هوشمند</span>
            <button
              onClick={() => handleNavClick('/settings')}
              className="text-xs text-violet-600 font-medium"
            >
              تنظیمات حساب کاربری
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
