import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import {
  ThemeMode,
  User,
  ResumeProfile,
  UserPreferences,
  Job,
  MatchAnalysis,
  TailoredResume,
  TailoredResumeContent,
  AgentLogStep,
  ToastNotification
} from '../types';
import {
  INITIAL_USER_PROFILE,
  INITIAL_PREFERENCES,
  MOCK_JOBS,
  MOCK_MATCH_RESULTS,
  MOCK_TAILORED_RESUMES,
  INITIAL_AGENT_STEPS
} from '../lib/mock-data';
import * as api from '../lib/api';

interface AppContextType {
  // Theme
  theme: ThemeMode;
  toggleTheme: () => void;

  // Routing
  currentPath: string;
  navigate: (path: string) => void;

  // Auth
  user: User | null;
  isAuthenticated: boolean;
  login: (payload: api.LoginPayload) => Promise<boolean>;
  register: (payload: api.RegisterPayload) => Promise<boolean>;
  logout: () => void;

  // Profile & Resume
  profile: ResumeProfile;
  isResumeUploaded: boolean;
  uploadResumeFile: (file?: File, rawText?: string) => Promise<boolean>;
  updateProfile: (updated: Partial<ResumeProfile>) => void;

  // Preferences
  preferences: UserPreferences;
  isPreferencesSet: boolean;
  saveUserPreferences: (prefs: UserPreferences) => Promise<boolean>;

  // Jobs
  jobs: Job[];
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  seniorityFilter: string;
  setSeniorityFilter: (f: string) => void;
  workStyleFilter: string;
  setWorkStyleFilter: (f: string) => void;

  // Matching
  matchResults: Record<string, MatchAnalysis>;
  matchingJobIds: Record<string, boolean>;
  analyzeJobMatch: (jobId: string) => Promise<MatchAnalysis | null>;

  // Tailoring
  tailoredResumes: Record<string, TailoredResume>;
  generateTailoredResume: (jobId: string) => Promise<TailoredResume | null>;
  submitFeedbackToTailor: (jobId: string, feedbackText: string) => Promise<boolean>;
  isTailoringLoading: boolean;

  // Agent Drawer
  agentSteps: AgentLogStep[];
  isAgentDrawerOpen: boolean;
  setAgentDrawerOpen: (open: boolean) => void;
  addAgentStep: (step: Omit<AgentLogStep, 'id' | 'timestamp'>) => void;

  // Toasts
  toasts: ToastNotification[];
  addToast: (title: string, message?: string, type?: ToastNotification['type']) => void;
  removeToast: (id: string) => void;

  // Checklist helper stats
  stats: {
    analyzedCount: number;
    averageScore: number;
    tailoredCount: number;
  };
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // 1. Theme State
  const [theme, setTheme] = useState<ThemeMode>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('resumeyar_theme') as ThemeMode;
      if (saved) return saved;
      return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }
    return 'light';
  });

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('resumeyar_theme', theme);
  }, [theme]);

  const toggleTheme = useCallback(() => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  }, []);

  // 2. Routing State (supports browser back/forward and path syncing)
  const [currentPath, setCurrentPath] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      return window.location.pathname || '/';
    }
    return '/';
  });

  const navigate = useCallback((path: string) => {
    if (typeof window !== 'undefined') {
      window.history.pushState({}, '', path);
    }
    setCurrentPath(path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname || '/');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // 3. Toasts State
  const [toasts, setToasts] = useState<ToastNotification[]>([]);

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const addToast = useCallback((title: string, message?: string, type: ToastNotification['type'] = 'info') => {
    const id = `toast_${Date.now()}_${Math.random()}`;
    const newToast: ToastNotification = { id, title, message, type };
    setToasts((prev) => [...prev, newToast]);

    setTimeout(() => {
      removeToast(id);
    }, 4000);
  }, [removeToast]);

  // 4. Auth State
  const [user, setUser] = useState<User | null>(() => {
    if (typeof window !== 'undefined') {
      const savedUser = localStorage.getItem('resumeyar_user');
      if (savedUser) {
        try {
          return JSON.parse(savedUser);
        } catch {
          // fallback
        }
      }
      const token = localStorage.getItem('resumeyar_token');
      if (token) {
        return {
          id: 'usr_default',
          name: 'امیرحسین رضایی',
          email: 'amirhossein.rezaei@example.com',
          avatarUrl: '/src/assets/images/persian_user_avatar_1791568791198.jpg',
          createdAt: new Date().toISOString()
        };
      }
    }
    // Default logged in user for immediate seamless experience
    return {
      id: 'usr_demo',
      name: 'امیرحسین رضایی',
      email: 'amirhossein.rezaei@example.com',
      avatarUrl: '/src/assets/images/persian_user_avatar_1791568791198.jpg',
      createdAt: new Date().toISOString()
    };
  });

  const login = async (payload: api.LoginPayload): Promise<boolean> => {
    try {
      const res = await api.loginUser(payload);
      setUser(res.user);
      if (typeof window !== 'undefined') {
        localStorage.setItem('resumeyar_token', res.token);
        localStorage.setItem('resumeyar_user', JSON.stringify(res.user));
      }
      addToast('ورود موفقیت‌آمیز بود', `خوش آمدید، ${res.user.name}`, 'success');
      return true;
    } catch (err: any) {
      addToast('خطا در ورود', err.message || 'مشکلی رخ داده است', 'error');
      return false;
    }
  };

  const register = async (payload: api.RegisterPayload): Promise<boolean> => {
    try {
      const res = await api.registerUser(payload);
      setUser(res.user);
      if (typeof window !== 'undefined') {
        localStorage.setItem('resumeyar_token', res.token);
        localStorage.setItem('resumeyar_user', JSON.stringify(res.user));
      }
      addToast('ثبت نام با موفقیت انجام شد', `خوش آمدید، ${res.user.name}`, 'success');
      return true;
    } catch (err: any) {
      addToast('خطا در ثبت‌نام', err.message || 'مشکلی رخ داده است', 'error');
      return false;
    }
  };

  const logout = () => {
    setUser(null);
    if (typeof window !== 'undefined') {
      localStorage.removeItem('resumeyar_token');
      localStorage.removeItem('resumeyar_user');
    }
    addToast('خروج از حساب کاربری', 'با موفقیت خارج شدید', 'info');
    navigate('/');
  };

  // 5. Agent Activity Steps State
  const [agentSteps, setAgentSteps] = useState<AgentLogStep[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('resumeyar_agent_steps');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch {
          // fallback
        }
      }
    }
    return INITIAL_AGENT_STEPS;
  });

  const [isAgentDrawerOpen, setAgentDrawerOpen] = useState(false);

  const addAgentStep = useCallback(
    (step: Omit<AgentLogStep, 'id' | 'timestamp'>) => {
      const now = new Date();
      const timeStr = now.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      const newStep: AgentLogStep = {
        ...step,
        id: `step_${Date.now()}_${Math.random()}`,
        timestamp: timeStr
      };

      setAgentSteps((prev) => {
        const next = [newStep, ...prev];
        if (typeof window !== 'undefined') {
          localStorage.setItem('resumeyar_agent_steps', JSON.stringify(next.slice(0, 30)));
        }
        return next;
      });
    },
    []
  );

  // 6. Resume Profile State
  const [profile, setProfile] = useState<ResumeProfile>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('resumeyar_profile');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch {}
      }
    }
    return INITIAL_USER_PROFILE;
  });

  const [isResumeUploaded, setIsResumeUploaded] = useState<boolean>(true);

  const updateProfile = (updated: Partial<ResumeProfile>) => {
    setProfile((prev) => {
      const next = { ...prev, ...updated };
      if (typeof window !== 'undefined') {
        localStorage.setItem('resumeyar_profile', JSON.stringify(next));
      }
      return next;
    });
  };

  const uploadResumeFile = async (file?: File, rawText?: string): Promise<boolean> => {
    addAgentStep({
      action: 'آپلود و خوانش سند رزومه',
      detail: file ? `تحلیل فایل سندی «${file.name}»...` : 'پردازش متن ورودی رزومه...',
      status: 'running',
      category: 'profile'
    });

    try {
      const res = await api.uploadResume({ file, rawText });
      setProfile(res.profile);
      setIsResumeUploaded(true);
      if (typeof window !== 'undefined') {
        localStorage.setItem('resumeyar_profile', JSON.stringify(res.profile));
      }

      addAgentStep({
        action: 'استخراج هوشمند پروفایل کاربری',
        detail: `استخراج ${res.profile.skills.length} مهارت تخصصی و ${res.profile.experiences.length} سابقه شغلی با موفقیت به پایان رسید.`,
        status: 'done',
        category: 'profile'
      });

      addToast('رزومه با موفقیت پردازش شد', 'پروفایل شغلی شما استخراج گردید', 'success');
      return true;
    } catch (err: any) {
      addAgentStep({
        action: 'خطا در پردازش رزومه',
        detail: err.message || 'فایل نامعتبر است',
        status: 'failed',
        category: 'profile'
      });
      addToast('خطا در بارگذاری', err.message || 'مشکلی رخ داده است', 'error');
      return false;
    }
  };

  // 7. Preferences State
  const [preferences, setPreferences] = useState<UserPreferences>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('resumeyar_preferences');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch {}
      }
    }
    return INITIAL_PREFERENCES;
  });

  const [isPreferencesSet, setIsPreferencesSet] = useState<boolean>(true);

  const saveUserPreferences = async (prefs: UserPreferences): Promise<boolean> => {
    addAgentStep({
      action: 'تنظیم اولویت‌ها و ترجیحات کاری',
      detail: `نقش: ${prefs.desiredRole} | مدل کاری: ${prefs.workStyle} | بازه حقوق: ${prefs.expectedSalaryMinMillionTomans}-${prefs.expectedSalaryMaxMillionTomans} میلیون`,
      status: 'running',
      category: 'profile'
    });

    try {
      await api.savePreferences(prefs);
      setPreferences(prefs);
      setIsPreferencesSet(true);
      if (typeof window !== 'undefined') {
        localStorage.setItem('resumeyar_preferences', JSON.stringify(prefs));
      }

      addAgentStep({
        action: 'تثبیت نیازمندی‌ها در پایگاه داده ایجنت',
        detail: 'فیلترهای تطبیق هوشمند آگهی‌ها بر مبنای مهارت‌ها و شهرهای هدف به‌روز شدند.',
        status: 'done',
        category: 'profile'
      });

      addToast('ترجیحات ذخیره شد', 'معیارهای شما با موفقیت ثبت گردید', 'success');
      return true;
    } catch (err: any) {
      addToast('خطا در ثبت ترجیحات', err.message, 'error');
      return false;
    }
  };

  // 8. Jobs & Search Filter State
  const [jobs, setJobs] = useState<Job[]>(MOCK_JOBS);
  const [searchQuery, setSearchQuery] = useState('');
  const [seniorityFilter, setSeniorityFilter] = useState('all');
  const [workStyleFilter, setWorkStyleFilter] = useState('all');

  useEffect(() => {
    let active = true;
    const fetchFilteredJobs = async () => {
      const results = await api.getJobs(searchQuery, {
        seniority: seniorityFilter,
        workStyle: workStyleFilter
      });
      if (active) {
        setJobs(results);
      }
    };
    fetchFilteredJobs();
    return () => {
      active = false;
    };
  }, [searchQuery, seniorityFilter, workStyleFilter]);

  // 9. Match Results State
  const [matchResults, setMatchResults] = useState<Record<string, MatchAnalysis>>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('resumeyar_match_results');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch {}
      }
    }
    return MOCK_MATCH_RESULTS;
  });

  const [matchingJobIds, setMatchingJobIds] = useState<Record<string, boolean>>({});

  const analyzeJobMatch = async (jobId: string): Promise<MatchAnalysis | null> => {
    const job = jobs.find((j) => j.id === jobId);
    const jobTitle = job ? `${job.title} (${job.company})` : jobId;

    setMatchingJobIds((prev) => ({ ...prev, [jobId]: true }));

    addAgentStep({
      action: `تحلیل تناسب برای «${jobTitle}»`,
      detail: 'مقایسه بردار معنایی رزومه با ملزومات فنی، شایستگی‌ها و فرهنگ سازمانی...',
      status: 'running',
      category: 'matching'
    });

    try {
      const analysis = await api.matchJob({ jobId, resumeProfile: profile, preferences });
      setMatchResults((prev) => {
        const next = { ...prev, [jobId]: analysis };
        if (typeof window !== 'undefined') {
          localStorage.setItem('resumeyar_match_results', JSON.stringify(next));
        }
        return next;
      });

      addAgentStep({
        action: `محاسبه درصد انطباق برای «${jobTitle}»`,
        detail: `نمره تناسب: ${analysis.score}٪ | ${analysis.strengths.length} نقطه قوت و ${analysis.gaps.length} نقطه بهبود شناسایی شد.`,
        status: 'done',
        category: 'matching'
      });

      addToast(`تحلیل تناسب تکمیل شد`, `نمره تناسب: ${analysis.score}٪`, 'success');
      return analysis;
    } catch (err: any) {
      addAgentStep({
        action: `خطا در ارزیابی تناسب «${jobTitle}»`,
        detail: err.message,
        status: 'failed',
        category: 'matching'
      });
      addToast('خطا در تحلیل آگهی', err.message, 'error');
      return null;
    } finally {
      setMatchingJobIds((prev) => ({ ...prev, [jobId]: false }));
    }
  };

  // 10. Tailored Resumes State
  const [tailoredResumes, setTailoredResumes] = useState<Record<string, TailoredResume>>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('resumeyar_tailored_resumes');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch {}
      }
    }
    return MOCK_TAILORED_RESUMES;
  });

  const [isTailoringLoading, setIsTailoringLoading] = useState(false);

  const generateTailoredResume = async (jobId: string): Promise<TailoredResume | null> => {
    const job = jobs.find((j) => j.id === jobId);
    const company = job ? job.company : 'شرکت هدف';

    setIsTailoringLoading(true);
    addAgentStep({
      action: `تولید رزومه اختصاصی برای ${company}`,
      detail: 'سفارشی‌سازی خلاصه حرفه‌ای، هم‌راستاسازی واژگان کلیدی و نگارش کاور لتر...',
      status: 'running',
      category: 'tailoring'
    });

    try {
      const result = await api.tailorResume({ jobId, resumeProfile: profile });
      setTailoredResumes((prev) => {
        const next = { ...prev, [jobId]: result };
        if (typeof window !== 'undefined') {
          localStorage.setItem('resumeyar_tailored_resumes', JSON.stringify(next));
        }
        return next;
      });

      addAgentStep({
        action: `تکمیل نگارش رزومه سفارشی (${company})`,
        detail: `تزریق ${result.content.addedKeywords.length} کلیدواژه طلایی و بازنویسی بولت‌پوینت‌های تجربیات کاری.`,
        status: 'done',
        category: 'tailoring'
      });

      addToast('رزومه اختصاصی ساخته شد', `نسخه متناسب با ${company} آماده دریافت است`, 'success');
      return result;
    } catch (err: any) {
      addAgentStep({
        action: `خطا در نگارش رزومه اختصاصی`,
        detail: err.message,
        status: 'failed',
        category: 'tailoring'
      });
      addToast('خطا در سفارشی‌سازی', err.message, 'error');
      return null;
    } finally {
      setIsTailoringLoading(false);
    }
  };

  const submitFeedbackToTailor = async (jobId: string, feedbackText: string): Promise<boolean> => {
    const existing = tailoredResumes[jobId];
    if (!existing) return false;

    setIsTailoringLoading(true);
    addAgentStep({
      action: 'دریافت بازخورد کاربر و بازتولید',
      detail: `بازخورد کاربر: «${feedbackText}» - در حال بازنویسی بخش‌های مرتبط...`,
      status: 'running',
      category: 'feedback'
    });

    try {
      const res = await api.sendFeedback({
        tailoredResumeId: existing.id,
        feedbackText,
        currentContent: existing.content
      });

      const updatedResume: TailoredResume = {
        ...existing,
        content: res.updatedContent,
        versions: [existing.content, ...(existing.versions || [])],
        updatedAt: 'لحظاتی پیش'
      };

      setTailoredResumes((prev) => {
        const next = { ...prev, [jobId]: updatedResume };
        if (typeof window !== 'undefined') {
          localStorage.setItem('resumeyar_tailored_resumes', JSON.stringify(next));
        }
        return next;
      });

      addAgentStep({
        action: `اعمال موفق بازخورد در نگارش شماره ${res.updatedContent.version}`,
        detail: res.message,
        status: 'done',
        category: 'feedback'
      });

      addToast('بازخورد شما اعمال شد', `نسخه جدید رزومه (ورژن ${res.updatedContent.version}) تولید گردید`, 'success');
      return true;
    } catch (err: any) {
      addAgentStep({
        action: 'خطا در اعمال بازخورد',
        detail: err.message,
        status: 'failed',
        category: 'feedback'
      });
      addToast('خطا در اعمال بازخورد', err.message, 'error');
      return false;
    } finally {
      setIsTailoringLoading(false);
    }
  };

  // 11. Stats Calculations
  const analyzedScores = Object.values(matchResults).map((r) => r.score);
  const averageScore =
    analyzedScores.length > 0
      ? Math.round(analyzedScores.reduce((a, b) => a + b, 0) / analyzedScores.length)
      : 85;

  const stats = {
    analyzedCount: Object.keys(matchResults).length,
    averageScore,
    tailoredCount: Object.keys(tailoredResumes).length
  };

  return (
    <AppContext.Provider
      value={{
        theme,
        toggleTheme,
        currentPath,
        navigate,
        user,
        isAuthenticated: Boolean(user),
        login,
        register,
        logout,
        profile,
        isResumeUploaded,
        uploadResumeFile,
        updateProfile,
        preferences,
        isPreferencesSet,
        saveUserPreferences,
        jobs,
        searchQuery,
        setSearchQuery,
        seniorityFilter,
        setSeniorityFilter,
        workStyleFilter,
        setWorkStyleFilter,
        matchResults,
        matchingJobIds,
        analyzeJobMatch,
        tailoredResumes,
        generateTailoredResume,
        submitFeedbackToTailor,
        isTailoringLoading,
        agentSteps,
        isAgentDrawerOpen,
        setAgentDrawerOpen,
        addAgentStep,
        toasts,
        addToast,
        removeToast,
        stats
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
