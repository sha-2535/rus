import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';
import { AgentDrawer } from './components/agent/AgentDrawer';
import { ToastContainer } from './components/common/ToastContainer';
import { LandingPage } from './pages/LandingPage';
import { AuthPage } from './pages/AuthPage';
import { DashboardPage } from './pages/DashboardPage';
import { ResumeUploadPage } from './pages/ResumeUploadPage';
import { PreferencesPage } from './pages/PreferencesPage';
import { JobsPage } from './pages/JobsPage';
import { JobDetailPage } from './pages/JobDetailPage';
import { TailorResumePage } from './pages/TailorResumePage';
import { SettingsPage } from './pages/SettingsPage';
import { Sparkles } from 'lucide-react';

const AppContent: React.FC = () => {
  const { currentPath, setAgentDrawerOpen, agentSteps } = useApp();

  const runningCount = agentSteps.filter((s) => s.status === 'running').length;

  // Route matching helper
  const renderCurrentRoute = () => {
    // 1. Landing
    if (currentPath === '/' || currentPath === '') {
      return <LandingPage />;
    }

    // 2. Auth routes
    if (currentPath === '/login') {
      return <AuthPage mode="login" />;
    }
    if (currentPath === '/register') {
      return <AuthPage mode="register" />;
    }

    // 3. Dashboard
    if (currentPath === '/dashboard') {
      return <DashboardPage />;
    }

    // 4. Resume upload & profile
    if (currentPath === '/resume') {
      return <ResumeUploadPage />;
    }

    // 5. Preferences
    if (currentPath === '/preferences') {
      return <PreferencesPage />;
    }

    // 6. Jobs List
    if (currentPath === '/jobs') {
      return <JobsPage />;
    }

    // 7. Match Detail: /jobs/:id
    if (currentPath.startsWith('/jobs/')) {
      const jobId = currentPath.replace('/jobs/', '').split('/')[0];
      return <JobDetailPage jobId={jobId || 'job-1'} />;
    }

    // 8. Tailor Resume: /tailor/:jobId
    if (currentPath.startsWith('/tailor/')) {
      const jobId = currentPath.replace('/tailor/', '').split('/')[0];
      return <TailorResumePage jobId={jobId || 'job-1'} />;
    }

    // 9. Settings
    if (currentPath === '/settings') {
      return <SettingsPage />;
    }

    // Fallback: Dashboard if logged in or Landing
    return <LandingPage />;
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 via-indigo-50/30 to-purple-50/40 dark:from-slate-950 dark:via-indigo-950/20 dark:to-slate-900 transition-colors duration-300">
      {/* Top Navbar Contract */}
      <Navbar />

      {/* Main Content Area */}
      <main className="flex-1">
        {renderCurrentRoute()}
      </main>

      {/* Footer */}
      <Footer />

      {/* Global Agent Activity Panel Drawer */}
      <AgentDrawer />

      {/* Toast Notification Container */}
      <ToastContainer />

      {/* Floating Action Button (FAB) for Instant Agent Access */}
      <div className="fixed bottom-6 left-6 z-30">
        <button
          onClick={() => setAgentDrawerOpen(true)}
          className="group relative flex items-center gap-2.5 px-4 py-3 rounded-full bg-gradient-to-l from-indigo-600 via-violet-600 to-fuchsia-600 text-white shadow-xl shadow-violet-500/35 hover:shadow-2xl hover:shadow-violet-500/50 hover:scale-105 active:scale-95 transition-all duration-200 cursor-pointer"
          aria-label="باز کردن پنل هوش مصنوعی ایجنت"
          title="فعالیت‌های زنده ایجنت هوشمند"
        >
          <Sparkles className="w-5 h-5 animate-pulse" />
          <span className="text-xs font-bold hidden sm:inline">
            ایجنت هوشمند
          </span>
          {runningCount > 0 ? (
            <span className="w-2.5 h-2.5 rounded-full bg-white animate-ping" />
          ) : (
            <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-white/20 tabular-nums">
              {agentSteps.length}
            </span>
          )}
        </button>
      </div>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
