export type ThemeMode = 'light' | 'dark';

export interface User {
  id: string;
  name: string;
  email: string;
  avatarUrl?: string;
  token?: string;
  createdAt: string;
}

export interface ExtractedExperience {
  id: string;
  role: string;
  company: string;
  period: string;
  description: string;
  highlights: string[];
}

export interface ExtractedEducation {
  id: string;
  degree: string;
  field: string;
  university: string;
  year: string;
}

export interface ResumeProfile {
  fullName: string;
  title: string;
  summary: string;
  phone: string;
  email: string;
  location: string;
  skills: string[];
  experiences: ExtractedExperience[];
  education: ExtractedEducation[];
  rawText?: string;
  fileName?: string;
  updatedAt: string;
}

export interface UserPreferences {
  desiredRole: string;
  seniorityLevel: 'junior' | 'mid' | 'senior' | 'lead';
  workStyle: 'remote' | 'hybrid' | 'onsite' | 'any';
  cities: string[];
  expectedSalaryMinMillionTomans: number;
  expectedSalaryMaxMillionTomans: number;
  keySkills: string[];
  industries: string[];
}

export interface Job {
  id: string;
  title: string;
  company: string;
  companyLogo?: string;
  location: string;
  city: string;
  workStyle: 'remote' | 'hybrid' | 'onsite';
  seniority: 'junior' | 'mid' | 'senior' | 'lead';
  salaryRange?: string;
  description: string;
  requirements: string[];
  benefits: string[];
  postedAt: string;
}

export interface MatchAnalysis {
  jobId: string;
  score: number; // 0 to 100
  summary: string;
  strengths: string[];
  gaps: string[];
  agentReasoning: string;
  skillOverlap: {
    matched: string[];
    missing: string[];
  };
  recommendedActions: string[];
}

export interface TailoredResumeContent {
  headline: string;
  summary: string;
  highlightedSkills: string[];
  tailoredExperiences: {
    role: string;
    company: string;
    period: string;
    bulletPoints: {
      text: string;
      isModified?: boolean;
      keywordsAdded?: string[];
    }[];
  }[];
  addedKeywords: string[];
  coverLetter: string;
  version: number;
  generationNote?: string;
}

export interface TailoredResume {
  id: string;
  jobId: string;
  jobTitle: string;
  company: string;
  content: TailoredResumeContent;
  versions: TailoredResumeContent[];
  createdAt: string;
  updatedAt: string;
}

export interface AgentLogStep {
  id: string;
  action: string;
  detail: string;
  timestamp: string;
  status: 'pending' | 'running' | 'done' | 'failed';
  category: 'profile' | 'analysis' | 'matching' | 'tailoring' | 'feedback';
}

export interface ToastNotification {
  id: string;
  title: string;
  message?: string;
  type: 'success' | 'info' | 'warning' | 'error';
  duration?: number;
}
