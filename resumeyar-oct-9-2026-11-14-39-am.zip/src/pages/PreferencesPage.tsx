import React, { useState } from 'react';
import {
  Sliders,
  Briefcase,
  MapPin,
  DollarSign,
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Sparkles,
  Plus,
  X
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { GlassCard } from '../components/common/GlassCard';
import { GradientButton } from '../components/common/GradientButton';
import { StepProgress } from '../components/common/StepProgress';
import { UserPreferences } from '../types';

export const PreferencesPage: React.FC = () => {
  const { preferences, saveUserPreferences, navigate } = useApp();

  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<UserPreferences>(preferences);
  const [customSkillInput, setCustomSkillInput] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const stepsConfig = [
    { label: 'نقش و سطح', description: 'عنوان شغلی و رده ارشدیت' },
    { label: 'موقعیت و دورکاری', description: 'شهرها و مدل حضور' },
    { label: 'حقوق و مهارت‌ها', description: 'بازه درآمدی و تخصص‌ها' }
  ];

  const seniorityOptions = [
    { id: 'junior', label: 'جونیور (مبتدی / تا ۲ سال سابقه)' },
    { id: 'mid', label: 'میدلول (متوسط / ۲ تا ۴ سال سابقه)' },
    { id: 'senior', label: 'سنیور (ارشد / بیش از ۴ سال سابقه)' },
    { id: 'lead', label: 'لید یا مدیر فنی (بیش از ۶ سال سابقه)' }
  ];

  const workStyleOptions = [
    { id: 'remote', label: 'تمام دورکاری (Remote)' },
    { id: 'hybrid', label: 'هیبرید و منعطف (Hybrid)' },
    { id: 'onsite', label: 'حضوری در دفتر (On-site)' },
    { id: 'any', label: 'مهم نیست (هر دو حالت)' }
  ];

  const cityOptions = ['تهران', 'اصفهان', 'مشهد', 'شیراز', 'تبریز', 'دورکاری سراسر کشور'];

  const industryOptions = [
    'فین‌تک و پرداخت',
    'تجارت الکترونیک',
    'هوش مصنوعی و داده',
    'محصولات ابری SaaS',
    'سلامت و درمان',
    'بازی‌سازی و سرگرمی'
  ];

  const toggleCity = (city: string) => {
    setFormData((prev) => {
      const exists = prev.cities.includes(city);
      return {
        ...prev,
        cities: exists ? prev.cities.filter((c) => c !== city) : [...prev.cities, city]
      };
    });
  };

  const toggleIndustry = (ind: string) => {
    setFormData((prev) => {
      const exists = prev.industries.includes(ind);
      return {
        ...prev,
        industries: exists ? prev.industries.filter((i) => i !== ind) : [...prev.industries, ind]
      };
    });
  };

  const addCustomSkill = () => {
    if (customSkillInput.trim() && !formData.keySkills.includes(customSkillInput.trim())) {
      setFormData((prev) => ({
        ...prev,
        keySkills: [...prev.keySkills, customSkillInput.trim()]
      }));
      setCustomSkillInput('');
    }
  };

  const removeSkill = (skillToRemove: string) => {
    setFormData((prev) => ({
      ...prev,
      keySkills: prev.keySkills.filter((s) => s !== skillToRemove)
    }));
  };

  const handleSubmit = async () => {
    setIsSaving(true);
    const ok = await saveUserPreferences(formData);
    setIsSaving(false);
    if (ok) {
      navigate('/jobs');
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 pb-16">
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto space-y-2 pt-4">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-violet-500/10 text-violet-700 dark:text-violet-300 text-xs font-semibold">
          <Sliders className="w-3.5 h-3.5" />
          <span>گام دوم: تنظیم ترجیحات اختصاصی</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
          اولویت‌ها و شرایط ایده‌آل شغلی شما
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
          ایجنت هوشمند بر اساس این پارامترها بهترین موقعیت‌های استخدامی را رتبه‌بندی می‌کند.
        </p>
      </div>

      {/* 3-Step Progress Indicator */}
      <GlassCard className="p-6">
        <StepProgress
          currentStep={step}
          totalSteps={3}
          steps={stepsConfig}
          onStepClick={(s) => setStep(s)}
        />
      </GlassCard>

      {/* Multi-step Form Content */}
      <GlassCard className="p-6 sm:p-10 space-y-6">
        {/* STEP 1: نقش و سطح */}
        {step === 1 && (
          <div className="space-y-6 animate-in fade-in slide-in-from-right-2">
            <div>
              <label className="block text-xs font-bold text-slate-900 dark:text-white mb-2">
                عنوان شغلی مدنظر شما
              </label>
              <input
                type="text"
                value={formData.desiredRole}
                onChange={(e) => setFormData({ ...formData, desiredRole: e.target.value })}
                placeholder="مثال: توسعه‌دهنده ارشد فرانت‌اند یا مدیر محصول"
                className="w-full p-3.5 rounded-2xl bg-white/70 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500"
              />
            </div>

            <div className="space-y-3">
              <label className="block text-xs font-bold text-slate-900 dark:text-white">
                سطح ارشدیت مطلوب
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {seniorityOptions.map((opt) => (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => setFormData({ ...formData, seniorityLevel: opt.id as any })}
                    className={`
                      p-3.5 rounded-2xl border text-right transition-all cursor-pointer flex items-center justify-between
                      ${
                        formData.seniorityLevel === opt.id
                          ? 'bg-violet-500/10 border-violet-500 text-violet-900 dark:text-violet-100 ring-2 ring-violet-500/20'
                          : 'bg-white/50 dark:bg-slate-800/40 border-slate-200/80 dark:border-slate-700/80 text-slate-700 dark:text-slate-300 hover:border-slate-400'
                      }
                    `}
                  >
                    <span className="text-xs font-semibold">{opt.label}</span>
                    {formData.seniorityLevel === opt.id && (
                      <CheckCircle2 className="w-4 h-4 text-violet-600 dark:text-violet-400 shrink-0" />
                    )}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-3 pt-2">
              <label className="block text-xs font-bold text-slate-900 dark:text-white">
                حوزه‌های صنعتی مورد علاقه
              </label>
              <div className="flex flex-wrap gap-2">
                {industryOptions.map((ind) => {
                  const isSelected = formData.industries.includes(ind);
                  return (
                    <button
                      key={ind}
                      type="button"
                      onClick={() => toggleIndustry(ind)}
                      className={`
                        text-xs px-3.5 py-2 rounded-xl border transition-all cursor-pointer
                        ${
                          isSelected
                            ? 'bg-gradient-to-l from-indigo-600/15 to-violet-600/15 border-violet-500 text-violet-700 dark:text-violet-300 font-bold'
                            : 'bg-white/60 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:border-slate-400'
                        }
                      `}
                    >
                      {ind}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* STEP 2: موقعیت و دورکاری */}
        {step === 2 && (
          <div className="space-y-6 animate-in fade-in slide-in-from-right-2">
            <div className="space-y-3">
              <label className="block text-xs font-bold text-slate-900 dark:text-white">
                نحوه حضور و مدل کاری
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {workStyleOptions.map((opt) => (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => setFormData({ ...formData, workStyle: opt.id as any })}
                    className={`
                      p-3.5 rounded-2xl border text-right transition-all cursor-pointer flex items-center justify-between
                      ${
                        formData.workStyle === opt.id
                          ? 'bg-violet-500/10 border-violet-500 text-violet-900 dark:text-violet-100 ring-2 ring-violet-500/20'
                          : 'bg-white/50 dark:bg-slate-800/40 border-slate-200/80 dark:border-slate-700/80 text-slate-700 dark:text-slate-300 hover:border-slate-400'
                      }
                    `}
                  >
                    <span className="text-xs font-semibold">{opt.label}</span>
                    {formData.workStyle === opt.id && (
                      <CheckCircle2 className="w-4 h-4 text-violet-600 dark:text-violet-400 shrink-0" />
                    )}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-3 pt-2">
              <label className="block text-xs font-bold text-slate-900 dark:text-white">
                شهرهای مدنظر برای اشتغال
              </label>
              <div className="flex flex-wrap gap-2.5">
                {cityOptions.map((city) => {
                  const isSelected = formData.cities.includes(city);
                  return (
                    <button
                      key={city}
                      type="button"
                      onClick={() => toggleCity(city)}
                      className={`
                        text-xs px-4 py-2 rounded-xl border transition-all cursor-pointer flex items-center gap-1.5
                        ${
                          isSelected
                            ? 'bg-violet-500 text-white border-violet-500 font-semibold shadow-sm'
                            : 'bg-white/60 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:border-slate-400'
                        }
                      `}
                    >
                      <MapPin className="w-3.5 h-3.5" />
                      <span>{city}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* STEP 3: حقوق و مهارت‌ها */}
        {step === 3 && (
          <div className="space-y-6 animate-in fade-in slide-in-from-right-2">
            {/* Salary Range Slider */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-900 dark:text-white">
                  بازه حقوق ماهانه مورد انتظار (میلیون تومان)
                </label>
                <span className="text-xs font-mono font-bold text-violet-600 dark:text-violet-400 tabular-nums">
                  از {formData.expectedSalaryMinMillionTomans} تا {formData.expectedSalaryMaxMillionTomans} میلیون تومان
                </span>
              </div>

              <div className="space-y-4 pt-2">
                <div>
                  <span className="text-[11px] text-slate-400 block mb-1">
                    حداقل حقوق: {formData.expectedSalaryMinMillionTomans} میلیون تومان
                  </span>
                  <input
                    type="range"
                    min="20"
                    max="100"
                    step="5"
                    value={formData.expectedSalaryMinMillionTomans}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        expectedSalaryMinMillionTomans: Number(e.target.value)
                      })
                    }
                    className="w-full accent-violet-600 cursor-pointer"
                  />
                </div>

                <div>
                  <span className="text-[11px] text-slate-400 block mb-1">
                    حداکثر حقوق مطلوب: {formData.expectedSalaryMaxMillionTomans} میلیون تومان
                  </span>
                  <input
                    type="range"
                    min="30"
                    max="150"
                    step="5"
                    value={formData.expectedSalaryMaxMillionTomans}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        expectedSalaryMaxMillionTomans: Number(e.target.value)
                      })
                    }
                    className="w-full accent-violet-600 cursor-pointer"
                  />
                </div>
              </div>
            </div>

            {/* Key Skills Chip Selector */}
            <div className="space-y-3 pt-3">
              <label className="block text-xs font-bold text-slate-900 dark:text-white">
                مهارت‌های کلیدی که می‌خواهید اولویت داشته باشند
              </label>

              <div className="flex gap-2">
                <input
                  type="text"
                  value={customSkillInput}
                  onChange={(e) => setCustomSkillInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addCustomSkill())}
                  placeholder="افزودن مهارت دلخواه (مانند GraphQL یا Docker)..."
                  className="flex-1 p-3 rounded-2xl bg-white/70 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-violet-500/20"
                />
                <button
                  type="button"
                  onClick={addCustomSkill}
                  className="px-4 rounded-2xl bg-violet-600 text-white text-xs font-semibold hover:bg-violet-700 transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  افزودن
                </button>
              </div>

              <div className="flex flex-wrap gap-2 pt-2">
                {formData.keySkills.map((sk) => (
                  <span
                    key={sk}
                    className="inline-flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-xl bg-violet-500/10 text-violet-800 dark:text-violet-200 border border-violet-500/20 font-medium"
                  >
                    <span>{sk}</span>
                    <button
                      type="button"
                      onClick={() => removeSkill(sk)}
                      className="text-violet-400 hover:text-rose-500 transition-colors cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Navigation Buttons between Steps */}
        <div className="flex items-center justify-between pt-6 border-t border-slate-200/60 dark:border-slate-800/60">
          {step > 1 ? (
            <GradientButton
              type="button"
              variant="glass"
              size="md"
              onClick={() => setStep(step - 1)}
              rightIcon={<ArrowRight className="w-4 h-4" />}
            >
              مرحله قبل
            </GradientButton>
          ) : (
            <div />
          )}

          {step < 3 ? (
            <GradientButton
              type="button"
              variant="primary"
              size="md"
              onClick={() => setStep(step + 1)}
              leftIcon={<ArrowLeft className="w-4 h-4" />}
            >
              مرحله بعد
            </GradientButton>
          ) : (
            <GradientButton
              type="button"
              variant="primary"
              size="md"
              isLoading={isSaving}
              onClick={handleSubmit}
              leftIcon={<Sparkles className="w-4 h-4" />}
            >
              ثبت و مشاهده آگهی‌های منطبق
            </GradientButton>
          )}
        </div>
      </GlassCard>
    </div>
  );
};
