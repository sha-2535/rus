import React, { useState, useRef } from 'react';
import {
  UploadCloud,
  FileText,
  CheckCircle2,
  ArrowLeft,
  Briefcase,
  GraduationCap,
  Sparkles,
  Clipboard,
  Trash2,
  Edit3
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { GlassCard } from '../components/common/GlassCard';
import { GradientButton } from '../components/common/GradientButton';

export const ResumeUploadPage: React.FC = () => {
  const { profile, uploadResumeFile, navigate } = useApp();

  const [activeTab, setActiveTab] = useState<'upload' | 'paste'>('upload');
  const [dragOver, setDragOver] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [pastedText, setPastedText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      setSelectedFile(file);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setSelectedFile(e.target.files[0]);
    }
  };

  const handleStartParsing = async () => {
    setIsProcessing(true);
    if (activeTab === 'upload' && selectedFile) {
      await uploadResumeFile(selectedFile, undefined);
    } else if (activeTab === 'paste' && pastedText.trim()) {
      await uploadResumeFile(undefined, pastedText);
    } else {
      // Default sample extraction
      await uploadResumeFile(undefined, undefined);
    }
    setIsProcessing(false);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 pb-16">
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto space-y-2 pt-4">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-700 dark:text-indigo-300 text-xs font-semibold">
          <UploadCloud className="w-3.5 h-3.5" />
          <span>گام اول: ورود اطلاعات کارجو</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
          بارگذاری و تحلیل هوشمند رزومه
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
          فایل رزومه خود را وارد کنید تا هوش مصنوعی اطلاعات تحصیلی، سوابق و مهارت‌ها را استخراج نماید.
        </p>
      </div>

      {/* Tabs for Upload vs Paste */}
      <div className="flex justify-center">
        <div className="inline-flex p-1 rounded-2xl bg-slate-200/60 dark:bg-slate-800/60 backdrop-blur-md">
          <button
            onClick={() => setActiveTab('upload')}
            className={`
              flex items-center gap-2 px-5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer
              ${
                activeTab === 'upload'
                  ? 'bg-white dark:bg-slate-900 text-violet-700 dark:text-violet-300 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }
            `}
          >
            <UploadCloud className="w-4 h-4" />
            <span>آپلود فایل (PDF / DOCX)</span>
          </button>

          <button
            onClick={() => setActiveTab('paste')}
            className={`
              flex items-center gap-2 px-5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer
              ${
                activeTab === 'paste'
                  ? 'bg-white dark:bg-slate-900 text-violet-700 dark:text-violet-300 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }
            `}
          >
            <Clipboard className="w-4 h-4" />
            <span>الصاق متن خام (Paste)</span>
          </button>
        </div>
      </div>

      {/* Upload Box / Paste Area */}
      <GlassCard className="p-6 sm:p-10 border-dashed border-2 border-slate-300/80 dark:border-slate-700/80">
        {activeTab === 'upload' ? (
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={handleFileDrop}
            className={`
              flex flex-col items-center justify-center py-10 px-4 text-center rounded-2xl transition-all cursor-pointer
              ${dragOver ? 'bg-violet-500/10 border-violet-500 scale-[0.99]' : ''}
            `}
            onClick={() => fileInputRef.current?.click()}
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept=".pdf,.docx,.doc,.txt"
              className="hidden"
            />

            <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-indigo-500/10 via-violet-500/10 to-fuchsia-500/10 text-violet-600 dark:text-violet-400 flex items-center justify-center mb-4 shadow-inner">
              <UploadCloud className="w-8 h-8" />
            </div>

            {selectedFile ? (
              <div className="space-y-1">
                <span className="text-sm font-bold text-slate-900 dark:text-white block">
                  {selectedFile.name}
                </span>
                <span className="text-xs text-slate-400 font-mono">
                  {(selectedFile.size / 1024).toFixed(1)} KB — آماده پردازش
                </span>
              </div>
            ) : (
              <div className="space-y-1.5">
                <p className="text-sm font-bold text-slate-900 dark:text-white">
                  فایل رزومه خود را بکشید و اینجا رها کنید
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  فرمت‌های مورد پذیرش: PDF, DOCX, TXT (حداکثر ۱۰ مگابایت)
                </p>
              </div>
            )}

            <div className="mt-6 flex items-center gap-3">
              <GradientButton
                type="button"
                size="sm"
                variant="glass"
                onClick={(e) => {
                  e.stopPropagation();
                  fileInputRef.current?.click();
                }}
              >
                انتخاب از سیستم
              </GradientButton>

              {(selectedFile || !profile.fileName) && (
                <GradientButton
                  type="button"
                  size="sm"
                  variant="primary"
                  isLoading={isProcessing}
                  onClick={(e) => {
                    e.stopPropagation();
                    handleStartParsing();
                  }}
                  rightIcon={<Sparkles className="w-4 h-4" />}
                >
                  استخراج با هوش مصنوعی
                </GradientButton>
              )}
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
              متن کامل یا خلاصه رزومه را اینجا وارد نمایید:
            </label>
            <textarea
              rows={8}
              value={pastedText}
              onChange={(e) => setPastedText(e.target.value)}
              placeholder="مثال: امیرحسین رضایی، مهندس نرم‌افزار با سابقه ۵ ساله در توسعه React و Next.js..."
              className="w-full p-4 rounded-2xl bg-white/70 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500"
            />
            <div className="flex justify-end">
              <GradientButton
                size="sm"
                variant="primary"
                isLoading={isProcessing}
                onClick={handleStartParsing}
                rightIcon={<Sparkles className="w-4 h-4" />}
              >
                پردازش متن
              </GradientButton>
            </div>
          </div>
        )}
      </GlassCard>

      {/* EXTRACTED PROFILE PREVIEW */}
      {profile && (
        <div className="space-y-6 pt-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-600 flex items-center justify-center">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                پروفایل استخراج‌شده توسط هوش مصنوعی
              </h2>
            </div>
            <span className="text-xs text-slate-400">
              آخرین به‌روزرسانی: {profile.updatedAt}
            </span>
          </div>

          <GlassCard className="p-6 md:p-8 space-y-6">
            {/* User Basic Info */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200/60 dark:border-slate-800/60">
              <div>
                <h3 className="text-xl font-black text-slate-900 dark:text-white">
                  {profile.fullName}
                </h3>
                <p className="text-xs sm:text-sm text-violet-600 dark:text-violet-400 font-semibold mt-0.5">
                  {profile.title}
                </p>
                <div className="flex flex-wrap items-center gap-3 mt-2 text-xs text-slate-500 dark:text-slate-400">
                  <span>{profile.email}</span>
                  <span aria-hidden="true">·</span>
                  <span>{profile.phone}</span>
                  <span aria-hidden="true">·</span>
                  <span>{profile.location}</span>
                </div>
              </div>

              {profile.fileName && (
                <div className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs font-mono self-start sm:self-center">
                  📄 {profile.fileName}
                </div>
              )}
            </div>

            {/* Summary */}
            <div className="space-y-1.5">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                خلاصه حرفه‌ای (Professional Summary)
              </h4>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                {profile.summary}
              </p>
            </div>

            {/* Skills Chips */}
            <div className="space-y-2.5">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                مهارت‌های کلیدی استخراج‌شده ({profile.skills.length} مورد)
              </h4>
              <div className="flex flex-wrap gap-2">
                {profile.skills.map((skill, idx) => (
                  <span
                    key={idx}
                    className="text-xs px-3 py-1.5 rounded-xl bg-violet-500/10 text-violet-800 dark:text-violet-200 border border-violet-500/20 font-medium"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>

            {/* Experience Timeline */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
                <Briefcase className="w-4 h-4 text-slate-400" />
                <span>سوابق کاری و تجربیات شغلی</span>
              </h4>

              <div className="space-y-4">
                {profile.experiences.map((exp) => (
                  <div
                    key={exp.id}
                    className="p-4 rounded-2xl bg-slate-50/70 dark:bg-slate-800/40 border border-slate-200/60 dark:border-slate-700/60 space-y-2"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                      <span className="text-sm font-bold text-slate-900 dark:text-white">
                        {exp.role} — <span className="text-slate-600 dark:text-slate-300">{exp.company}</span>
                      </span>
                      <span className="text-xs text-slate-500 font-mono">
                        {exp.period}
                      </span>
                    </div>

                    <p className="text-xs text-slate-600 dark:text-slate-400">
                      {exp.description}
                    </p>

                    <ul className="list-disc list-inside space-y-1 text-xs text-slate-700 dark:text-slate-300 pr-2">
                      {exp.highlights.map((h, hIdx) => (
                        <li key={hIdx}>{h}</li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>

            {/* Education */}
            <div className="space-y-2.5">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
                <GraduationCap className="w-4 h-4 text-slate-400" />
                <span>تحصیلات و مدارک دانشگاهی</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {profile.education.map((edu) => (
                  <div
                    key={edu.id}
                    className="p-3.5 rounded-2xl bg-slate-50/70 dark:bg-slate-800/40 border border-slate-200/60 dark:border-slate-700/60"
                  >
                    <span className="text-xs font-bold text-slate-900 dark:text-white block">
                      {edu.degree} {edu.field}
                    </span>
                    <span className="text-xs text-slate-500 block mt-0.5">
                      {edu.university} (فارغ‌التحصیلی {edu.year})
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </GlassCard>

          {/* Bottom Next Step Bar */}
          <div className="flex items-center justify-between p-4 rounded-2xl bg-white/60 dark:bg-slate-900/60 border border-slate-200/60 dark:border-slate-800/60 backdrop-blur-md">
            <span className="text-xs text-slate-500 dark:text-slate-400">
              اطلاعات فوق در مراحل سنجش تطابق و تولید رزومه به کار گرفته می‌شوند.
            </span>
            <GradientButton
              size="md"
              variant="primary"
              onClick={() => navigate('/preferences')}
              leftIcon={<ArrowLeft className="w-4 h-4" />}
            >
              ادامه به مرحله ترجیحات شغلی
            </GradientButton>
          </div>
        </div>
      )}
    </div>
  );
};
