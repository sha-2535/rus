import React, { useState, useEffect } from 'react';
import {
  FileText,
  Wand2,
  Download,
  Copy,
  Send,
  ArrowRight,
  Sparkles,
  Check,
  RotateCcw,
  Tag,
  Mail,
  History,
  CheckCircle2,
  BookOpen
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { GlassCard } from '../components/common/GlassCard';
import { GradientButton } from '../components/common/GradientButton';

export const TailorResumePage: React.FC<{ jobId: string }> = ({ jobId }) => {
  const {
    jobs,
    profile,
    tailoredResumes,
    generateTailoredResume,
    submitFeedbackToTailor,
    isTailoringLoading,
    navigate,
    addToast
  } = useApp();

  const [activeTab, setActiveTab] = useState<'resume' | 'coverLetter'>('resume');
  const [feedbackInput, setFeedbackInput] = useState('');
  const [isCopied, setIsCopied] = useState(false);

  const job = jobs.find((j) => j.id === jobId) || jobs[0];
  const tailoredResume = tailoredResumes[job.id];

  // If no tailored resume exists for this job, auto-trigger generation on page load
  useEffect(() => {
    if (!tailoredResume && !isTailoringLoading) {
      generateTailoredResume(job.id);
    }
  }, [job.id, tailoredResume, isTailoringLoading, generateTailoredResume]);

  const handleApplyFeedback = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedbackInput.trim()) return;

    const ok = await submitFeedbackToTailor(job.id, feedbackInput.trim());
    if (ok) {
      setFeedbackInput('');
    }
  };

  const handleCopyText = () => {
    if (!tailoredResume) return;

    let textToCopy = '';
    if (activeTab === 'resume') {
      textToCopy = `رزومه اختصاصی: ${profile.fullName}\nعنوان: ${tailoredResume.content.headline}\n\nخلاصه:\n${tailoredResume.content.summary}\n\nمهارت‌های برجسته:\n${tailoredResume.content.highlightedSkills.join('، ')}\n\nسوابق کاری:\n${tailoredResume.content.tailoredExperiences
        .map(
          (exp) =>
            `${exp.role} - ${exp.company} (${exp.period}):\n${exp.bulletPoints
              .map((b) => `- ${b.text}`)
              .join('\n')}`
        )
        .join('\n\n')}`;
    } else {
      textToCopy = tailoredResume.content.coverLetter;
    }

    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(textToCopy);
      setIsCopied(true);
      addToast('متن کپی شد', 'محتوا در کلیپ‌بورد کپی شد', 'success');
      setTimeout(() => setIsCopied(false), 2000);
    }
  };

  const handleDownload = () => {
    if (!tailoredResume) return;

    const content = activeTab === 'resume'
      ? `${tailoredResume.content.headline}\n${tailoredResume.content.summary}\n\n${tailoredResume.content.coverLetter}`
      : tailoredResume.content.coverLetter;

    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `رزومه_سفارشی_${job.company}_${profile.fullName}.txt`;
    link.click();
    URL.revokeObjectURL(url);

    addToast('دانلود فایل آغاز شد', `نسخه سفارشی برای ${job.company} با موفقیت دریافت گردید`, 'success');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 pb-16">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pt-4">
        <div>
          <button
            onClick={() => navigate(`/jobs/${job.id}`)}
            className="inline-flex items-center gap-1.5 text-xs text-slate-500 hover:text-violet-600 mb-2 cursor-pointer transition-colors"
          >
            <ArrowRight className="w-3.5 h-3.5" />
            <span>بازگشت به آگهی {job.company}</span>
          </button>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
            سفارشی‌سازی رزومه برای موقعیت «{job.title}»
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            شرکت هدف: <span className="font-semibold text-slate-700 dark:text-slate-200">{job.company}</span>
            {tailoredResume && (
              <span className="mr-3 text-violet-600 dark:text-violet-400 font-mono">
                (نگارش نسخه {tailoredResume.content.version})
              </span>
            )}
          </p>
        </div>

        {/* Action Controls & Tab Switcher */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Tabs */}
          <div className="p-1 rounded-2xl bg-slate-200/60 dark:bg-slate-800/60 flex items-center">
            <button
              onClick={() => setActiveTab('resume')}
              className={`
                px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5
                ${
                  activeTab === 'resume'
                    ? 'bg-white dark:bg-slate-900 text-violet-700 dark:text-violet-300 shadow-sm'
                    : 'text-slate-600 dark:text-slate-400'
                }
              `}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>رزومه تطبیق‌یافته</span>
            </button>

            <button
              onClick={() => setActiveTab('coverLetter')}
              className={`
                px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5
                ${
                  activeTab === 'coverLetter'
                    ? 'bg-white dark:bg-slate-900 text-violet-700 dark:text-violet-300 shadow-sm'
                    : 'text-slate-600 dark:text-slate-400'
                }
              `}
            >
              <Mail className="w-3.5 h-3.5" />
              <span>کاور لتر اختصاصی</span>
            </button>
          </div>

          <button
            onClick={handleCopyText}
            className="p-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white/70 dark:bg-slate-800/70 hover:border-violet-400 text-slate-700 dark:text-slate-200 text-xs font-medium flex items-center gap-1.5 cursor-pointer transition-all shadow-sm active:scale-95"
            title="کپی کردن متن"
          >
            {isCopied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
            <span className="hidden sm:inline">{isCopied ? 'کپی شد' : 'کپی متن'}</span>
          </button>

          <GradientButton
            size="sm"
            variant="primary"
            onClick={handleDownload}
            leftIcon={<Download className="w-4 h-4" />}
          >
            دانلود رزومه (PDF / TXT)
          </GradientButton>
        </div>
      </div>

      {/* Added Keywords Bar */}
      {tailoredResume && tailoredResume.content.addedKeywords.length > 0 && (
        <div className="p-4 rounded-2xl bg-gradient-to-l from-violet-500/10 via-purple-500/10 to-indigo-500/10 border border-violet-500/20 flex flex-wrap items-center gap-2">
          <span className="text-xs font-bold text-violet-900 dark:text-violet-200 flex items-center gap-1">
            <Tag className="w-3.5 h-3.5" />
            کلیدواژه‌های طلایی تزریق‌شده جهت تطبیق با ATS:
          </span>
          {tailoredResume.content.addedKeywords.map((kw, idx) => (
            <span
              key={idx}
              className="text-xs px-2.5 py-1 rounded-lg bg-white/80 dark:bg-slate-800/80 text-violet-700 dark:text-violet-300 border border-violet-500/20 font-medium"
            >
              {kw}
            </span>
          ))}
        </div>
      )}

      {/* Main Split View: Resume comparison or Cover Letter */}
      {activeTab === 'resume' ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
          {/* COLUMN 1: Original Resume */}
          <GlassCard className="p-6 sm:p-7 space-y-5">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200/60 dark:border-slate-800/60">
              <div className="space-y-0.5">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
                  نسخه اولیه
                </span>
                <h3 className="text-base font-bold text-slate-800 dark:text-slate-200">
                  رزومه عمومی کارجو
                </h3>
              </div>
              <span className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-500">
                بدون بهینه‌سازی
              </span>
            </div>

            {/* Profile summary */}
            <div className="space-y-1">
              <span className="text-xs font-bold text-slate-500 block">خلاصه رزومه:</span>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed bg-slate-50 dark:bg-slate-800/30 p-3 rounded-xl">
                {profile.summary}
              </p>
            </div>

            {/* Skills */}
            <div className="space-y-1.5">
              <span className="text-xs font-bold text-slate-500 block">مهارت‌ها:</span>
              <div className="flex flex-wrap gap-1.5">
                {profile.skills.slice(0, 8).map((sk, idx) => (
                  <span
                    key={idx}
                    className="text-[11px] px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"
                  >
                    {sk}
                  </span>
                ))}
              </div>
            </div>

            {/* Experiences */}
            <div className="space-y-3 pt-2">
              <span className="text-xs font-bold text-slate-500 block">سوابق شغلی:</span>
              {profile.experiences.map((exp) => (
                <div key={exp.id} className="space-y-1.5 text-xs">
                  <div className="font-bold text-slate-800 dark:text-slate-200">
                    {exp.role} — {exp.company}
                  </div>
                  <ul className="list-disc list-inside space-y-1 text-slate-600 dark:text-slate-400 pr-1">
                    {exp.highlights.map((h, i) => (
                      <li key={i}>{h}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </GlassCard>

          {/* COLUMN 2: Tailored Resume */}
          <GlassCard className="p-6 sm:p-7 space-y-5 border-violet-500/40" glow="violet">
            <div className="flex items-center justify-between pb-4 border-b border-violet-500/20">
              <div className="space-y-0.5">
                <span className="text-xs font-bold text-violet-600 dark:text-violet-400 uppercase tracking-wider block">
                  نسخه سفارشی هوشمند
                </span>
                <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-violet-500" />
                  رزومه اختصاصی برای {job.company}
                </h3>
              </div>
              <span className="text-[11px] px-2.5 py-1 rounded-lg bg-violet-500/10 text-violet-700 dark:text-violet-300 font-bold">
                نسخه {tailoredResume?.content.version || 1}
              </span>
            </div>

            {tailoredResume ? (
              <div className="space-y-5">
                {/* Headline */}
                <div className="p-3.5 rounded-2xl bg-violet-500/10 border border-violet-500/20 space-y-1">
                  <span className="text-[11px] font-bold text-violet-700 dark:text-violet-300 block">
                    عنوان شغلی هدفمندسازی‌شده:
                  </span>
                  <p className="text-xs font-semibold text-slate-900 dark:text-white">
                    {tailoredResume.content.headline}
                  </p>
                </div>

                {/* Tailored Summary */}
                <div className="space-y-1">
                  <span className="text-xs font-bold text-violet-600 dark:text-violet-400 block">
                    خلاصه بازنویسی‌شده با تأکید بر اهداف {job.company}:
                  </span>
                  <p className="text-xs text-slate-700 dark:text-slate-200 leading-relaxed bg-white/60 dark:bg-slate-800/60 p-3 rounded-xl border border-violet-500/10">
                    {tailoredResume.content.summary}
                  </p>
                </div>

                {/* Highlighted Skills */}
                <div className="space-y-1.5">
                  <span className="text-xs font-bold text-violet-600 dark:text-violet-400 block">
                    مهارت‌های دارای بالاترین اولویت در آگهی:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {tailoredResume.content.highlightedSkills.map((sk, idx) => (
                      <span
                        key={idx}
                        className="text-[11px] px-2.5 py-1 rounded-lg bg-gradient-to-l from-violet-600/15 to-fuchsia-600/15 text-violet-800 dark:text-violet-200 border border-violet-500/30 font-semibold"
                      >
                        ✓ {sk}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Tailored Experiences & Bullets */}
                <div className="space-y-3 pt-2">
                  <span className="text-xs font-bold text-violet-600 dark:text-violet-400 block">
                    بولت‌پوینت‌های بهینه‌سازی‌شده بر اساس دستاوردهای کمّی:
                  </span>
                  {tailoredResume.content.tailoredExperiences.map((exp, idx) => (
                    <div key={idx} className="space-y-2 text-xs">
                      <div className="font-bold text-slate-900 dark:text-white">
                        {exp.role} — {exp.company}
                      </div>
                      <ul className="space-y-2 text-slate-800 dark:text-slate-200">
                        {exp.bulletPoints.map((bp, bIdx) => (
                          <li
                            key={bIdx}
                            className={`p-2.5 rounded-xl border leading-relaxed ${
                              bp.isModified
                                ? 'bg-violet-500/5 border-violet-500/30'
                                : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700'
                            }`}
                          >
                            <span>{bp.text}</span>
                            {bp.keywordsAdded && bp.keywordsAdded.length > 0 && (
                              <div className="mt-1 flex gap-1">
                                {bp.keywordsAdded.map((k, ki) => (
                                  <span
                                    key={ki}
                                    className="text-[10px] text-violet-600 dark:text-violet-400 bg-violet-500/10 px-1.5 py-0.2 rounded"
                                  >
                                    +{k}
                                  </span>
                                ))}
                              </div>
                            )}
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="py-12 text-center text-xs text-slate-400">
                در حال تولید رزومه سفارشی...
              </div>
            )}
          </GlassCard>
        </div>
      ) : (
        /* COVER LETTER VIEW */
        <GlassCard className="p-6 sm:p-10 max-w-4xl mx-auto space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-200/60 dark:border-slate-800/60">
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                نامه انگیزه و همراهی (Cover Letter)
              </h2>
              <p className="text-xs text-slate-500">
                نگارش اختصاصی و متقاعدکننده خطاب به مسئول استخدام {job.company}
              </p>
            </div>
            <button
              onClick={handleCopyText}
              className="text-xs text-violet-600 dark:text-violet-400 font-semibold hover:underline cursor-pointer flex items-center gap-1"
            >
              <Copy className="w-3.5 h-3.5" />
              کپی متن نامه
            </button>
          </div>

          <div className="p-6 rounded-2xl bg-white/70 dark:bg-slate-900/70 border border-slate-200 dark:border-slate-800 text-xs sm:text-sm text-slate-800 dark:text-slate-200 leading-loose whitespace-pre-line font-serif">
            {tailoredResume?.content.coverLetter || 'در حال آماده‌سازی کاور لتر...'}
          </div>
        </GlassCard>
      )}

      {/* FEEDBACK LOOP CONTAINER (BOTTOM ACTION) */}
      <GlassCard className="p-6 space-y-3 bg-gradient-to-br from-violet-500/5 via-fuchsia-500/5 to-transparent border-violet-500/30">
        <div className="flex items-center gap-2">
          <Wand2 className="w-4 h-4 text-violet-600 dark:text-violet-400" />
          <h3 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
            حلقهٔ بازخورد هوشمند با ایجنت (Agent Feedback Loop)
          </h3>
        </div>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          دستور مورد نظر خود را برای اصلاح رزومه بنویسید (مثلاً: «پروژه‌های فرانت‌اند را پررنگ‌تر کن» یا «لحن رسمی‌تر شود») تا ایجنت رزومه را بلافاصله بازنویسی کند.
        </p>

        <form onSubmit={handleApplyFeedback} className="flex gap-2 pt-1">
          <input
            type="text"
            value={feedbackInput}
            onChange={(e) => setFeedbackInput(e.target.value)}
            placeholder="بازخورد خود را بنویسید (مثلاً: پروژه‌ها را پررنگ‌تر کن)..."
            className="flex-1 p-3.5 rounded-2xl bg-white/80 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500"
          />

          <GradientButton
            type="submit"
            variant="primary"
            size="md"
            isLoading={isTailoringLoading}
            leftIcon={<Send className="w-4 h-4" />}
          >
            اعمال بازخورد
          </GradientButton>
        </form>

        {/* Feedback suggestions chips */}
        <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
          <span className="text-slate-400">پیشنهادها:</span>
          {[
            'پروژه‌ها را پررنگ‌تر کن',
            'بخش Next.js و بهینه‌سازی را بیشتر توضیح بده',
            'لحن نامه کاور لتر را مشتاقانه‌تر کن',
            'متریک‌های عملکردی را اولویت بده'
          ].map((suggestion, sIdx) => (
            <button
              key={sIdx}
              type="button"
              onClick={() => setFeedbackInput(suggestion)}
              className="text-[11px] px-2.5 py-1 rounded-xl bg-white/70 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-violet-400 hover:text-violet-600 transition-colors cursor-pointer"
            >
              {suggestion}
            </button>
          ))}
        </div>
      </GlassCard>
    </div>
  );
};
