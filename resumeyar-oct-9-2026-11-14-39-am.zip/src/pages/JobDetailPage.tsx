import React, { useState } from 'react';
import {
  MapPin,
  Building2,
  DollarSign,
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  Briefcase,
  Share2
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { GlassCard } from '../components/common/GlassCard';
import { GradientButton } from '../components/common/GradientButton';
import { MatchScoreRing } from '../components/common/MatchScoreRing';

export const JobDetailPage: React.FC<{ jobId: string }> = ({ jobId }) => {
  const { jobs, matchResults, analyzeJobMatch, matchingJobIds, navigate, addToast } = useApp();

  const [isWhyScoreExpanded, setIsWhyScoreExpanded] = useState(true);

  const job = jobs.find((j) => j.id === jobId) || jobs[0];
  const match = matchResults[job.id];
  const isMatching = matchingJobIds[job.id];

  const handleShare = () => {
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      addToast('لینک آگهی کپی شد', 'آدرس صفحه در کلیپ‌بورد قرار گرفت', 'info');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 pb-16">
      {/* Top Navigation Back */}
      <div className="flex items-center justify-between pt-4">
        <button
          onClick={() => navigate('/jobs')}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-violet-600 dark:hover:text-violet-400 transition-colors cursor-pointer"
        >
          <ArrowRight className="w-4 h-4" />
          <span>بازگشت به فهرست آگهی‌ها</span>
        </button>

        <button
          onClick={handleShare}
          className="inline-flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 cursor-pointer"
        >
          <Share2 className="w-3.5 h-3.5" />
          <span>اشتراک‌گذاری</span>
        </button>
      </div>

      {/* Main Two-Column Layout (Job Details & Match Analysis) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* RIGHT COLUMN (RTL): Job Details (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          <GlassCard className="p-6 sm:p-8 space-y-6">
            {/* Header info */}
            <div className="space-y-3 pb-6 border-b border-slate-200/60 dark:border-slate-800/60">
              <div className="flex items-center gap-2 text-xs font-semibold text-violet-600 dark:text-violet-400">
                <Building2 className="w-4 h-4" />
                <span>{job.company}</span>
              </div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
                {job.title}
              </h1>

              <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 dark:text-slate-400 pt-1">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5" />
                  {job.location}
                </span>
                <span aria-hidden="true">·</span>
                <span className="font-semibold text-emerald-600 dark:text-emerald-400">
                  {job.salaryRange || 'توافقی'}
                </span>
                <span aria-hidden="true">·</span>
                <span>انتشار: {job.postedAt}</span>
              </div>
            </div>

            {/* Job Description */}
            <div className="space-y-2">
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                درباره این موقعیت شغلی
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                {job.description}
              </p>
            </div>

            {/* Requirements */}
            <div className="space-y-3">
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                مهارت‌ها و نیازمندی‌های احراز شغل
              </h2>
              <ul className="space-y-2 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
                {job.requirements.map((req, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-violet-500 mt-2 shrink-0" />
                    <span>{req}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Benefits */}
            {job.benefits && job.benefits.length > 0 && (
              <div className="space-y-3 pt-2">
                <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                  مزایا و امکانات رفاهی
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {job.benefits.map((ben, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/60 dark:border-slate-700/60 text-xs text-slate-700 dark:text-slate-300 flex items-center gap-2"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      <span>{ben}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </GlassCard>
        </div>

        {/* LEFT COLUMN (RTL): Match Analysis & AI Recommendations (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          {match ? (
            <GlassCard className="p-6 sm:p-8 space-y-6 border-violet-500/30">
              {/* Score Header */}
              <div className="flex flex-col items-center text-center space-y-3 pb-6 border-b border-slate-200/60 dark:border-slate-800/60">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                  نمره تطابق هوشمند با رزومه شما
                </span>
                <MatchScoreRing score={match.score} size="xl" showLabel />
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed max-w-sm">
                  {match.summary}
                </p>
              </div>

              {/* Strengths (نقاط قوت) */}
              <div className="space-y-2.5">
                <h3 className="text-xs font-bold text-emerald-700 dark:text-emerald-400 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>نقاط قوت برجسته در این موقعیت</span>
                </h3>
                <ul className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300 pr-1">
                  {match.strengths.map((str, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-emerald-500 font-bold shrink-0">✓</span>
                      <span>{str}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Gaps (شکاف‌ها) */}
              {match.gaps.length > 0 && (
                <div className="space-y-2.5 pt-2">
                  <h3 className="text-xs font-bold text-amber-700 dark:text-amber-400 flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4" />
                    <span>شکاف‌ها و موارد نیازمند ارتقا</span>
                  </h3>
                  <ul className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300 pr-1">
                    {match.gaps.map((gap, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="text-amber-500 font-bold shrink-0">!</span>
                        <span>{gap}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* "چرا این نمره؟" Expandable Reasoning */}
              <div className="pt-2 border-t border-slate-200/60 dark:border-slate-800/60">
                <button
                  type="button"
                  onClick={() => setIsWhyScoreExpanded(!isWhyScoreExpanded)}
                  className="w-full flex items-center justify-between text-xs font-bold text-slate-900 dark:text-white py-2 cursor-pointer hover:text-violet-600 transition-colors"
                >
                  <span className="flex items-center gap-1.5">
                    <HelpCircle className="w-4 h-4 text-violet-500" />
                    <span>چرا این نمره؟ تحلیل شفاف ایجنت</span>
                  </span>
                  {isWhyScoreExpanded ? (
                    <ChevronUp className="w-4 h-4 text-slate-400" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-slate-400" />
                  )}
                </button>

                {isWhyScoreExpanded && (
                  <div className="p-3.5 rounded-2xl bg-violet-500/10 border border-violet-500/20 text-xs text-slate-700 dark:text-slate-300 leading-relaxed mt-2 animate-in fade-in">
                    {match.agentReasoning}
                  </div>
                )}
              </div>

              {/* Action CTA */}
              <div className="pt-4">
                <GradientButton
                  size="lg"
                  variant="primary"
                  className="w-full"
                  onClick={() => navigate(`/tailor/${job.id}`)}
                  leftIcon={<ArrowLeft className="w-4 h-4" />}
                >
                  رزومه اختصاصی این آگهی را بساز
                </GradientButton>
              </div>
            </GlassCard>
          ) : (
            <GlassCard className="p-8 text-center space-y-4">
              <Sparkles className="w-10 h-10 text-violet-500 mx-auto" />
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                هنوز تناسب سنجیده نشده است
              </h3>
              <p className="text-xs text-slate-500">
                برای مشاهده درصد هم‌پوشانی، نقاط قوت و شناسایی شکاف‌های فنی، تحلیل هوشمند را فعال نمایید.
              </p>
              <div className="pt-2">
                <GradientButton
                  variant="primary"
                  size="md"
                  isLoading={isMatching}
                  onClick={() => analyzeJobMatch(job.id)}
                  leftIcon={<Sparkles className="w-4 h-4" />}
                >
                  تحلیل تناسب با هوش مصنوعی
                </GradientButton>
              </div>
            </GlassCard>
          )}
        </div>
      </div>
    </div>
  );
};
