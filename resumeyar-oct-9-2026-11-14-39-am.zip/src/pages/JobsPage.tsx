import React from 'react';
import {
  Search,
  Filter,
  Briefcase,
  Sparkles,
  SlidersHorizontal,
  RefreshCw
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { JobCard } from '../components/jobs/JobCard';
import { GlassCard } from '../components/common/GlassCard';
import { GradientButton } from '../components/common/GradientButton';

export const JobsPage: React.FC = () => {
  const {
    jobs,
    searchQuery,
    setSearchQuery,
    seniorityFilter,
    setSeniorityFilter,
    workStyleFilter,
    setWorkStyleFilter,
    matchResults,
    matchingJobIds,
    analyzeJobMatch,
    navigate
  } = useApp();

  const handleMatchAll = async () => {
    // Sequentially trigger matching for all unmatched jobs
    for (const job of jobs) {
      if (!matchResults[job.id]) {
        await analyzeJobMatch(job.id);
      }
    }
  };

  const unmatchedCount = jobs.filter((j) => !matchResults[j.id]).length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 pb-16">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pt-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-700 dark:text-indigo-300 text-xs font-semibold mb-2">
            <Briefcase className="w-3.5 h-3.5" />
            <span>فرصت‌های شغلی منتخب</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
            آگهی‌های استخدامی و تحلیل تناسب
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            موقعیت‌های فعال در شرکت‌های فناوری پیشرو؛ با کلیک روی هر آگهی، تناسب رزومه خود را بسنجید.
          </p>
        </div>

        {unmatchedCount > 0 && (
          <GradientButton
            variant="glass"
            size="md"
            onClick={handleMatchAll}
            rightIcon={<Sparkles className="w-4 h-4 text-violet-500" />}
          >
            تحلیل خودکار همه آگهی‌ها ({unmatchedCount} آگهی)
          </GradientButton>
        )}
      </div>

      {/* Search & Filter Bar */}
      <GlassCard className="p-4 sm:p-5">
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center gap-4">
          {/* Search Input */}
          <div className="relative flex-1">
            <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center pointer-events-none text-slate-400">
              <Search className="w-4 h-4" />
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="جستجو در عنوان شغلی، شرکت، یا مهارت‌ها (مثلاً: دیجی‌کالا یا فرانت‌اند)..."
              className="w-full pr-10 pl-4 py-2.5 rounded-2xl bg-white/70 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 transition-all"
            />
          </div>

          {/* Filter Dropdowns */}
          <div className="flex flex-wrap sm:flex-nowrap items-center gap-3 shrink-0">
            {/* Seniority Filter */}
            <div className="w-full sm:w-auto">
              <select
                value={seniorityFilter}
                onChange={(e) => setSeniorityFilter(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-2xl bg-white/70 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 text-xs text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-violet-500/20"
              >
                <option value="all">تمام سطوح ارشدیت</option>
                <option value="junior">جونیور (مبتدی)</option>
                <option value="mid">میدلول (متوسط)</option>
                <option value="senior">سنیور (ارشد)</option>
                <option value="lead">لید / مدیریت</option>
              </select>
            </div>

            {/* Work Style Filter */}
            <div className="w-full sm:w-auto">
              <select
                value={workStyleFilter}
                onChange={(e) => setWorkStyleFilter(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-2xl bg-white/70 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 text-xs text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-violet-500/20"
              >
                <option value="all">تمامی مدل‌های کاری</option>
                <option value="remote">فقط دورکاری کامل</option>
                <option value="hybrid">هیبرید (ترکیبی)</option>
                <option value="onsite">حضوری</option>
              </select>
            </div>
          </div>
        </div>
      </GlassCard>

      {/* Jobs Grid */}
      {jobs.length === 0 ? (
        <GlassCard className="p-12 text-center space-y-3">
          <Briefcase className="w-12 h-12 text-slate-400 mx-auto" />
          <h3 className="text-base font-bold text-slate-800 dark:text-slate-200">
            هیچ موقعیت شغلی متناسب با فیلترها یافت نشد
          </h3>
          <p className="text-xs text-slate-500">
            می‌توانید عبارت جستجو را تغییر داده یا فیلترهای سطح و مدل کاری را پاک کنید.
          </p>
          <div className="pt-2">
            <GradientButton
              size="sm"
              variant="glass"
              onClick={() => {
                setSearchQuery('');
                setSeniorityFilter('all');
                setWorkStyleFilter('all');
              }}
            >
              پاکسازی فیلترها
            </GradientButton>
          </div>
        </GlassCard>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {jobs.map((job) => (
            <JobCard
              key={job.id}
              job={job}
              match={matchResults[job.id]}
              isMatching={matchingJobIds[job.id]}
              onAnalyzeMatch={(id) => analyzeJobMatch(id)}
              onViewDetails={(id) => navigate(`/jobs/${id}`)}
              onTailorResume={(id) => navigate(`/tailor/${id}`)}
            />
          ))}
        </div>
      )}
    </div>
  );
};
