import React, { useState } from 'react';
import { Mail, Lock, User, ArrowLeft, Sparkles, CheckCircle2 } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { GlassCard } from '../components/common/GlassCard';
import { GradientButton } from '../components/common/GradientButton';

interface AuthPageProps {
  mode: 'login' | 'register';
}

export const AuthPage: React.FC<AuthPageProps> = ({ mode: initialMode }) => {
  const { login, register, navigate } = useApp();
  const [isRegister, setIsRegister] = useState(initialMode === 'register');

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<{ name?: string; email?: string; password?: string }>({});

  const validate = () => {
    const newErrors: { name?: string; email?: string; password?: string } = {};

    if (isRegister && (!name || name.trim().length < 2)) {
      newErrors.name = 'لطفاً نام و نام خانوادگی خود را کامل وارد کنید';
    }

    if (!email || !email.includes('@') || !email.includes('.')) {
      newErrors.email = 'لطفاً یک آدرس ایمیل معتبر وارد کنید';
    }

    if (!password || password.length < 6) {
      newErrors.password = 'رمز عبور باید حداقل ۶ کاراکتر باشد';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsLoading(true);

    if (isRegister) {
      const ok = await register({ name, email, password });
      setIsLoading(false);
      if (ok) {
        navigate('/dashboard');
      }
    } else {
      const ok = await login({ email, password });
      setIsLoading(false);
      if (ok) {
        navigate('/dashboard');
      }
    }
  };

  return (
    <div className="min-h-[calc(100vh-14rem)] flex items-center justify-center py-10 px-4">
      {/* Ambient background glow */}
      <div className="absolute w-96 h-96 bg-violet-500/10 dark:bg-violet-600/10 rounded-full blur-3xl pointer-events-none -z-10" />

      <div className="w-full max-w-md">
        <GlassCard elevation="high" className="p-8 sm:p-10 border-white/60 dark:border-white/10 shadow-2xl">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-flex w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-600 via-violet-600 to-fuchsia-600 items-center justify-center text-white shadow-lg shadow-violet-500/25 mb-4">
              <Sparkles className="w-6 h-6" />
            </div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
              {isRegister ? 'ایجاد حساب در رزومه یار' : 'ورود به حساب کاربری'}
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1.5">
              {isRegister
                ? 'به جمع هزاران کارجوی هوشمند در مسیر موفقیت بپیوندید'
                : 'برای مدیریت رزومه‌ها و پیگیری آگهی‌ها وارد شوید'}
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {isRegister && (
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  نام و نام خانوادگی
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center pointer-events-none text-slate-400">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => {
                      setName(e.target.value);
                      if (errors.name) setErrors((prev) => ({ ...prev, name: undefined }));
                    }}
                    placeholder="مثال: امیرحسین رضایی"
                    className={`
                      w-full pr-10 pl-3.5 py-2.5 rounded-2xl text-xs sm:text-sm
                      bg-white/70 dark:bg-slate-800/70 border
                      ${errors.name ? 'border-rose-500 focus:ring-rose-500/20' : 'border-slate-200 dark:border-slate-700 focus:border-violet-500'}
                      text-slate-900 dark:text-white placeholder:text-slate-400
                      focus:outline-none focus:ring-2 focus:ring-violet-500/20 transition-all
                    `}
                  />
                </div>
                {errors.name && (
                  <p className="text-[11px] text-rose-500 mt-1">{errors.name}</p>
                )}
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                آدرس ایمیل
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center pointer-events-none text-slate-400">
                  <Mail className="w-4 h-4" />
                </div>
                <input
                  type="email"
                  dir="ltr"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    if (errors.email) setErrors((prev) => ({ ...prev, email: undefined }));
                  }}
                  placeholder="name@example.com"
                  className={`
                    w-full pr-10 pl-3.5 py-2.5 rounded-2xl text-xs sm:text-sm font-sans
                    bg-white/70 dark:bg-slate-800/70 border
                    ${errors.email ? 'border-rose-500 focus:ring-rose-500/20' : 'border-slate-200 dark:border-slate-700 focus:border-violet-500'}
                    text-slate-900 dark:text-white placeholder:text-slate-400
                    focus:outline-none focus:ring-2 focus:ring-violet-500/20 transition-all
                  `}
                />
              </div>
              {errors.email && (
                <p className="text-[11px] text-rose-500 mt-1">{errors.email}</p>
              )}
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                رمز عبور
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center pointer-events-none text-slate-400">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type="password"
                  dir="ltr"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (errors.password) setErrors((prev) => ({ ...prev, password: undefined }));
                  }}
                  placeholder="••••••••"
                  className={`
                    w-full pr-10 pl-3.5 py-2.5 rounded-2xl text-xs sm:text-sm font-sans
                    bg-white/70 dark:bg-slate-800/70 border
                    ${errors.password ? 'border-rose-500 focus:ring-rose-500/20' : 'border-slate-200 dark:border-slate-700 focus:border-violet-500'}
                    text-slate-900 dark:text-white placeholder:text-slate-400
                    focus:outline-none focus:ring-2 focus:ring-violet-500/20 transition-all
                  `}
                />
              </div>
              {errors.password && (
                <p className="text-[11px] text-rose-500 mt-1">{errors.password}</p>
              )}
            </div>

            <div className="pt-2">
              <GradientButton
                type="submit"
                variant="primary"
                size="lg"
                isLoading={isLoading}
                className="w-full"
                leftIcon={<ArrowLeft className="w-4 h-4" />}
              >
                {isRegister ? 'ثبت نام و شروع کار' : 'ورود به حساب کاربری'}
              </GradientButton>
            </div>
          </form>

          {/* Switch Mode Footer */}
          <div className="mt-6 pt-6 border-t border-slate-200/60 dark:border-slate-800/60 text-center text-xs text-slate-600 dark:text-slate-400">
            {isRegister ? (
              <span>
                قبلاً ثبت‌نام کرده‌اید؟{' '}
                <button
                  type="button"
                  onClick={() => setIsRegister(false)}
                  className="text-violet-600 dark:text-violet-400 font-bold hover:underline cursor-pointer"
                >
                  وارد شوید
                </button>
              </span>
            ) : (
              <span>
                حساب کاربری ندارید؟{' '}
                <button
                  type="button"
                  onClick={() => setIsRegister(true)}
                  className="text-violet-600 dark:text-violet-400 font-bold hover:underline cursor-pointer"
                >
                  حساب جدید بسازید
                </button>
              </span>
            )}
          </div>
        </GlassCard>
      </div>
    </div>
  );
};
