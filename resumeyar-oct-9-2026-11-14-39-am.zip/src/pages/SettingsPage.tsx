import React from 'react';
import {
  Settings,
  User,
  Moon,
  Sun,
  Globe,
  LogOut,
  RotateCcw,
  ShieldCheck,
  Code
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { GlassCard } from '../components/common/GlassCard';
import { GradientButton } from '../components/common/GradientButton';

export const SettingsPage: React.FC = () => {
  const { user, theme, toggleTheme, logout, addToast, navigate } = useApp();

  const handleResetData = () => {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('resumeyar_profile');
      localStorage.removeItem('resumeyar_preferences');
      localStorage.removeItem('resumeyar_match_results');
      localStorage.removeItem('resumeyar_tailored_resumes');
      localStorage.removeItem('resumeyar_agent_steps');
    }
    addToast('بازنشانی داده‌ها انجام شد', 'اطلاعات به وضعیت پیش‌فرض اولیه برگشت', 'info');
    setTimeout(() => {
      window.location.reload();
    }, 500);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 pb-16">
      {/* Header */}
      <div className="pt-4">
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
          تنظیمات و حساب کاربری
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
          مدیریت تم ظاهری، اطلاعات کاربری و وضعیت سامانه
        </p>
      </div>

      <div className="space-y-6">
        {/* Profile Card */}
        <GlassCard className="p-6 sm:p-8 space-y-6">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <User className="w-4 h-4 text-violet-500" />
            <span>مشخصات حساب کاربری</span>
          </h2>

          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <img
                src={user?.avatarUrl || '/src/assets/images/persian_user_avatar_1791568791198.jpg'}
                alt={user?.name || 'کاربر'}
                className="w-14 h-14 rounded-2xl object-cover border-2 border-violet-500/20"
                referrerPolicy="no-referrer"
              />
              <div className="space-y-0.5">
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  {user?.name || 'کاربر رزومه یار'}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                  {user?.email || 'user@example.com'}
                </p>
                <span className="inline-block text-[10px] text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full font-medium">
                  حساب کاربری فعال (نسخه پرمیوم دمو)
                </span>
              </div>
            </div>

            <GradientButton
              size="sm"
              variant="outline"
              onClick={logout}
              leftIcon={<LogOut className="w-3.5 h-3.5" />}
            >
              خروج از حساب
            </GradientButton>
          </div>
        </GlassCard>

        {/* Appearance & Theme Card */}
        <GlassCard className="p-6 sm:p-8 space-y-6">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            {theme === 'dark' ? <Moon className="w-4 h-4 text-amber-400" /> : <Sun className="w-4 h-4 text-indigo-500" />}
            <span>ظاهر و تم سامانه</span>
          </h2>

          <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/60 dark:border-slate-700/60">
            <div>
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
                حالت رنگی (روشن / تاریک)
              </span>
              <p className="text-[11px] text-slate-500 mt-0.5">
                فعلاً در حالت «{theme === 'dark' ? 'تم تاریک (Dark Mode)' : 'تم روشن (Light Mode)'}» هستید.
              </p>
            </div>

            <button
              onClick={toggleTheme}
              className="px-4 py-2 rounded-xl text-xs font-semibold bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-800 dark:text-slate-200 hover:border-violet-500 transition-all cursor-pointer shadow-sm"
            >
              تغییر به {theme === 'dark' ? 'تم روشن' : 'تم تاریک'}
            </button>
          </div>
        </GlassCard>

        {/* Language & Localization */}
        <GlassCard className="p-6 sm:p-8 space-y-6">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Globe className="w-4 h-4 text-sky-500" />
            <span>زبان و چیدمان (Localization)</span>
          </h2>

          <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/60 dark:border-slate-700/60 text-xs">
            <div>
              <span className="font-bold text-slate-800 dark:text-slate-200 block">
                زبان پیش‌فرض رابط کاربری
              </span>
              <p className="text-[11px] text-slate-500 mt-0.5">
                فارسی (چیدمان کامل راست‌به‌چپ RTL با قلم وزیرمتن)
              </p>
            </div>
            <span className="px-3 py-1.5 rounded-xl bg-violet-500/10 text-violet-700 dark:text-violet-300 font-semibold text-xs">
              فارسی (FA)
            </span>
          </div>
        </GlassCard>

        {/* Developer & FastAPI Backend info */}
        <GlassCard className="p-6 sm:p-8 space-y-4">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Code className="w-4 h-4 text-emerald-500" />
            <span>اتصال به بک‌اند اختصاصی (FastAPI Ready)</span>
          </h2>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            لایه‌بندی ارتباطی در <code className="text-violet-600 dark:text-violet-400 font-mono">/lib/api.ts</code> با قراردادهای FastAPI طراحی شده است. با تنظیم متغیر <code className="text-violet-600 dark:text-violet-400 font-mono">NEXT_PUBLIC_API_URL</code> در فایل <code className="font-mono">.env</code>، درخواست‌ها مستقیماً به سرور واقعی ارسال خواهند شد.
          </p>

          <div className="pt-2 flex justify-between items-center">
            <span className="text-xs text-slate-400">
              پاکسازی کش موقت و بازنشانی دمو:
            </span>
            <button
              onClick={handleResetData}
              className="text-xs text-rose-600 hover:text-rose-700 font-semibold flex items-center gap-1 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>بازنشانی به حالت کارخانه</span>
            </button>
          </div>
        </GlassCard>
      </div>
    </div>
  );
};
