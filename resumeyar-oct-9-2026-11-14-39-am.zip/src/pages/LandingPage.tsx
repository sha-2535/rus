import React from 'react';
import {
  Sparkles,
  ArrowLeft,
  FileCheck2,
  Cpu,
  RefreshCw,
  Search,
  Sliders,
  CheckCircle2,
  ShieldCheck,
  TrendingUp,
  Award
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { GlassCard } from '../components/common/GlassCard';
import { GradientButton } from '../components/common/GradientButton';

export const LandingPage: React.FC = () => {
  const { navigate, isAuthenticated } = useApp();

  const handleStart = () => {
    if (isAuthenticated) {
      navigate('/dashboard');
    } else {
      navigate('/register');
    }
  };

  const featureCards = [
    {
      icon: <Search className="w-6 h-6 text-indigo-500" />,
      title: 'تحلیل هوشمند آگهی‌ها',
      description:
        'استخراج خودکار مهارت‌های پنهان، ملزومات کلیدی و فرهنگ سازمانی هر آگهی استخدامی و تطبیق برداری آن با سوابق شما با تعیین نمره دقیق تناسب (۰ تا ۱۰۰).'
    },
    {
      icon: <FileCheck2 className="w-6 h-6 text-violet-500" />,
      title: 'ساخت رزومه اختصاصی',
      description:
        'بازنویسی هدفمند تجربیات کاری، بازآرایی اولویت دستاوردها و تزریق کلیدواژه‌های طلایی مطابق با سیستم‌های ATS و نیاز مدیران استخدام.'
    },
    {
      icon: <RefreshCw className="w-6 h-6 text-fuchsia-500" />,
      title: 'حلقهٔ بازخورد با ایجنت',
      description:
        'گفتگوی تعاملی و بی‌درنگ با ایجنت هوشمند؛ دستوراتی نظیر «پروژه‌ها را پررنگ‌تر کن» یا «بخش بک‌اند را تقویت کن» بدهید و بلافاصله نگارش جدید رزومه را تحویل بگیرید.'
    }
  ];

  const steps = [
    {
      num: '۰۱',
      title: 'آپلود رزومه اولیه',
      desc: 'فایل رزومه خود را (PDF یا Word) بارگذاری کنید تا تمام مهارت‌ها و سوابق در چند ثانیه استخراج شوند.',
      icon: <FileCheck2 className="w-5 h-5 text-indigo-500" />
    },
    {
      num: '۰۲',
      title: 'تعیین ترجیحات شغلی',
      desc: 'سطح ارشدیت، بازه حقوق مدنظر، شهرهای هدف و مدل کاری (دورکاری یا حضوری) را مشخص کنید.',
      icon: <Sliders className="w-5 h-5 text-violet-500" />
    },
    {
      num: '۰۳',
      title: 'سنجش تناسب آگهی‌ها',
      desc: 'ایجنت تمام فرصت‌های شغلی را اسکن کرده و نمره تناسب، نقاط قوت و شکاف‌های رزومه شما را شفاف می‌سازد.',
      icon: <Cpu className="w-5 h-5 text-purple-500" />
    },
    {
      num: '۰۴',
      title: 'تولید نسخه بهینه و ارسال',
      desc: 'با یک کلیک، رزومه سفارشی و کاور لتر اختصاصی متناسب با همان شرکت را دریافت و ارسال کنید.',
      icon: <Sparkles className="w-5 h-5 text-fuchsia-500" />
    }
  ];

  return (
    <div className="space-y-20 pb-16">
      {/* 1. HERO SECTION */}
      <section className="relative pt-10 sm:pt-16 lg:pt-20 text-center">
        {/* Ambient background glow behind hero */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[550px] h-[350px] bg-gradient-to-tr from-violet-600/15 via-fuchsia-500/15 to-indigo-500/15 blur-3xl pointer-events-none -z-10 rounded-full" />

        <div className="max-w-4xl mx-auto px-4 space-y-6">
          {/* Natural human editorial kicker */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-violet-500/10 border border-violet-500/20 text-xs font-semibold text-violet-700 dark:text-violet-300">
            <Sparkles className="w-3.5 h-3.5" />
            <span>نسل نوین کاریابی هوشمند با هوش مصنوعی مولد</span>
          </div>

          {/* Main Title */}
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-slate-900 dark:text-white tracking-tight leading-[1.25] text-balance">
            همراه هوشمند شما برای{' '}
            <span className="bg-gradient-to-l from-indigo-600 via-violet-600 to-fuchsia-600 bg-clip-text text-transparent">
              شکار بهترین فرصت‌های شغلی
            </span>
          </h1>

          {/* Value proposition subtitle */}
          <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto leading-relaxed">
            رزومه یار با تحلیل عمیق آگهی‌های استخدامی، درصد شانس شما را محاسبه کرده و برای هر موقعیت شغلی، رزومه‌ای کاملاً سفارشی‌شده و کاور لتر اختصاصی می‌سازد.
          </p>

          {/* CTA Action Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
            <GradientButton
              size="lg"
              variant="primary"
              onClick={handleStart}
              leftIcon={<ArrowLeft className="w-4 h-4" />}
            >
              شروع کن — رایگان
            </GradientButton>

            <GradientButton
              size="lg"
              variant="glass"
              onClick={() => navigate('/jobs')}
            >
              مشاهده آگهی‌های فعال
            </GradientButton>
          </div>

          {/* Social Proof metrics */}
          <div className="pt-8 flex flex-wrap items-center justify-center gap-6 sm:gap-12 text-slate-600 dark:text-slate-400 text-xs">
            <div className="flex items-center gap-1.5 font-medium">
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              <span>پشتیبانی کامل از زبان فارسی و فرمت‌های استاندارد</span>
            </div>
            <div className="flex items-center gap-1.5 font-medium">
              <ShieldCheck className="w-4 h-4 text-violet-500" />
              <span>سازگار با استانداردهای فیلترینگ ATS</span>
            </div>
            <div className="flex items-center gap-1.5 font-medium">
              <TrendingUp className="w-4 h-4 text-fuchsia-500" />
              <span>افزایش ۳ برابری نرخ دعوت به مصاحبه</span>
            </div>
          </div>
        </div>

        {/* Hero Product Mockup Preview */}
        <div className="max-w-5xl mx-auto px-4 mt-12 sm:mt-16">
          <div className="relative rounded-3xl p-2 sm:p-3 bg-gradient-to-b from-white/40 via-white/10 to-transparent dark:from-white/10 dark:via-white/5 border border-white/60 dark:border-white/10 backdrop-blur-2xl shadow-2xl">
            <img
              src="/src/assets/images/hero_resumeyar_preview_1791568771581.jpg"
              alt="پیش‌نمایش پیشخوان و تحلیل تناسب رزومه یار"
              className="w-full h-auto rounded-2xl shadow-lg border border-slate-200/40 dark:border-slate-800/60 object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
      </section>

      {/* 2. THREE CORE FEATURES */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            قدرت هوش مصنوعی در خدمت مسیر شغلی شما
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
            سه ستون اصلی پلتفرم رزومه یار که فرایند ارسال رزومه بدون هدف را دگرگون می‌کنند
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {featureCards.map((feat, idx) => (
            <GlassCard
              key={idx}
              hoverEffect
              glow="violet"
              className="p-7 flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-2xl bg-violet-500/10 border border-violet-500/20 flex items-center justify-center mb-5">
                  {feat.icon}
                </div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">
                  {feat.title}
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                  {feat.description}
                </p>
              </div>
            </GlassCard>
          ))}
        </div>
      </section>

      {/* 3. HOW IT WORKS (4 STEPS) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            مراحل دستیابی به پیشنهادهای شغلی برتر
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
            فقط در ۴ گام ساده، از بارگذاری تا دریافت نسخه اختصاصی
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {steps.map((st) => (
            <GlassCard key={st.num} className="p-6 relative overflow-hidden">
              <span className="absolute top-4 left-4 text-3xl font-black text-slate-200 dark:text-slate-800 font-mono tabular-nums select-none">
                {st.num}
              </span>
              <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center mb-4">
                {st.icon}
              </div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2">
                {st.title}
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                {st.desc}
              </p>
            </GlassCard>
          ))}
        </div>
      </section>

      {/* 4. BOTTOM CALL TO ACTION BANNER */}
      <section className="max-w-5xl mx-auto px-4">
        <GlassCard className="p-8 sm:p-12 text-center bg-gradient-to-br from-indigo-900/90 via-violet-900/90 to-purple-900/90 text-white border-violet-500/30 shadow-2xl relative overflow-hidden">
          <div className="relative z-10 max-w-2xl mx-auto space-y-4">
            <h2 className="text-2xl sm:text-3xl font-extrabold">
              آماده‌اید فرصت شغلی رؤیایی خود را به واقعیت تبدیل کنید؟
            </h2>
            <p className="text-xs sm:text-sm text-violet-200 leading-relaxed">
              همین حالا رزومه خود را وارد کنید تا ایجنت رزومه یار تحلیل جامعی از تناسب شما با برترین شرکت‌های فناوری ارائه دهد.
            </p>
            <div className="pt-2">
              <GradientButton
                size="lg"
                variant="primary"
                onClick={handleStart}
                className="bg-white text-violet-950 hover:bg-slate-100 shadow-xl"
                leftIcon={<ArrowLeft className="w-4 h-4 text-violet-950" />}
              >
                همین حالا شروع کنید
              </GradientButton>
            </div>
          </div>
        </GlassCard>
      </section>
    </div>
  );
};
