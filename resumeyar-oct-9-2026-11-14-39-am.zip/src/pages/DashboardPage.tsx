import React from 'react';
import {
  Sparkles,
  FileText,
  Sliders,
  Briefcase,
  CheckCircle2,
  ArrowLeft,
  TrendingUp,
  BrainCircuit,
  Wand2,
  Clock
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { GlassCard } from '../components/common/GlassCard';
import { GradientButton } from '../components/common/GradientButton';
import { ChecklistProgress } from '../components/common/StepProgress';
import { MatchScoreRing } from '../components/common/MatchScoreRing';

export const DashboardPage: React.FC = () => {
  const {
    user,
    navigate,
    isResumeUploaded,
    isPreferencesSet,
    stats,
    matchResults,
    jobs,
    tailoredResumes,
    setAgentDrawerOpen
  } = useApp();

  const isJobsAnalyzed = stats.analyzedCount > 0;
  const isTailoredCreated = stats.tailoredCount > 0;

  const checklistItems = [
    {
      id: 'step-upload',
      label: 'رزومه اولیه آپلود شد',
      isDone: isResumeUploaded,
      actionText: 'آپلود رزومه',
      onAction: () => navigate('/resume')
    },
    {
      id: 'step-preferences',
      label: 'ترجیحات شغلی و حقوق ثبت شد',
      isDone: isPreferencesSet,
      actionText: 'تنظیم معیارها',
      onAction: () => navigate('/preferences')
    },
    {
      id: 'step-analysis',
      label: 'آگهی‌های هدف ارزیابی و تحلیل شدند',
      isDone: isJobsAnalyzed,
      actionText: 'تحلیل آگهی‌ها',
      onAction: () => navigate('/jobs')
    },
    {
      id: 'step-tailored',
      label: 'حداقل یک رزومه اختصاصی هوشمند ساخته شد',
      isDone: isTailoredCreated,
      actionText: 'تولید رزومه',
      onAction: () => navigate('/jobs')
    }
  ];

  // Best matched job for spotlight
  const bestMatchJobId = Object.entries(matchResults).sort((a, b) => b[1].score - a[1].score)[0]?.[0];
  const bestJob = jobs.find((j) => j.id === bestMatchJobId);
  const bestMatchAnalysis = bestMatchJobId ? matchResults[bestMatchJobId] : null;

  return (
    <div className="space-y-8 pb-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* 1. WELCOME HEADER */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pt-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-violet-500/10 text-violet-700 dark:text-violet-300 text-xs font-semibold mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>پیشخوان مدیریت هوشمند رزومه</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
            سلام، {user?.name || 'کاربر گرامی'} عزیز 👋
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            ایجنت هوشمند آماده است تا تناسب شما را با آگهی‌های جدید بسنجد و رزومه اختصاصی تولید کند.
          </p>
        </div>

        {/* Header Action Button */}
        <div className="flex items-center gap-2.5">
          <GradientButton
            variant="glass"
            size="md"
            onClick={() => setAgentDrawerOpen(true)}
            rightIcon={<BrainCircuit className="w-4 h-4 text-violet-500" />}
          >
            مشاهده مغز متفکر ایجنت
          </GradientButton>
          <GradientButton
            variant="primary"
            size="md"
            onClick={() => navigate('/jobs')}
            leftIcon={<ArrowLeft className="w-4 h-4" />}
          >
            بررسی آگهی‌ها
          </GradientButton>
        </div>
      </div>

      {/* 2. STATS CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <GlassCard className="p-5 flex items-center justify-between" glow="violet">
          <div className="space-y-1">
            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
              تعداد آگهی‌های تحلیل‌شده
            </span>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-mono tabular-nums">
              {stats.analyzedCount} <span className="text-xs font-sans font-normal text-slate-400">آگهی</span>
            </div>
            <p className="text-[11px] text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              <span>پوشش جامع فرصت‌های مرتبط</span>
            </p>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
            <Briefcase className="w-6 h-6" />
          </div>
        </GlassCard>

        <GlassCard className="p-5 flex items-center justify-between" glow="fuchsia">
          <div className="space-y-1">
            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
              میانگین تناسب سوابق شما
            </span>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-mono tabular-nums">
              {stats.averageScore}٪
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              شاخص برداری هم‌پوشانی مهارت‌ها
            </p>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-violet-500/10 text-violet-600 dark:text-violet-400 flex items-center justify-center">
            <Sparkles className="w-6 h-6" />
          </div>
        </GlassCard>

        <GlassCard className="p-5 flex items-center justify-between" glow="indigo">
          <div className="space-y-1">
            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
              رزومه‌های ساخته‌شده اختصاصی
            </span>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-mono tabular-nums">
              {stats.tailoredCount} <span className="text-xs font-sans font-normal text-slate-400">نسخه</span>
            </div>
            <p className="text-[11px] text-violet-600 dark:text-violet-400 flex items-center gap-1">
              <Wand2 className="w-3 h-3" />
              <span>آماده برای ارسال با کاور لتر</span>
            </p>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-fuchsia-500/10 text-fuchsia-600 dark:text-fuchsia-400 flex items-center justify-center">
            <FileText className="w-6 h-6" />
          </div>
        </GlassCard>
      </div>

      {/* 3. PROGRESS CHECKLIST & QUICK ACTIONS (SPLIT) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Checklist Container */}
        <GlassCard className="p-6 lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                چک‌لیست آمادگی شغلی
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                مراحل لازم برای کسب بیشترین بازخورد مثبت از کارفرمایان
              </p>
            </div>
          </div>

          <ChecklistProgress items={checklistItems} />
        </GlassCard>

        {/* Quick Actions Panel */}
        <GlassCard className="p-6 space-y-4 flex flex-col justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white mb-1">
              دسترسی‌های سریع
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
              عملیات کلیدی جهت بهبود پرونده کاری
            </p>

            <div className="space-y-2.5">
              <button
                onClick={() => navigate('/resume')}
                className="w-full flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 hover:bg-violet-500/10 dark:hover:bg-violet-500/10 border border-slate-200/60 dark:border-slate-700/60 transition-all text-xs font-semibold text-slate-800 dark:text-slate-200 cursor-pointer group"
              >
                <span className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-indigo-500" />
                  ویرایش یا آپلود مجدد رزومه
                </span>
                <ArrowLeft className="w-3.5 h-3.5 text-slate-400 group-hover:-translate-x-1 transition-transform" />
              </button>

              <button
                onClick={() => navigate('/preferences')}
                className="w-full flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 hover:bg-violet-500/10 dark:hover:bg-violet-500/10 border border-slate-200/60 dark:border-slate-700/60 transition-all text-xs font-semibold text-slate-800 dark:text-slate-200 cursor-pointer group"
              >
                <span className="flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-violet-500" />
                  به‌روزرسانی ترجیحات و بازه حقوقی
                </span>
                <ArrowLeft className="w-3.5 h-3.5 text-slate-400 group-hover:-translate-x-1 transition-transform" />
              </button>

              <button
                onClick={() => navigate('/jobs')}
                className="w-full flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 hover:bg-violet-500/10 dark:hover:bg-violet-500/10 border border-slate-200/60 dark:border-slate-700/60 transition-all text-xs font-semibold text-slate-800 dark:text-slate-200 cursor-pointer group"
              >
                <span className="flex items-center gap-2">
                  <Briefcase className="w-4 h-4 text-fuchsia-500" />
                  جستجو و مقایسه آگهی‌های بازار
                </span>
                <ArrowLeft className="w-3.5 h-3.5 text-slate-400 group-hover:-translate-x-1 transition-transform" />
              </button>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-violet-500/10 border border-violet-500/20 text-xs text-violet-700 dark:text-violet-300">
            💡 <span className="font-semibold">توصیه ایجنت:</span> برای آگهی‌های با تناسب بالای ۷۵٪، حتماً رزومه اختصاصی تولید کرده و ارسال فرمایید.
          </div>
        </GlassCard>
      </div>

      {/* 4. BEST MATCH HIGHLIGHT SPOTLIGHT */}
      {bestJob && bestMatchAnalysis && (
        <GlassCard className="p-6 md:p-8 border-violet-500/30">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div className="flex items-start sm:items-center gap-4">
              <MatchScoreRing score={bestMatchAnalysis.score} size="lg" />
              <div className="space-y-1">
                <div className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full">
                  <CheckCircle2 className="w-3 h-3" />
                  بالاترین سازگاری شناسایی‌شده
                </div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                  {bestJob.title} — {bestJob.company}
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-2 max-w-xl">
                  {bestMatchAnalysis.summary}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 shrink-0 w-full md:w-auto justify-end">
              <button
                onClick={() => navigate(`/jobs/${bestJob.id}`)}
                className="px-4 py-2.5 rounded-2xl text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                جزئیات تطابق
              </button>
              <GradientButton
                size="md"
                variant="primary"
                onClick={() => navigate(`/tailor/${bestJob.id}`)}
                leftIcon={<ArrowLeft className="w-4 h-4" />}
              >
                ساخت رزومه اختصاصی این آگهی
              </GradientButton>
            </div>
          </div>
        </GlassCard>
      )}
    </div>
  );
};
